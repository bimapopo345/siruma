<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<meta property="og:image" content="https://danteproject.site/public/thumbnail/logo-true.jpg">
	<title>Demo Web Surat Permohonan Desa | Multi Desa | V.2</title>
	<meta content="" name="description">
	<meta content="" name="keywords">

	<!-- Favicons -->
	<link rel="shortcut icon" type="image/x-generic" href="https://danteproject.site/public/thumbnail/logo-true.jpg">
	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

	<!-- Vendor CSS Files -->
	<link href="<?php echo e(asset('green/assets/vendor/animate.css/animate.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('green/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('green/assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('green/assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('green/assets/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('green/assets/vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">    

	<!-- Template Main CSS File -->
	<link href="<?php echo e(asset('green/assets/css/style.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('green/assets/css/styletwo.css')); ?>" rel="stylesheet">
	<meta name="google-site-verification" content="tkq27n2LSUS8G2RVAyP-7wL0Op70HFQB3qRaCAGzWm4" />
</head>
<style type="text/css">
	#masuk:hover{
		color:#435ebe;
	}

	@media  only screen and (max-width: 600px) {
		#masuk{display: none;}
		.popup-overlay {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background-color: rgba(0, 0, 0, 0.5);
			z-index: 999;
			display: none;
		}
		.popup {
			position: fixed;
			bottom: 0;
			left: 0;
			width: 100%;
			border-top-right-radius: 25px;
			border-top-left-radius: 25px;
			background-color: #fff;
			transform: translateY(100%);
			transition: transform 0.3s ease-in-out;
			z-index: 1000;
		}
	}

	@media  only screen and (min-width: 601px) {
		#masuk_mobile{display: none;}
		#body_mobile{display: none;}
		#content_mobile{display: none;}

	}

	.popup.open {
		transform: translateY(0);
	}

	.popup-content {
		padding: 20px;
	}

	.close-btn {
		background-color: #ccc;
		padding: 8px 12px;
		border-radius: 4px;
		border: none;
		cursor: pointer;
	}

	.close-btn:hover {
		background-color: #999;
	}
</style>
<body>
	<div itemprop="image" itemscope="itemscope" itemtype="http://schema.org/ImageObject">
		<meta content="https://danteproject.site/public/thumbnail/logo-true.jpg" itemprop="url"/> </div>
		<!-- ======= Header ======= -->
		<header id="header" class="d-flex align-items-center">
			<div class="container d-flex align-items-center">

				<h1 class="logo me-auto"><a href="" style="color: #435ebe">WEB SURAT</a></h1>

				<nav id="navbar" class="navbar">
					<ul>
						<li><a class="nav-link scrollto active" href="#hero">Beranda</a></li>
						<li><a class="nav-link scrollto" href="#about">Panduan Daftar</a></li>
						<li><a class="nav-link scrollto" href="#why-us">Layanan Surat</a></li>
						<li><a class="nav-link scrollto " href="#cta">Masuk</a></li>
						<li><a class="nav-link scrollto" href="#contact">Scan Masuk</a></li>
					</ul>
					<i class="bi bi-list mobile-nav-toggle"></i>
				</nav><!-- .navbar -->

			</div>
		</header><!-- End Header -->

		<!-- ======= Hero Section ======= -->
		<section id="hero">
			<div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">


				<div class="carousel-inner" role="listbox">

					<!-- Slide 1 -->
					<div class="carousel-item active">
						<div class="carousel-container">
							<div class="container">
								<h2 class="animate__animated animate__fadeInDown">DEMO WEB SURAT <span>PERMOHONAN</span></h2>
								<p class="animate__animated animate__fadeInUp">Selamat datang di Web Surat Permohonan/Pengajuan Desa - Multi Kantor Kelurahan/Desa</p>
								<a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Baca Panduan</a>
							</div>
						</div>
					</div>

					<!-- Slide 2 -->

				</div>

			</div>
		</section><!-- End Hero -->

		<main id="main">

			<!-- ======= Featured Services Section ======= -->
			<section id="featured-services" class="featured-services section-bg">

				<div class="container">

					<div class="row no-gutters">
						<div class="col-lg-4 col-md-6">
							<div class="icon-box">
								<div class="icon"><i class="bi bi-pencil-square"></i></div>
								<h4 class="title">Tanda Tangan Digital</h4>
								<p class="description">Dalam sistem Web Surat Permohonan telah di siapkan Tanda Tangan Digital untuk Surat Ajuan. Tanda Tangan yang tampil menggunakan Tanda Tangan QrCode.</p>
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="icon-box">
								<div class="icon"><i class="bi bi-file-pdf"></i></div>
								<h4 class="title">Pengambilan Online</h4>
								<p class="description">Pengambilan Surat Ajuan bisa di lakukan secara Online dengan Mendownload File Surat ketika Sudah siap di berikan.</p>
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="icon-box">
								<div class="icon"><i class="bi bi-qr-code"></i></div>
								<h4 class="title">QR Code</h4>
								<p class="description">Di sediakan Poster QR Code per Kantor Kelurahan/Desa yang mendaftar. Masuk ke desa dengan Scan QR Code atau Kode Akses Desa.</p>
							</div>
						</div>
					</div>

				</div>
			</section><!-- End Featured Services Section -->

			<!-- ======= About Us Section ======= -->
			<section id="about" class="about">
				<div class="container">

					<div class="section-title">
						<h2>Panduan Pendaftaran</h2>
					</div>

					<div class="row">
						<div class="col-xl-12 pt-4 content">
							<p class="fst-italic">
								Panduan Pendaftaran Kantor Kelurahan/Desa :
							</p>
							<ul>
								<li><b>New :</b> <br>
									+ New page panel Admin <br>
									+ Lebih Fiks dan Flexible <br>
									+ Responsive Panel <br>
									+ Lebih banyak surat <br>
									+ Format/Template dan Form per Surat Pengajuan berbeda-beda (sesuai yang kita pilih) <br>
									+ dan banyak lainnya.
								</li>
								<li><i class="bi bi-check-circled"></i> 1. Buat Kode Pendaftaran Desa/Kelurahan klik link di samping dan masukkan email pendaftaran.<b>
									<a href="javascript:void(0)" id="mail" onclick="mail()" style="font-family: times new roman;color: #435ebe;">
										Daftar Desa Baru
									</a>
									/
									<a href="javascript:void(0)" onclick="masuk_langsung()" style="font-family: times new roman;color: #435ebe;">Cek Demo</a>
									/
									<a href="javascript:void(0)" onclick="masuk()" style="font-family: times new roman;color: #435ebe;">Masuk</a>
								</b></li>
								<li><i class="bi bi-check-circled"></i> 2. Setelah link Pendaftaran berhasil di Akses, isikan Data Kantor Kelurahan Anda.</li>
								<li><i class="bi bi-check-circled"></i> 3. Pastikan Data dan berkas-berkas benar dan sesuai dengan Kantor Kelurahan yang terdaftar, guna Admin mempermudah Verifikasi</li>
								<li><i class="bi bi-check-circled"></i> 4. Cek Email yang di gunakan untuk mendaftar untuk Info Verifikasi dan Informasi Data Data Desa.</li>
								<li><i class="bi bi-check-circled"></i> 5. Setelah Pendaftaran berhasil di Verifikasi oleh Admin, anda akan di berikan Kode Akses dan Qr Code untuk masuk ke Halaman Desa masing-masing.</li>
								<li><i class="bi bi-check-circled"></i> 6. Bagikan Kode Akses/QR Code ke Warga Desa untuk mengajukan Permohonan Surat.</li>
							</ul>
						</div>
					</div>

				</div>
			</section><!-- End About Us Section -->

			<!-- ======= Why Us Section ======= -->
			<section id="why-us" class="why-us">
				<div class="container">

					<div class="section-title">
						<h2>Fitur Layanan Surat</h2>
					</div>

					<div class="row no-gutters text-center">

						<?php $__currentLoopData = $template; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tmp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php  
						$surat = str_replace("_", " ", $tmp->nama_template);
						$urutan = explode('_', $tmp->urutan_template)[1];
						?>
						<div class="col-lg-4 col-md-6 content-item">
							<span><?php echo e($surat); ?></span>
							<h4>TEMPLATE KE <?php echo e($urutan); ?></h4>
							<p><a href="<?php echo e(asset('template-surat')); ?>/<?php echo e($tmp->gambar_template); ?>" target="_blank" style="color: #f73859">Cek Format Surat di sini</a></p>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</div>

				</div>
			</section><!-- End Why Us Section -->

			<!-- ======= Cta Section ======= -->
			<section id="cta" class="cta">
				<div class="container">

					<div class="row">
						<div class="col-lg-9 text-center text-lg-start">
							<h3>Masukkan Kode Akses</h3>
							<p>Masuk ke Halaman menggunakan Kode Akses. Cek Kode Akses kamu ada di Email yang terkirim. <br> Klik tombol di samping untuk masuk</p>
						</div>
						<div class="col-lg-3 cta-btn-container text-center"> 
							<a class="cta-btn align-middle" onclick="masuk()" id="masuk">Masuk</a>
							<a class="open-btn cta-btn align-middle" id="masuk_mobile">Masuk</a>
						</div>
					</div>

				</div>
			</section><!-- End Cta Section -->

			<!-- ======= Contact Section ======= -->
			<section id="contact" class="contact">
				<div class="container">

					<div class="section-title">
						<h2>Scan Masuk</h2>
						<p>Masuk ke Halaman dengan Scan QR Code Desa, Anda akan di arahkan ke Halaman masing-masing</p>
					</div>

					<div class="row">
						<script src="<?php echo e(asset('scankode.min.js')); ?>" type="text/javascript"></script>
						<div class="col-xl-12 mt-5 mt-xl-0 d-flex align-items-stretch">
							<form action="" method="post" role="form" class="php-email-form">
								<div class="row" id="reader">
								</form>
							</div>

						</div>

					</div>
				</section><!-- End Contact Section -->

				<div class="popup-overlay" id="popup_mobile"></div>
				<div class="popup" id="content_mobile">
					<div class="popup-content">
						<div class="row pb-4">
							<div class="col-12 text-center">
								<a href="javascript:void(0)" style="background: transparent;" class="close-btn text-primary"><i class="bi bi-x"></i></a>
							</div>
							<div class="col-12 text-center">
								<div class="align-items-center justify-content-between mb-4">
									<div class="input-group">
										<!-- <input type="text" class="form-control border-primary" autofocus autocomplete="off" id="search-input" placeholder="Cari Produk disini"> -->
										<input type="text" autofocus="" id="title_user" style="border-radius: 15px 15px 15px" autocomplete="off" title="Kode Akses Desa" class="swal2-input" placeholder="Kode Akses">
										<a href="javascript:void(0)" onclick="send()" class="btn text-white" style="background: #435ebe;">Masuk</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

			</main><!-- End #main -->

			<!-- ======= Footer ======= -->
			<footer id="footer">
				<div class="container">
					<h3>DIGITAL SURAT PERMOHONAN</h3>
					<p>Web Surat Permohonan Digital Kantor Kelurahan/Desa - Aplikasi Surat Pengajuan/Permohonan Desa<br> Multi Desa v2</p>
					<div class="credits">
						Powered by <a href="https://danteproject.site/" style="color: #435ebe;">DANTE Project | Dani Trisna</a>
					</div>
				</div>
			</footer><!-- End Footer -->

			<a href="https://www.facebook.com/plugins/video.php?height=314&href=https%3A%2F%2Fweb.facebook.com%2Fdanteprojectgroup%2Fvideos%2F1433367563843258%2F&show_text=true&width=560&t=0" target="_blank" class="back-to-top d-flex align-items-center justify-content-center btn-danger"><i class="bi bi-play"></i></a>

			<!-- Vendor JS Files -->
			<script src="<?php echo e(asset('green/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
			<script src="<?php echo e(asset('green/assets/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
			<script src="<?php echo e(asset('green/assets/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
			<script src="<?php echo e(asset('green/assets/vendor/php-email-form/validate.js')); ?>"></script>
			<!--<script src="<?php echo e(asset('green/assets/js/not.js')); ?>"></script>-->
			<!--<script src="<?php echo e(asset('green/assets/js/disabledi.js')); ?>"></script>-->
			<script src="<?php echo e(asset('green/assets/js/default.js')); ?>"></script>
			<script src="<?php echo e(asset('green/assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
			<script src="<?php echo e(asset('template/dist/assets/js/extensions/sweetalert2.js')); ?>"></script>
			<script src="<?php echo e(asset('template/dist/assets/vendors/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
			<!-- Template Main JS File -->
			<script src="<?php echo e(asset('green/assets/js/main.js')); ?>"></script>
			<?php echo $__env->make('home/custom-js/custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<script type="text/javascript">
				document.addEventListener("DOMContentLoaded", function() {
					var popupOverlay = document.querySelector(".popup-overlay");
					var popup = document.querySelector(".popup");
					var openBtn = document.querySelector(".open-btn");
					var closeBtn = document.querySelector(".close-btn");

					openBtn.addEventListener("click", function() {
						popupOverlay.style.display = "block";
						setTimeout(function() {
							popup.classList.add("open");
						}, 100);
					});

					closeBtn.addEventListener("click", function() {
						popup.classList.remove("open");
						setTimeout(function() {
							popupOverlay.style.display = "none";
						}, 300);
					});
				});

			</script>
			</html><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/index.blade.php ENDPATH**/ ?>