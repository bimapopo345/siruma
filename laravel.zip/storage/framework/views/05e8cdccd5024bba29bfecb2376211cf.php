
<?php $__env->startSection('title','Profil Desa'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="">Profile</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Profile Desa</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <section class="section">
        <div class="card">
            <div class="card-header">
                <h2>Profil Desa <button type="button" class="btn btn-profil rounded-pill btn-sm btn-warning block" style="float: right;">
                    <i class="bx bx-edit"></i> Ubah
                </button></h2>
                
            </div>
            <div class="card-body">
                <div class="table table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>EMAIL</td>
                                <td>:</td>
                                <td><?php echo e($cst->email_desa); ?></td>
                            </tr>
                            <tr>
                                <td>TELEPON</td>
                                <td>:</td>
                                <td><?php echo e($cst->telepon_desa); ?></td>
                            </tr>
                            <tr>
                                <td>PROVISI</td>
                                <td>:</td>
                                <td><?php echo e($cst->name_province); ?></td>
                            </tr>
                            <tr>
                                <td>KOTA</td>
                                <td>:</td>
                                <td><?php echo e($cst->name_city); ?></td>
                            </tr>
                            <tr>
                                <td>KECAMATAN</td>
                                <td>:</td>
                                <td><?php echo e($cst->name_district); ?></td>
                            </tr>
                            <tr>
                                <td>KELURAHAN</td>
                                <td>:</td>
                                <td><?php echo e($cst->name_village); ?></td>
                            </tr>
                            <tr>
                                <td>LOKASI DESA</td>
                                <td>:</td>
                                <td><?php echo e($cst->lokasi_desa); ?></td>
                            </tr>
                            <tr>
                                <td>LOGO</td>
                                <td>:</td>
                                <td>
                                    <img src="<?php echo e(asset('foto')); ?>/<?php echo e($cst->logo); ?>" width="70">
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </section>
</div>
<?php echo $__env->make('page/desa/profildesa/ubah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row mb-4">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($cst->lokasi_desa==NULL): ?>
    <div class="alert alert-light-danger color-danger"><i
        class="bi bi-exclamation-circle"></i> ALAMAT TIDAK DI KETAHUI</div>
        <?php else: ?>
        <div class="col-12"><iframe class="form-control" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=720&amp;height=600&amp;hl=en&amp;q=Kantor+Kelurahan+<?php echo e($cst->name_village); ?>+<?php echo e($cst->name_district); ?>+<?php echo e($cst->name_city); ?>+(My%20Business%20Name)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>
        </div>
        <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        var ajaxUrl;
        $(".btn-profil").click(function() {
            $("#profilDesaForm")[0].reset();
            $(".modal-title").html('<i class="fa fa-building-o"></i> Profil Desa');
            $(".invalid-feedback").children("strong").text("");
            $(".select_opsi").val(null).trigger('change');
            $("#profilDesaForm input").removeClass("is-invalid");
            $("#profilDesaForm select").removeClass("is-invalid");
            $("#profilDesaForm textarea").removeClass("is-invalid");
            $("#modal_form_profil").modal('show');
            ajaxUrl = " <?php echo e(route('lengkapi')); ?> ";
        });
        $(function () {
            $('#profilDesaForm').submit(function(e) {
                e.preventDefault();
                let formData = new FormData(this);
                show_loading();
                $(".invalid-feedback").children("strong").text("");
                $("#profilDesaForm input").removeClass("is-invalid");
                $("#profilDesaForm select").removeClass("is-invalid");
                $("#profilDesaForm textarea").removeClass("is-invalid");
                $.ajax({
                    method: "POST",
                    headers: {
                        Accept: "application/json"
                    },
                    contentType: false,
                    processData: false,
                    url: ajaxUrl,
                    data: formData,
                    success: function (response) {
                        hide_loading();
                        if (response.status == 'true') {
                            $("#profilDesaForm")[0].reset();
                                // $('#modal_form_profil').modal('hide');
                                Swal.fire({
                                    icon: 'success',
                                    type: 'success',
                                    title: 'Success',
                                    text: response.message
                                });
                                setTimeout(function() {
                                    window.location = "";
                                }, 200);
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    type: 'error',
                                    title: 'Gagal',
                                    dangerMode: true,
                                    text: response.message
                                });
                            }
                        },
                        error: function (response) {
                            hide_loading();
                            if (response.status === 422) {
                                let errors = response.responseJSON.errors;
                                Object.keys(errors).forEach(function (key) {
                                    $("#" + key).addClass("is-invalid");
                                    $("#" + key + "Error").children("strong").text(errors[key][0]);
                                });
                            } else {
                                swal({
                                    icon: 'error',
                                    type: 'error',
                                    title: 'Gagal',
                                    dangerMode: true,
                                    text: response.message
                                });
                            }
                        }
                    });
            });
        });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('page/desa/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ratdela\resources\views/page/desa/profildesa/profil.blade.php ENDPATH**/ ?>