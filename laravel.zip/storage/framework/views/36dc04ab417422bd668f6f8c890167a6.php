<?php if(Auth::user()->level=="Desa" OR Auth::user()->level=="Staff" OR Auth::user()->level=="Kepala Desa" OR Auth::user()->level=="Pengaju"): ?>
<?php $__currentLoopData = $userporfil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($usp->foto_profil == NULL): ?>
<img src="<?php echo e(asset('template_new/assets/img/avatars/1.png')); ?>" alt class="w-px-40 h-40 rounded-circle" />
<?php else: ?>
<img src="<?php echo e(asset('profil')); ?>/<?php echo e($usp->foto_profil); ?>" alt class="w-px-40 h-40 rounded-circle" />
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(Auth::user()->level == "Admin"): ?>
<img src="<?php echo e(asset('template_new/assets/img/avatars/1.png')); ?>" alt class="w-px-40 h-40 rounded-circle" />
<?php endif; ?><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ladar\resources\views/page/desa/layout/foto-header.blade.php ENDPATH**/ ?>