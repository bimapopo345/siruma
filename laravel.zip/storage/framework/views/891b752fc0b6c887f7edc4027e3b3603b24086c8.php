<!DOCTYPE html>
<html>
<head>
  <title>PENDAFTARAN KELURAHAN</title>
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('template/daftar/bostrap.min.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('template/daftar/awesome.css')); ?>">
  <script type="text/javascript" src="<?php echo e(asset('template/daftar/bundle.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('template/daftar/jquery.min.js')); ?>"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('template/daftar/style.css')); ?>">

</head>
<body style="background: #435ebe;">
    <!-- MultiStep Form -->
    <div class="container-fluid" id="grad1">
        <div class="row justify-content-center mt-0">
            <div class="col-11 col-sm-9 col-md-7 col-lg-8 text-center p-0 mt-3 mb-2" id="msform">
                <div class="card px-0 pt-4 pb-0 mt-3 mb-3">
                    <h2><strong>Pendaftaran Kelurahan Desa</strong></h2>
                    <p>Lengkapi data - data di Bawah</p>
                    <div class="row">
                        <div class="col-md-12 mx-0">
                            <!-- progressbar -->
                            <ul id="progressbar">
                                <li class="active" id="account"><strong>Lokasi</strong></li>
                                <li id="personal"><strong>Informasi</strong></li>
                                <li id="payment"><strong>Dokumen</strong></li>
                                <!-- <li id="confirm"><strong>Finish</strong></li> -->
                            </ul> <!-- fieldsets -->
                            <fieldset>
                                <div class="form-card">
                                    <h2 class="fs-title">Pilih Daerah/Kelurahan anda <a href="<?php echo e(route('pendaftaran')); ?>" class="btn btn-sm btn-primary" style="float: right;">Refresh</a></h2> 
                                    <?php if(empty($_GET['state'])): ?>
                                    <form method="GET" action="">
                                        <?php echo csrf_field(); ?>
                                        <label>Provinsi</label>
                                        <select id="country" required="" name="country" class="form-control">
                                            <option value="" selected disabled>Pilih Provinsi</option>
                                            <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($prc->code); ?>"> <?php echo e($prc->name_province); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label>Kota</label>
                                        <select name="state" required="" id="state" class="form-control"></select>
                                        <button class="btn btn-sm btn-success mt-3">Seacrh</button>
                                    </form>
                                    <?php endif; ?>
                                    <form method="post" enctype="multipart/form-data" action="<?php echo e(route('tambah_pendaftaran')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php if(!empty($_GET['state'])): ?>
                                        <?php  
                                        $daerah=DB::table('indonesia_districts')->get();
                                        $kotaku=DB::table('indonesia_cities')->get();
                                        ?>
                                        <label>Provinsi</label>
                                        <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($key->code==$_GET['country']): ?>
                                        <input type="text" readonly="" value="<?php echo e($key->name_province); ?>" name="">
                                        <input type="hidden" readonly="" value="<?php echo e($key->code); ?>" name="province">
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <label>Kota</label>
                                        <?php $__currentLoopData = $kotaku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ktk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($ktk->code==$_GET['state']): ?>
                                        <input type="text" readonly="" value="<?php echo e($ktk->name_city); ?>" name="">
                                        <input type="hidden" readonly="" value="<?php echo e($ktk->code); ?>" name="city">
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <label>Kecamatan</label>
                                        <select class="form-control" required="" name="district" id="kec">
                                            <?php $__currentLoopData = $daerah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($dr->city_code==$_GET['state']): ?>
                                            <option value="<?php echo e($dr->code); ?>"><?php echo e($dr->name_district); ?></option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label class="text mt-3">Kel/Desa</label>
                                        <select class="form-control mb-3" required="" name="village" id="desa">
                                        </select>
                                        <!-- <input type="email" name="email" placeholder="Email Id" /> <input type="text" name="uname" placeholder="UserName" /> <input type="password" name="pwd" placeholder="Password" /> <input type="password" name="cpwd" placeholder="Confirm Password" /> -->
                                    </div> 
                                    <input type="button" name="next" class="next action-button" value="Next Step" />
                                </fieldset>
                                <fieldset>
                                    <div class="form-card">
                                        <h2 class="fs-title">Information Data Kelurahan</h2> 
                                        <input type="text" required="" name="email" placeholder="Email" /> 
                                        <input type="password" required="" name="password" placeholder="Password" /> 
                                        <input type="number" required="" name="telepon_desa" placeholder="Contact No." /> 
                                        <label>Alamat</label>
                                        <textarea class="form-control" rows="5" required="" name="lokasi_desa" autocomplete="off"></textarea>
                                    </div> <input type="button" name="previous" class="previous action-button-previous" value="Previous" /> <input type="button" name="next" class="next action-button" value="Next Step" />
                                </fieldset>
                                <fieldset>
                                    <div class="form-card">
                                        <h2 class="fs-title">Upload beberapa Berkas Kelurahan</h2> 
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="imgPreview">
                                                    <div class="form-group">
                                                        <input type="file" required="" id="images" class="form-control" name="file[]" multiple>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div> 
                                    <!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script> -->
                                    <script>
                                        $(function() {
        // Multiple images preview with JavaScript
        var multiImgPreview = function(input, imgPreviewPlaceholder) {

            if (input.files) {
                var filesAmount = input.files.length;

                for (i = 0; i < filesAmount; i++) {
                    var reader = new FileReader();

                    reader.onload = function(event) {
                        $($.parseHTML('<img>')).attr('src', event.target.result).width('200').appendTo(imgPreviewPlaceholder);
                    }

                    reader.readAsDataURL(input.files[i]);
                }
            }

        };

        $('#images').on('change', function() {
            multiImgPreview(this, 'div.imgPreview');
        });
    });    
</script>
<input type="button" name="previous" class="previous action-button-previous" value="Previous" />
<button type="submit" name="make_payment" class="btn btn-lg btn-success">Confirm</button>
</form>
<?php endif; ?>

</fieldset>

</div>
</div>
</div>
</div>
</div>
</div>
</body>
<script type="text/javascript" src="<?php echo e(asset('template/daftar/ajax.js')); ?>"></script>
<script>
        // when country dropdown changes
        $('#country').change(function() {

            var countryID = $(this).val();

            if (countryID) {

                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('pendaftaran-desa/getState')); ?>?country_id=" + countryID,
                    success: function(res) {

                        if (res) {

                            $("#state").empty();
                            $("#state").append('<option>Select State</option>');
                            $.each(res, function(key, value) {
                                $("#state").append('<option value="' + value.code + '">' + value.name_city +
                                    '</option>');
                            });

                        } else {

                            $("#state").empty();
                        }
                    }
                });
            } else {

                $("#state").empty();
            }
        });
    </script>
    <script>
        // when country dropdown changes
        $('#kec').change(function() {

            var districtID = $(this).val();

            if (districtID) {

                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('pendaftaran-desadua/getState')); ?>?district_code=" + districtID,
                    success: function(res) {

                        if (res) {

                            $("#desa").empty();
                            $("#desa").append('<option>Select State</option>');
                            $.each(res, function(key, value) {
                                $("#desa").append('<option value="' + value.code + '">' + value.name_village +
                                    '</option>');
                            });

                        } else {

                            $("#desa").empty();
                        }
                    }
                });
            } else {

                $("#desa").empty();
            }
        });
    </script>
    <script src="<?php echo e(asset('template/dist/assets/js/extensions/sweetalert2.js')); ?>"></script>
    <script src="<?php echo e(asset('template/dist/assets/vendors/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
    <?php if(session('yes')): ?>
    <script type="text/javascript">
        document.getElementById('success');
        Swal.fire({
            icon: "success",
            title: "Register Berhasil",
            text: "Tunggu Konfirmasi dari Pihak Admin melalui Email.",
        });
    </script>
    <?php endif; ?>
    <?php if(session('digunakan')): ?>
    <script type="text/javascript">
        document.getElementById('warning');
        Swal.fire({
            icon: "warning",
            title: "Wilayah Tersedia",
            text: "Wilayah sudah Terdaftar dalam Data.",
        });
    </script>
    <?php endif; ?>
    <?php if(session('coba')): ?>
    <script type="text/javascript">
        document.getElementById('warning');
        Swal.fire({
            icon: "warning",
            title: "Coba Lagi",
            text: "Coba lagi nanti untuk mendaftar.",
        });
    </script>
    <?php endif; ?>
    </html><?php /**PATH D:\xampp\htdocs\desa\resources\views/pendaftaran.blade.php ENDPATH**/ ?>