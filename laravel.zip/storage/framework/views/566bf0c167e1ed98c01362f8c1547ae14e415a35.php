<!DOCTYPE html>
<html lang="en">
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($dt->nomor_surat); ?></title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/bootstrap.css')); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/dripicons/webfont.css')); ?>"> -->
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/pages/dripicons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/app.css')); ?>">
</head>
<style type="text/css">
    .footer {
        position: absolute;
        /*absolute*/
        bottom: 0;
        right: 0;
        left: 0;
        text-align: right;
        padding: 10px;
    }
    .signature {
        display: inline-block;
        text-align: center;
        width: 50%; /* Adjust the width as needed */
        margin: 0 auto;
    }
</style>
<body style="background: white;color: black;">
    <div class="container-fluid" style="background: white;">
        <div class="row">
            <div class="col-xl-12">
                <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <center>
                    <img src="<?php echo e(asset('foto')); ?>/<?php echo e($ds->logo); ?>" alt="avatar" class="img" width="70" style="float: left;">
                    <b>PEMERINTAHAN <?php echo e($ds->name_city); ?> <br>
                        KECAMATAN <?php echo e($ds->name_district); ?></b>
                        <h5 style="color: black;">KANTOR DESA <?php echo e($ds->name_village); ?></h5>
                        <span><?php echo e($ds->lokasi_desa); ?></span>
                    </center>
                    <hr>
                    <center>
                        <span style="font-size: 18px;text-transform: uppercase;font-weight: bold;text-decoration: underline;"><?php echo e($dt->nama_surat); ?></span>
                        <br>
                        <span>Nomor : <?php echo e($dt->nomor_surat); ?></span>
                    </center>
                    <p class="text mt-3" style="font-size:14.5px;">
                        Yang bertanda tangan di bawah ini: 
                    </p>
                    <?php  
                    $remark = explode(";", $dt->remark);
                    $remark_1 = explode(";", $dt->remark_1);
                    ?>
                    <table border="0" cellpadding="3" cellspacing="0" class="text" style="font-size:14.5px;margin-top: -15px;margin-left: 2rem;">
                        <tr>
                          <td>Nama</td>
                          <td>:</td>
                          <td>
                             <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php echo e($kpl->name); ?>

                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </td>
                     </tr>
                     <tr>
                        <td>Jabatan</td>
                        <td>:</td>
                        <td>
                           <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php echo e($kpl->level); ?> Desa <?php echo e(ucwords(strtolower($ds->name_village))); ?> Kecamatan <?php echo e(ucwords(strtolower($ds->name_district))); ?>

                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </td>
                   </tr>
                   <tr>
                      <td>Alamat</td>
                      <td>:</td>
                      <td>
                         <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php echo e($kpl->alamat); ?>

                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </td>
                 </tr>
             </table>
             <p class="text mt-2" style="font-size:14.5px;">
                 Dengan ini memberikan Keterangan pada :
             </p>
             <table border="0" cellpadding="3" cellspacing="0" class="text" style="font-size:14.5px;margin-top: -15px;margin-left: 2rem;">
                <tr>
                    <td>Nama Wali/Ortu</td>
                    <td>:</td>
                    <td><?php echo e($remark[0]); ?></td>
                </tr>
                <tr>
                    <td>NIK</td>
                    <td>:</td>
                    <td><?php echo e($remark[1]); ?></td>
                </tr>
                <tr>
                    <td>Tempat/Tanggal Lahir</td>
                    <td>:</td>
                    <td><?php echo e($remark[2]); ?> / <?php echo e(tanggal_indonesia($remark[3])); ?></td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td>:</td>
                    <td><?php echo e($remark[5]); ?></td>
                </tr>
                <tr>
                    <td>Pekerjaan</td>
                    <td>:</td>
                    <td><?php echo e($remark[4]); ?></td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td>:</td>
                    <td><?php echo e($remark[6]); ?></td>
                </tr>
            </table>
            <p class="text mt-2" style="font-size:14.5px;">
                Keterangan :
            </p>
            <ol style="margin-top: -20px;">
                <li>
                    Yang tersebut adalah benar Penduduk <?php echo e($remark[6]); ?>.
                </li>
                <li>
                    Benar tersebut tergolong penduduk yang <b><u>BERPENGHASILAN KURANG/KURANG MAMPU.</u></b>
                </li>
                <li>
                    Yang tersebut diatas adalah Wali/Orang Tua dari :
                    <table style="margin-left: 2rem;">
                        <tr>
                            <td>Nama</td>
                            <td>:</td>
                            <td><?php echo e($dt->name); ?></td>
                        </tr>
                        <tr>
                            <td>NIK</td>
                            <td>:</td>
                            <td><?php echo e($dt->nik); ?></td>
                        </tr>
                    </table>
                </li>
                <li>
                    <?php  
                    function terbilangRupiah($angka) {
                        $angka = abs($angka);
                        $terbilang = '';
                        $huruf = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
                        if ($angka < 12) {
                            $terbilang = $huruf[$angka];
                        } elseif ($angka < 20) {
                            $terbilang = terbilangRupiah($angka - 10) . " belas";
                        } elseif ($angka < 100) {
                            $terbilang = terbilangRupiah($angka / 10) . " puluh " . terbilangRupiah($angka % 10);
                        } elseif ($angka < 200) {
                            $terbilang = "seratus " . terbilangRupiah($angka - 100);
                        } elseif ($angka < 1000) {
                            $terbilang = terbilangRupiah($angka / 100) . " ratus " . terbilangRupiah($angka % 100);
                        } elseif ($angka < 2000) {
                            $terbilang = "seribu " . terbilangRupiah($angka - 1000);
                        } elseif ($angka < 1000000) {
                            $terbilang = terbilangRupiah($angka / 1000) . " ribu " . terbilangRupiah($angka % 1000);
                        } elseif ($angka < 1000000000) {
                            $terbilang = terbilangRupiah($angka / 1000000) . " juta " . terbilangRupiah($angka % 1000000);
                        } else {
                            $terbilang = 'Angka terlalu besar untuk diolah';
                        }
                        return ucwords($terbilang);
                    }
                    ?>
                    Penghasilan Wali/Orang Tua per Bulan Rp. <?php echo e(number_format($remark_1[0],0,",",".")); ?> ( <?php echo e(terbilangRupiah($remark_1[0])); ?> ).
                </li>
                <li>
                    Surat Keterangan ini digunakan untuk <?php echo e($dt->keperluan); ?>.
                </li>
            </ol>
            <p class="text mt-2" style="font-size:14.5px;">
             Demikian Surat Keterangan ini telah dibuat dan diberikan kepada yang bersangkutan untuk digunakan sesuai perlunya, atas perhatian dan kerjasamanya kami ucapkan terima kasih.
         </p>
         <div class="footer">
            <div class="signature">
             <div>
                Dikeluarkan di : <?php echo e(ucwords(strtolower($ds->name_village))); ?> <br>
                <u>Pada Tanggal : <?php echo date('m F Y') ?></u>
            </div>
            <div>Kepala Desa <?php echo e(ucfirst(strtolower($ds->name_village))); ?></div>
            <div><img src="data:image/png;base64, <?php echo base64_encode(QrCode::size(95)->generate($dt->ttd)); ?> " class="text pt-1" height="95"></div>
            <div>
               <?php if(Auth::user()->level!=="Kepala Desa"): ?>
               <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <p><b><u><?php echo e($kpl->name); ?></u></b></p>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php else: ?>
               <p><b><u><?php echo e(Auth::user()->name); ?></u></b></p>
               <?php endif; ?>
           </div>
       </div>
   </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>
</body>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</html><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/page/desa/template/SURAT_KETERANGAN_PENGHASILAN_ORANG_TUA/SKPOT_1/print.blade.php ENDPATH**/ ?>