

<?php $__env->startSection('title','Laporan Surat'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mb-3">
    <!-- <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Laporan /</span> Surat Pengajuan</h4> -->
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="">Laporan</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Surat Pengajuan</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="row">
     <div class="col-lg-5 pb-4" style="background: white;box-shadow:2px 2px grey;">
        <form method="get">
            <?php echo csrf_field(); ?>
            <input type="date" required="" class="form-control mt-4" name="awal">
            <input type="date" required="" class="form-control mt-1" name="akhir">
            <button class="btn btn-sm btn-primary mt-2"><i class="fa fa-filter"></i> Tampilkan</button>
            <?php if(!empty($_GET['awal'])): ?>
            <a href="<?php echo e(route('print',['awal'=>$_GET['awal'],'akhir'=>$_GET['akhir']])); ?>" class="btn btn-sm btn-danger mt-2" target="_blank"><i class="fa fa-print"></i></a>
            <?php endif; ?>
        </form>
    </div>
</div>
</div>
<section class="section">
    <div class="card">
        <div class="card-header">
            Laporan Pengajuan Surat
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped" id="table1">
                    <thead>
                        <tr>
                            <th>No. </th>
                            <th>Tanggal Pengajuan</th>
                            <th>Nomor Surat</th>
                            <th>Surat</th>
                            <th>Nama Pengaju</th>
                            <th>Status</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no=1; ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?=$no; ?>. </th>
                            <td><?php echo e(tanggal_indonesia($dt->tgl_req)); ?></td>
                            <td><?php echo e($dt->nomor_surat); ?></td>
                            <td><?php echo e($dt->nama_surat); ?></td>
                            <td><?php echo e($dt->name); ?></td>
                            <td>
                                <?php if($dt->status_pengajuan=="Pengecekan Permohonan"): ?>
                                <span class="badge bg-danger">Data Sedang <br>di Periksa</span>
                                <?php elseif($dt->status_pengajuan=="Data Belum Lengkap"): ?>
                                <span class="badge bg-danger"><?php echo e($dt->status_pengajuan); ?></span>
                                <?php else: ?>
                                <span class="badge bg-success"><?php echo e($dt->status_pengajuan); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($dt->selesai==NULL): ?>
                                Menunggu Konfirmasi
                                <?php endif; ?>
                                <?php if($dt->selesai!==NULL): ?>
                                <span class="badge bg-success">
                                    <?php echo e($dt->selesai); ?>

                                </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php $no++ ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/desa/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ladar\resources\views/page/staff/selesai/laporan.blade.php ENDPATH**/ ?>