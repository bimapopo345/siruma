<!DOCTYPE html>
<html lang="en">
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo e($dt->nomor_surat); ?></title>

  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/bootstrap.css')); ?>">
  <!-- <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/dripicons/webfont.css')); ?>"> -->
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/pages/dripicons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/app.css')); ?>">
</head>
<style type="text/css">
  .footer {
    position: absolute;
    bottom: 0;
    right: 0;
    left: 0;
    text-align: right;
    padding: 10px;
  }
  .signature {
    display: inline-block;
    text-align: center;
    width: 50%; /* Adjust the width as needed */
    margin: 0 auto;
  }
</style>
<body style="background: white;color: black;">
  <div class="container-fluid" style="background: white;">
    <div class="row">
      <div class="col-xl-12">
        <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <center>
          <img src="<?php echo e(asset('foto')); ?>/<?php echo e($ds->logo); ?>" alt="avatar" class="img pt-2" width="65" style="float: left;">
          PEMERINTAHAN <?php echo e($ds->name_city); ?> <br>
          KECAMATAN <?php echo e($ds->name_district); ?>

          <h5 style="color: black;">KANTOR DESA <?php echo e($ds->name_village); ?></h5>
          <span><i><?php echo e($ds->lokasi_desa); ?></i></span>
        </center>
        <hr>
        <center>
          <h5 style="text-transform: uppercase;color: black;"><u><?php echo e($dt->nama_surat); ?></u></h5>
          Nomor : <?php echo e($dt->nomor_surat); ?>

        </center>
        <p class="text mt-5">
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yang bertanda tangan di bawah ini Kepala Desa <?php echo e(ucwords(strtolower($ds->name_village))); ?> Kecamatan <?php echo e(ucwords(strtolower($ds->name_district))); ?>

          <?php echo e(ucwords(strtolower($ds->name_city))); ?>, dengan ini menerangkan bahwa: 
        </p>
        <table border="0" style="margin-left: 27px;">
         <tr>
          <td>Nama</td>
          <td>:</td>
          <td><?php echo e($dt->name); ?></td>
        </tr>
        <td>Tempat/Tanggal/Lahir</td>
        <td>:</td>
        <td><?php echo e($dt->tempat); ?>, <?php echo e($dt->tgl_lahir); ?></td>
      </tr>
      <tr>
        <td>No. KTP</td>
        <td>:</td>
        <td><?php echo e($dt->nik); ?></td>
      </tr>
      <tr>
        <td>Agama</td>
        <td>:</td>
        <td><?php echo e($dt->agama); ?></td>
      </tr>
      <tr>
        <td>Pekerjaan</td>
        <td>:</td>
        <td><?php echo e($dt->pekerjaan); ?></td>
      </tr>
      <tr>
        <td>Alamat</td>
        <td>:</td>
        <td><?php echo e($dt->alamat); ?></td>
      </tr>
    </table>
    <p style="text-align: left;" class="text mt-5">
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nama yang tersebut di atas adalah benar penduduk yang berdomisili di Desa <?php echo e(ucwords(strtolower($ds->name_village))); ?>, Berdasarkan pengamatan kami bahwa orang yang bersangkutan adalah benar memiliki usaha. 
   </p>
   <p style="text-align: left;" class="text mt-5">
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Demikian Surat Keterangan Usaha ini dibuat untuk dapat dipergunakan sebagaimana
     mestinya. 
   </p>
  <!--  <center>
    <table class="table mt-5" align="center" style="color: black;">
      <tr>
        <td align="right" colspan="3">
          <?php echo e($ds->name_village); ?>, <?php echo e(tanggal_indonesia($dt->tgl_req)); ?> <br>
          <span style="padding-right: 25px;">KEPALA DESA <?php echo e($ds->name_village); ?></span>
        </td>
      </tr>
      <tr>
        <td></td>
        <td></td>
        <td align="center" class="text">
            <?php if(Auth::user()->level!=="Kepala Desa"): ?>
            <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><b><u><?php echo e($kpl->name); ?></u></b></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p><b><u><?php echo e(Auth::user()->name); ?></u></b></p>
            <?php endif; ?>
          </span>
        </td>
      </tr>
    </table>
  </center> -->
  <div class="footer">
    <div class="signature">
      <div><?php echo e(ucwords(strtolower($ds->name_village))); ?>, <?php echo e(tanggal_indonesia($dt->tgl_req)); ?></div>
      <div>Kepala Desa <?php echo e(ucwords(strtolower($ds->name_village))); ?></div>
      <div><img src="<?php echo e(asset($dt->ttd)); ?>" class="text" height="95"></div>
      <div>
       <?php if(Auth::user()->level!=="Kepala Desa"): ?>
       <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <p><b><u><?php echo e($kpl->name); ?></u></b></p>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <?php else: ?>
       <p><b><u><?php echo e(Auth::user()->name); ?></u></b></p>
       <?php endif; ?>
     </div>
   </div>
 </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ratdela\resources\views/page/desa/template/SURAT_KETERANGAN_USAHA/SKU_2/print.blade.php ENDPATH**/ ?>