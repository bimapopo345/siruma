<div class="modal fade text-left" id="update<?php echo e($pgn->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel1">Update Data User</h5>
                <button type="button" class="close rounded-pill"
                data-bs-dismiss="modal" aria-label="Close">
                <i data-feather="x"></i>
            </button>
        </div>
        <div class="modal-body">
            <form class="form form-vertical" action="" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e($pgn->id); ?>" name="id">
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label for="password-vertical">Email</label>
                            <input type="text" id="password-vertical"
                            class="form-control" value="<?php echo e($pgn->email); ?>" name="email">
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label for="password-vertical">Password</label>
                            <input type="text" id="password-vertical"
                            class="form-control" name="password">
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label for="contact-info-vertical">Role</label>
                            <select id="contact-info-vertical"
                            class="form-control" name="role">
                            <option <?php if($pgn->role=="Staff"){echo "selected";}?> value="Staff">Staff</option>
                            <option <?php if($pgn->role=="Kepala Desa"){echo "selected";}?> value="Kepala Desa">Kepala Desa</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn" data-bs-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Close</span>
                </button>
                <button class="btn btn-primary ml-1">
                    <i class="bx bx-check d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Accept</span>
                </button>
            </div>
        </form>
    </div>
</div>
</div>
</div><?php /**PATH D:\xampp\htdocs\desa\resources\views/desa/user/edit.blade.php ENDPATH**/ ?>