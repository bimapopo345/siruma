    <div class="app-brand demo">
      <a href="javascript:void(0)" class="app-brand-link">
        <span class="app-brand-logo demo">
          <!-- <img src=""> -->
        </span>
        <span class="app-brand-text demo menu-text fw-bolder" style="text-transform: uppercase;"><?php echo e(implode(" ", array_slice(explode(" ", Auth::user()->name),0,2))); ?></span>
      </a>

      <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
        <i class="bx bx-chevron-left bx-sm align-middle"></i>
      </a>
    </div>

    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1" id="menu">
      <?php if(Auth::user()->level=="Desa"): ?>
      <li class="menu-header small text-uppercase">
        <span class="menu-header-text">Dashboard</span>
      </li>
      <li class="menu-item">
        <a href="<?php echo e(route('dashboard')); ?>" class="menu-link">
          <i class="menu-icon tf-icons bx bx-home"></i>
          <div data-i18n="Basic">Dashboard</div>
        </a>
      </li>
      <li class="menu-header small text-uppercase">
        <span class="menu-header-text">Profile</span>
      </li>
      <li class="menu-item">
        <a href="<?php echo e(route('profil_desa')); ?>" class="menu-link">
          <i class="menu-icon tf-icons bx bx-building"></i>
          <div data-i18n="Basic">Profile Desa</div>
        </a>
      </li>
      <li class="menu-header small text-uppercase">
        <span class="menu-header-text">User & Master</span>
      </li>
      <li class="menu-item">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
          <i class="menu-icon tf-icons bx bx-user"></i>
          <div data-i18n="Account Settings">Data User</div>
        </a>
        <ul class="menu-sub">
          <li class="menu-item">
            <a href="<?php echo e(route('data_user','Pengaju')); ?>" class="menu-link">
              <div data-i18n="Account">Pengaju</div>
            </a>
          </li>
          <li class="menu-item">
            <a href="<?php echo e(route('data_user','Pengurus')); ?>" class="menu-link">
              <div data-i18n="Notifications">Pengurus</div>
            </a>
          </li>
        </ul>
      </li>
      <li class="menu-item">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
          <i class="menu-icon tf-icons bx bx-briefcase"></i>
          <div data-i18n="Account Settings">Data Master</div>
        </a>
        <ul class="menu-sub">
          <li class="menu-item">
            <a href="<?php echo e(route('data_surat')); ?>" class="menu-link">
              <div data-i18n="Account">Surat</div>
            </a>
          </li>
          <li class="menu-item">
            <a href="<?php echo e(route('waktu_layanan')); ?>" class="menu-link">
              <div data-i18n="Notifications">Waktu Pelayanan</div>
            </a>
          </li>
          <li class="menu-item">
            <a href="<?php echo e(route('prosedur')); ?>" class="menu-link">
              <div data-i18n="Notifications">Prosedur</div>
            </a>
          </li>
        </ul>
      </li>
      <li class="menu-header small text-uppercase">
        <span class="menu-header-text">Barcode Scan</span>
      </li>
      <li class="menu-item">
        <a href="<?php echo e(route('barcode')); ?>" class="menu-link">
          <i class="menu-icon tf-icons bx bx-qr-scan"></i>
          <div data-i18n="Basic">Qr Code Poster</div>
        </a>
      </li>
      <?php elseif(Auth::user()->level=="Pengaju"): ?>
      <li class="menu-header small text-uppercase">
        <span class="menu-header-text">Dashboard</span>
      </li>
      <li class="menu-item">
        <a href="<?php echo e(route('dashboard_pengaju')); ?>" class="menu-link">
          <i class="menu-icon tf-icons bx bx-home"></i>
          <div data-i18n="Basic">Dashboard</div>
        </a>
      </li>
      <li class="menu-header small text-uppercase">
        <span class="menu-header-text">Pengajuan Saya</span>
      </li>
      <li class="menu-item">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
          <i class="menu-icon tf-icons bx bx-food-menu"></i>
          <div data-i18n="Account Settings">Data Pengajuan</div>
        </a>
        <ul class="menu-sub">
          <?php $__currentLoopData = $request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="menu-item">
            <a href="<?php echo e(route('data_request',['id_surat'=>$req->id_surat,'singkatan'=>$req->singkatan])); ?>" class="menu-link">
              <div data-i18n="Notifications"><?php echo e($req->singkatan); ?></div>
            </a>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </li>
      <?php elseif(Auth::user()->level=="Staff"): ?>
      <li class="menu-header small text-uppercase">
        <span class="menu-header-text">Dashboard</span>
      </li>
      <li class="menu-item">
        <a href="<?php echo e(route('dashboard_staff')); ?>" class="menu-link">
          <i class="menu-icon tf-icons bx bx-home"></i>
          <div data-i18n="Basic">Dashboard</div>
        </a>
      </li>
      <li class="menu-header small text-uppercase">
        <span class="menu-header-text">Pengajuan Surat</span>
      </li>
      <li class="menu-item">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
          <i class="menu-icon tf-icons bx bx-file-find"></i>
          <div data-i18n="Account Settings">Belum Acc</div>
        </a>
        <ul class="menu-sub">
          <?php $__currentLoopData = $request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="menu-item">
            <a href="<?php echo e(route('staff_acc',['id_surat'=>$req->id_surat,'surat'=>$req->singkatan])); ?>" class="menu-link">
              <div data-i18n="Notifications"><?php echo e($req->singkatan); ?></div>
            </a>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </li>
      <li class="menu-item">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
          <i class="menu-icon tf-icons bx bx-printer"></i>
          <div data-i18n="Account Settings">Cetak Surat</div>
        </a>
        <ul class="menu-sub">
          <?php $__currentLoopData = $request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="menu-item">
            <a href="<?php echo e(route('staff_cetak',['id_surat'=>$req->id_surat,'surat'=>$req->singkatan])); ?>" class="menu-link">
              <div data-i18n="Notifications"><?php echo e($req->singkatan); ?></div>
            </a>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </li>
      <li class="menu-item">
        <a href="<?php echo e(route('surat_selesai')); ?>" class="menu-link">
          <i class="menu-icon tf-icons bx bx-archive"></i>
          <div data-i18n="Basic">Surat Selesai</div>
        </a>
      </li>
      <li class="menu-header small text-uppercase">
        <span class="menu-header-text">Laporan</span>
      </li>
      <li class="menu-item">
        <a href="<?php echo e(route('laporan')); ?>" class="menu-link">
          <i class="menu-icon tf-icons bx bx-file"></i>
          <div data-i18n="Basic">Laporan</div>
        </a>
      </li>
      <?php elseif(Auth::user()->level=="Kepala Desa"): ?>
      <li class="menu-header small text-uppercase">
        <span class="menu-header-text">Dashboard</span>
      </li>
      <li class="menu-item">
        <a href="<?php echo e(route('dashboard_kepaladesa')); ?>" class="menu-link">
          <i class="menu-icon tf-icons bx bx-home"></i>
          <div data-i18n="Basic">Dashboard</div>
        </a>
      </li>
      <li class="menu-header small text-uppercase">
        <span class="menu-header-text">Pengajuan Surat</span>
      </li>
      <li class="menu-item">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
          <i class="menu-icon tf-icons bx bx-check"></i>
          <div data-i18n="Account Settings">ACC dan TTD</div>
        </a>
        <ul class="menu-sub">
          <?php $__currentLoopData = $request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="menu-item">
            <a href="<?php echo e(route('kepaladesa_acc',['id_surat'=>$req->id_surat,'surat'=>$req->singkatan])); ?>" class="menu-link">
              <div data-i18n="Notifications"><?php echo e($req->singkatan); ?></div>
            </a>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </li>
      <?php else: ?>
      <li class="menu-header small text-uppercase">
        <span class="menu-header-text">Dashboard</span>
      </li>
      <li class="menu-item">
        <a href=" <?php echo e(route('user_desa')); ?> " class="menu-link">
          <i class="menu-icon tf-icons bx bx-collection"></i>
          <div data-i18n="Basic">Data Desa</div>
        </a>
      </li>
      <li class="menu-item">
        <a href=" <?php echo e(route('data_template')); ?> " class="menu-link">
          <i class="menu-icon tf-icons bx bx-collection"></i>
          <div data-i18n="Basic">Template</div>
        </a>
      </li>
      <li class="menu-item">
        <a href=" <?php echo e(route('data_url')); ?> " class="menu-link">
          <i class="menu-icon tf-icons bx bx-collection"></i>
          <div data-i18n="Basic">URL Pendaftaran</div>
        </a>
      </li>
      <?php endif; ?>

<!-- <li class="menu-header small text-uppercase">
  <span class="menu-header-text">Pages</span>
</li>
<li class="menu-item">
  <a href="javascript:void(0);" class="menu-link menu-toggle">
    <i class="menu-icon tf-icons bx bx-lock-open-alt"></i>
    <div data-i18n="Authentications">Authentications</div>
</a>
<ul class="menu-sub">
    <li class="menu-item">
      <a href="auth-login-basic.html" class="menu-link" target="_blank">
        <div data-i18n="Basic">Login</div>
    </a>
</li>
<li class="menu-item">
  <a href="auth-register-basic.html" class="menu-link" target="_blank">
    <div data-i18n="Basic">Register</div>
</a>
</li>
<li class="menu-item">
  <a href="auth-forgot-password-basic.html" class="menu-link" target="_blank">
    <div data-i18n="Basic">Forgot Password</div>
</a>
</li>
</ul>
</li>
<li class="menu-item">
  <a href="javascript:void(0);" class="menu-link menu-toggle">
    <i class="menu-icon tf-icons bx bx-cube-alt"></i>
    <div data-i18n="Misc">Misc</div>
</a>
<ul class="menu-sub">
    <li class="menu-item">
      <a href="pages-misc-error.html" class="menu-link">
        <div data-i18n="Error">Error</div>
    </a>
</li>
<li class="menu-item">
  <a href="pages-misc-under-maintenance.html" class="menu-link">
    <div data-i18n="Under Maintenance">Under Maintenance</div>
</a>
</li>
</ul>
</li>
<li class="menu-header small text-uppercase"><span class="menu-header-text">Components</span></li>
<li class="menu-item">
  <a href="cards-basic.html" class="menu-link">
    <i class="menu-icon tf-icons bx bx-collection"></i>
    <div data-i18n="Basic">Cards</div>
</a>
</li>
<li class="menu-item">
  <a href="javascript:void(0)" class="menu-link menu-toggle">
    <i class="menu-icon tf-icons bx bx-box"></i>
    <div data-i18n="User interface">User interface</div>
</a>
<ul class="menu-sub">
    <li class="menu-item">
      <a href="ui-accordion.html" class="menu-link">
        <div data-i18n="Accordion">Accordion</div>
    </a>
</li>
<li class="menu-item">
  <a href="ui-alerts.html" class="menu-link">
    <div data-i18n="Alerts">Alerts</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-badges.html" class="menu-link">
    <div data-i18n="Badges">Badges</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-buttons.html" class="menu-link">
    <div data-i18n="Buttons">Buttons</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-carousel.html" class="menu-link">
    <div data-i18n="Carousel">Carousel</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-collapse.html" class="menu-link">
    <div data-i18n="Collapse">Collapse</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-dropdowns.html" class="menu-link">
    <div data-i18n="Dropdowns">Dropdowns</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-footer.html" class="menu-link">
    <div data-i18n="Footer">Footer</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-list-groups.html" class="menu-link">
    <div data-i18n="List Groups">List groups</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-modals.html" class="menu-link">
    <div data-i18n="Modals">Modals</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-navbar.html" class="menu-link">
    <div data-i18n="Navbar">Navbar</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-offcanvas.html" class="menu-link">
    <div data-i18n="Offcanvas">Offcanvas</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-pagination-breadcrumbs.html" class="menu-link">
    <div data-i18n="Pagination &amp; Breadcrumbs">Pagination &amp; Breadcrumbs</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-progress.html" class="menu-link">
    <div data-i18n="Progress">Progress</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-spinners.html" class="menu-link">
    <div data-i18n="Spinners">Spinners</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-tabs-pills.html" class="menu-link">
    <div data-i18n="Tabs &amp; Pills">Tabs &amp; Pills</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-toasts.html" class="menu-link">
    <div data-i18n="Toasts">Toasts</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-tooltips-popovers.html" class="menu-link">
    <div data-i18n="Tooltips & Popovers">Tooltips &amp; popovers</div>
</a>
</li>
<li class="menu-item">
  <a href="ui-typography.html" class="menu-link">
    <div data-i18n="Typography">Typography</div>
</a>
</li>
</ul>
</li>
<li class="menu-item">
  <a href="javascript:void(0)" class="menu-link menu-toggle">
    <i class="menu-icon tf-icons bx bx-copy"></i>
    <div data-i18n="Extended UI">Extended UI</div>
</a>
<ul class="menu-sub">
    <li class="menu-item">
      <a href="extended-ui-perfect-scrollbar.html" class="menu-link">
        <div data-i18n="Perfect Scrollbar">Perfect scrollbar</div>
    </a>
</li>
<li class="menu-item">
  <a href="extended-ui-text-divider.html" class="menu-link">
    <div data-i18n="Text Divider">Text Divider</div>
</a>
</li>
</ul>
</li>

<li class="menu-item">
  <a href="icons-boxicons.html" class="menu-link">
    <i class="menu-icon tf-icons bx bx-crown"></i>
    <div data-i18n="Boxicons">Boxicons</div>
</a>
</li>
<li class="menu-header small text-uppercase"><span class="menu-header-text">Forms &amp; Tables</span></li>
<li class="menu-item">
  <a href="javascript:void(0);" class="menu-link menu-toggle">
    <i class="menu-icon tf-icons bx bx-detail"></i>
    <div data-i18n="Form Elements">Form Elements</div>
</a>
<ul class="menu-sub">
    <li class="menu-item">
      <a href="forms-basic-inputs.html" class="menu-link">
        <div data-i18n="Basic Inputs">Basic Inputs</div>
    </a>
</li>
<li class="menu-item">
  <a href="forms-input-groups.html" class="menu-link">
    <div data-i18n="Input groups">Input groups</div>
</a>
</li>
</ul>
</li>
<li class="menu-item">
  <a href="javascript:void(0);" class="menu-link menu-toggle">
    <i class="menu-icon tf-icons bx bx-detail"></i>
    <div data-i18n="Form Layouts">Form Layouts</div>
</a>
<ul class="menu-sub">
    <li class="menu-item">
      <a href="form-layouts-vertical.html" class="menu-link">
        <div data-i18n="Vertical Form">Vertical Form</div>
    </a>
</li>
<li class="menu-item">
  <a href="form-layouts-horizontal.html" class="menu-link">
    <div data-i18n="Horizontal Form">Horizontal Form</div>
</a>
</li>
</ul>
</li>
<li class="menu-item">
  <a href="tables-basic.html" class="menu-link">
    <i class="menu-icon tf-icons bx bx-table"></i>
    <div data-i18n="Tables">Tables</div>
</a>
</li>
<li class="menu-header small text-uppercase"><span class="menu-header-text">Misc</span></li>
<li class="menu-item">
  <a
  href="https://github.com/themeselection/sneat-html-admin-template-free/issues"
  target="_blank"
  class="menu-link"
  >
  <i class="menu-icon tf-icons bx bx-support"></i>
  <div data-i18n="Support">Support</div>
</a>
</li>
<li class="menu-item">
    <a
    href="https://themeselection.com/demo/sneat-bootstrap-html-admin-template/documentation/"
    target="_blank"
    class="menu-link"
    >
    <i class="menu-icon tf-icons bx bx-file"></i>
    <div data-i18n="Documentation">Documentation</div>
</a>
</li> -->
</ul><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/page/desa/layout/sidebar.blade.php ENDPATH**/ ?>