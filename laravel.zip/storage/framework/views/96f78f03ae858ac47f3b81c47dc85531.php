<!DOCTYPE html>
<html lang="en">
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo e($dt->nomor_surat); ?></title>

  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/bootstrap.css')); ?>">
  <!-- <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/dripicons/webfont.css')); ?>"> -->
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/pages/dripicons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/app.css')); ?>">
</head>
<style type="text/css">
  .footer {
    position: absolute;
    bottom: 0;
    right: 0;
    left: 0;
    text-align: right;
    padding: 10px;
  }
  .signature {
    display: inline-block;
    text-align: center;
    width: 50%; /* Adjust the width as needed */
    margin: 0 auto;
  }
</style>
<body style="background: white;color: black;">
  <div class="container-fluid" style="background: white;">
    <div class="row">
      <div class="col-xl-12">
        <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <center>
          <img src="<?php echo e(asset('foto')); ?>/<?php echo e($ds->logo); ?>" alt="avatar" class="img pt-2" width="65" style="float: left;">
          PEMERINTAHAN <?php echo e($ds->name_city); ?> <br>
          KECAMATAN <?php echo e($ds->name_district); ?>

          <h5 style="color: black;">KANTOR DESA <?php echo e($ds->name_village); ?></h5>
          <span><i><?php echo e($ds->lokasi_desa); ?></i></span>
        </center>
        <hr>
        <center>
          <h5 style="text-transform: uppercase;color: black;"><u><?php echo e($dt->nama_surat); ?></u></h5>
          Nomor : <?php echo e($dt->nomor_surat); ?>

        </center>
        <p>
          Yang bertanda tangan di bawah ini: 
        </p>
        <table>
          <tr>
            <td>Nama</td>
            <td>:</td>
            <td>
             <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php echo e($kpl->name); ?>

             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </td>
         </tr>
         <tr>
          <td>Jabatan</td>
          <td>:</td>
          <td>
           <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php echo e($kpl->level); ?>

           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </td>
       </tr>
       <tr>
        <td>Alamat</td>
        <td>:</td>
        <td>
         <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php echo e($kpl->alamat); ?>

         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </td>
     </tr>
   </table>
   <p class="text mt-3">
     Menerangkan dengan sebenarnya bahwa: 
   </p>
   <table class="table" cellpadding="3" align="left" style="color: black;">
    <tr>
      <td>1. Nama</td>
      <td>:</td>
      <td><?php echo e($dt->name); ?></td>
    </tr>
    <tr>
      <td>2. Jenis Kelamin</td>
      <td>:</td>
      <td><?php echo e($dt->jenis_kelamin); ?></td>
    </tr>
    <tr>
      <td>3. Tempat/Tanggal/Lahir</td>
      <td>:</td>
      <td><?php echo e($dt->tempat); ?>, <?php echo e(tanggal_indonesia($dt->tgl_lahir)); ?></td>
    </tr>
    <tr>
      <td>4. Nama Orang Tua</td>
      <td>:</td>
      <td>
        <?php  
        $nama_ortu = explode(";", $dt->remark);
        ?>
        <?php echo e($nama_ortu[0]); ?>

      </td>
    </tr>
    <tr>
      <td>5. Agama</td>
      <td>:</td>
      <td><?php echo e($dt->agama); ?></td>
    </tr>
    <tr>
      <td>6. Alamat</td>
      <td>:</td>
      <td><?php echo e($dt->alamat); ?></td>
    </tr>
  </table>
  <p style="text-align: center;" class="text mt-3">
   Setelah diadakan penelitian hingga saat dikeluarkannya Surat Keterangan ini, yang
   bersangkutan benar-benar keadaan sosial ekonominya tergolong <b><u>Kurang Mampu</u></b>. 
   <br>
   <br>
   Demikian surat keterangan ini kami dibuat dan diberikan kepada yang berkepentingan
   untuk selanjutnya supaya dipergunakan sebagai <b>Persyaratan <?php echo e($dt->keperluan); ?> </b>
 </p>
 <div class="footer">
  <div class="signature">
    <div><?php echo e(ucfirst(strtolower($ds->name_village))); ?>, <?php echo e(tanggal_indonesia($dt->tgl_req)); ?></div>
    <div>Kepala Desa <?php echo e(ucfirst(strtolower($ds->name_village))); ?></div>
    <div><img src="<?php echo e(asset($dt->ttd)); ?>" class="text" height="95"></div>
    <div>
     <?php if(Auth::user()->level!=="Kepala Desa"): ?>
     <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p><b><u><?php echo e($kpl->name); ?></u></b></p>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php else: ?>
     <p><b><u><?php echo e(Auth::user()->name); ?></u></b></p>
     <?php endif; ?>
   </div>
 </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ratdela\resources\views/page/desa/template/SURAT_KETERANGAN_TIDAK_MAMPU/SKTM_2/print.blade.php ENDPATH**/ ?>