

<?php $__env->startSection('title','Surat Permohonan'); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div id="loading">
        <span class="fa fa-circle-o-notch fa-pulse fa-3x"></span>
    </div>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title"><?php echo e(Auth::user()->name); ?> - Request</h4>
            <sup>FORM REQUEST PERMOHONAN</sup>
        </div>

        <div class="card-body">
            <form method="post" id="requestForm" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-xl-12">
                        <h6>Persyaratan Permohonan <?php echo e($surat->nama_surat); ?></h6>
                        <div class="form-group">
                            <?php
                            $array = explode(PHP_EOL, $surat->persyaratan);
                            $total = count($array);
                            foreach($array as $item) {
                              echo "<span>". $item . "</span><br>";
                          }
                          ?>
                      </div>
                  </div>
                  <hr>
                  <div class="col-md-6">
                    <h6>Nama Lengkap</h6>
                    <div class="form-group position-relative has-icon-left">
                        <input type="text" value="<?php echo e($dt->name); ?>" readonly="" style="background: transparent;" class="form-control"
                        placeholder="Lengkapi Biodata Anda" value="">
                        <div class="form-control-icon">
                            <i class="dripicons dripicons-information"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <h6>Tempat/Tanggal Lahir</h6>
                    <div class="form-group position-relative has-icon-left">
                        <input type="text" value="<?php echo e($dt->tempat); ?>/<?php echo e($dt->tgl_lahir); ?>" readonly="" style="background: transparent;" class="form-control"
                        placeholder="Lengkapi Biodata Anda" value="">
                        <div class="form-control-icon">
                            <i class="dripicons dripicons-information"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <h6>Nik</h6>
                    <div class="form-group position-relative has-icon-left">
                        <input type="text" value="<?php echo e($dt->nik); ?>" readonly="" style="background: transparent;" class="form-control"
                        placeholder="Lengkapi Biodata Anda" value="">
                        <div class="form-control-icon">
                            <i class="dripicons dripicons-information"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <h6>Pekerjaan</h6>
                    <div class="form-group position-relative has-icon-left">
                        <input type="text" value="<?php echo e($dt->pekerjaan); ?>" readonly="" style="background: transparent;" class="form-control"
                        placeholder="Lengkapi Biodata Anda" value="">
                        <div class="form-control-icon">
                            <i class="dripicons dripicons-information"></i>
                        </div>
                    </div>
                </div>
                <input type="hidden" value="<?php echo e($surat->id_surat); ?>" id="id_surat" name="id_surat">
                <input type="hidden" value="<?php echo e($surat->singkatan); ?>" name="singkatan" id="singkatan">
                <div class="col-md-6">
                    <h6>Agama</h6>
                    <div class="form-group position-relative has-icon-left">
                        <input type="text" value="<?php echo e($dt->agama); ?>" readonly="" style="background: transparent;" class="form-control"
                        placeholder="Lengkapi Biodata Anda" value="">
                        <div class="form-control-icon">
                            <i class="dripicons dripicons-information"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <h6>Jenis Kelamin</h6>
                    <div class="form-group position-relative has-icon-left">
                        <input type="text" value="<?php echo e($dt->jenis_kelamin); ?>" readonly="" style="background: transparent;" class="form-control"
                        placeholder="Lengkapi Biodata Anda" value="">
                        <div class="form-control-icon">
                            <i class="dripicons dripicons-information"></i>
                        </div>
                    </div>
                </div>
                <input type="text" hidden="" value="<?php echo e($surat->urutan_template); ?>" name="urutan_template">
                <!-- Form SKD -->
                <?php if($surat->singkatan_template == 'SURAT_KETERANGAN_DOMISILI'): ?>
                <?php echo $__env->make('pengaju/request/SURAT_KETERANGAN_DOMISILI/skd_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <!-- FORM SKTM -->
                <?php if($surat->singkatan_template == 'SURAT_KETERANGAN_TIDAK_MAMPU'): ?>

                <?php if($surat->urutan_template == 'SKTM_1'): ?>
                <?php echo $__env->make('pengaju/request/SURAT_KETERANGAN_TIDAK_MAMPU/sktm_1_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php else: ?>
                <?php echo $__env->make('pengaju/request/SURAT_KETERANGAN_TIDAK_MAMPU/sktm_2_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>

                <?php endif; ?>
                <!-- end sktm -->
                <!-- FORM SKU -->
                <?php if($surat->singkatan_template == 'SURAT_KETERANGAN_USAHA'): ?>

                <?php if($surat->urutan_template == 'SKU_1'): ?>
                <?php echo $__env->make('pengaju/request/SURAT_KETERANGAN_USAHA/sku_1_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php else: ?>
                <?php endif; ?>

                <?php endif; ?>
                <!-- end SKU -->
            </div>
            <div class="row" id="after-add-more">
                <div class="col-xl-12">
                    <h6>Berkas Persyaratan <span class="text-danger">*</span></h6>
                    <div class="form-group position-relative">
                        <input type="file" name="berkas" id="berkas" class="form-control">
                        <span class="invalid-feedback" role="alert" id="berkasError">
                            <strong></strong>
                        </span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12 mt-2">
                    <button class="btn btn-sm btn-primary form-control" onclick="return confirm('Lanjut melakukan Pengajuan Surat')">KONFIRMASI PENGAJUAN</button>
                </div>
            </div>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(function () {
        $('#requestForm').submit(function(e) {
            e.preventDefault();
            let formData = new FormData(this);
            $("#loading").show();
            $(".invalid-feedback").children("strong").text("");
            $("#requestForm input").removeClass("is-invalid");
            // $("#requestForm select").removeClass("is-invalid");
            // $("#requestForm textarea").removeClass("is-invalid");
            $.ajax({
                method: "POST",
                headers: {
                    Accept: "application/json"
                },
                contentType: false,
                processData: false,
                url: "<?php echo e(route('add_request')); ?>",
                data: formData,
                success: function (response) {
                    $("#loading").hide();
                    if (response.status == 'true') {
                        $("#requestForm")[0].reset();
                        Swal.fire({
                            icon: 'success',
                            type: 'success',
                            title: 'Success',
                            text: response.message
                        });
                        setTimeout(function() {
                            window.location = response.redirect;
                        }, 350);
                    } else {
                        Swal.fire({
                            icon: 'error',
                            type: 'error',
                            title: 'Gagal',
                            dangerMode: true,
                            text: response.message
                        });
                    }
                },
                error: function (response) {
                    $("#loading").hide();
                    if (response.status === 422) {
                        let errors = response.responseJSON.errors;
                        Object.keys(errors).forEach(function (key) {
                            $("#" + key).addClass("is-invalid");
                            $("#" + key + "Error").children("strong").text(errors[key][0]);
                        });
                    } else {
                        swal({
                            icon: 'error',
                            type: 'error',
                            title: 'Gagal',
                            dangerMode: true,
                            text: response.message
                        });
                    }
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('desa/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/pengaju/request/index.blade.php ENDPATH**/ ?>