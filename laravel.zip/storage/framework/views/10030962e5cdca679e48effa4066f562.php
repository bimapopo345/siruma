<!DOCTYPE html>
<html lang="en">

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($dt->nomor_surat); ?></title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/bootstrap.css')); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/dripicons/webfont.css')); ?>"> -->
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/pages/dripicons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/app.css')); ?>">
</head>
<style type="text/css">
    .footer_right {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        text-align: right;
        padding: 10px;
    }
    .footer_left {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        text-align: left;
        padding: 10px;
    }
    .signature {
        display: inline-block;
        text-align: center;
        width: 50%; /* Adjust the width as needed */
        margin: 0 auto;
    }
</style>
<body style="background: white;color: black;">
    <div class="container-fluid" style="background: white;">
        <div class="row">
            <div class="col-xl-12">
                <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <center>
                    <img src="<?php echo e(asset('foto')); ?>/<?php echo e($ds->logo); ?>" alt="avatar" class="img pt-2" width="65" style="float: left;">
                    PEMERINTAHAN <?php echo e($ds->name_city); ?> <br>
                    KECAMATAN <?php echo e($ds->name_district); ?>

                    <h5 style="color: #000;">KELURAHAN <?php echo e($ds->name_village); ?></h5>
                    <span><i><?php echo e($ds->lokasi_desa); ?></i></span>
                </center>
                <hr>
                <center>
                    <h5 style="text-transform: uppercase;color: black;"><u><?php echo e($dt->nama_surat); ?></u></h5>
                    Nomor : <?php echo e($dt->nomor_surat); ?>

                </center>
                <p style="text-align: left;">
                    &nbsp;&nbsp;&nbsp; Yang bertanda tangan di bawah ini Lurah <?php echo e(ucwords(strtolower($ds->name_village))); ?> <?php echo e(ucwords(strtolower($ds->name_city))); ?>, <br style="float: left;">Menerangkan bahwa :
                </p>
                <center>
                    <table border="0" align="center" class="text mt-2 mb-4">
                        <tr>
                            <td>Nama</td>
                            <td>:</td>
                            <td><?php echo e($dt->name); ?></td>
                        </tr>
                        <tr>
                            <td>Tempat, tanggal lahir</td>
                            <td>:</td>
                            <td><?php echo e($dt->tempat); ?>, <?php echo e(tanggal_indonesia($dt->tgl_lahir)); ?></td>
                        </tr>
                        <tr>
                            <td>Jenis Kelamin</td>
                            <td>:</td>
                            <td><?php echo e($dt->jenis_kelamin); ?></td>
                        </tr>
                        <tr>
                            <td>Agama</td>
                            <td>:</td>
                            <td><?php echo e($dt->agama); ?></td>
                        </tr>
                        <tr>
                            <td>Pekerjaan</td>
                            <td>:</td>
                            <td><?php echo e($dt->pekerjaan); ?></td>
                        </tr>
                        <tr>
                            <td>No. NIK</td>
                            <td>:</td>
                            <td><?php echo e($dt->nik); ?></td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td><?php echo e($dt->alamat); ?></td>
                        </tr>
                    </table>
                </center>
                <center>
                    Adalah benar - benar penduduk asli Kampung <?php echo e(ucwords(strtolower($ds->nama_village))); ?> Kecamatan <?php echo e(ucwords(strtolower($ds->name_district))); ?>.
                    <p>"Surat Keterangan ini digunakan untuk Keperluan <b><i><u><?php echo e($dt->keperluan); ?></u></i></b>"</p>
                    <p>Demikian surat ini diberikan kepada yang bersangkutan agar dapat dipergunakan untuk sebagaimana mestinya.</p>
                   <!--  <table class="table mt-5" align="center" style="color: black;">
                        <tr>
                            <td align="center">
                                Tanda Tangan <br> Yang Bersangkutan
                            </td>
                            <td align="center">
                                <?php echo e($ds->name_city); ?> <br>
                                Kepala Desa Kelurahan <?php echo e(ucwords(strtolower($ds->name_village))); ?> <br>
                            </td>
                        </tr>
                        <tr>
                            <td align="center" class="text pt-5">
                                <p style="padding-top: 20%;"><b><u><?php echo e($dt->name); ?></u></b></p>
                            </td>
                            <td align="center" class="text">
                                <?php if(Auth::user()->level!=="Kepala Desa"): ?>
                                <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p><b><u><?php echo e($kpl->name); ?></u></b></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <p><b><u><?php echo e(Auth::user()->name); ?></u></b></p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table> -->
                </center>
                <div class="footer_left">
                    <div class="signature">
                        <div>Tanda Tangan Yang Bersangkutan</div>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <div><?php echo e($dt->name); ?></div>
                    </div>
                </div>
                <div class="footer_right">
                    <div class="signature">
                        <div><?php echo e(ucwords(strtolower($ds->name_city))); ?></div>
                        <div>Kepala Desa kelurahan <?php echo e(ucwords(strtolower($ds->name_village))); ?></div>
                        <div><img src="<?php echo e(asset($dt->ttd)); ?>" class="text" height="95"></div>
                        <div>
                           <?php if(Auth::user()->level!=="Kepala Desa"): ?>
                           <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <p><b><u><?php echo e($kpl->name); ?></u></b></p>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php else: ?>
                           <p><b><u><?php echo e(Auth::user()->name); ?></u></b></p>
                           <?php endif; ?>
                       </div>
                   </div>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </div>
       </div>
   </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ratdela\resources\views/page/desa/template/SURAT_KETERANGAN_DOMISILI/SKD_1/print.blade.php ENDPATH**/ ?>