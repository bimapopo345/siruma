<?php $__currentLoopData = $userporfil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($usp->foto_profil == NULL): ?>
<img src="<?php echo e(asset('template_new/assets/img/avatars/1.png')); ?>" alt class="w-px-40 h-40 rounded-circle" />
<?php else: ?>
<img src="<?php echo e(asset('profil')); ?>/<?php echo e($usp->foto_profil); ?>" alt class="w-px-40 h-40 rounded-circle" />
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH E:\xampp\htdocs\Custom Produk\webdesa_siruma\resources\views/page/desa/layout/foto-header.blade.php ENDPATH**/ ?>