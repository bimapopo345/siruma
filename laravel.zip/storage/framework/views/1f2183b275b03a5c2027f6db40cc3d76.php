<div class="col-xl-12">
	<div class="row">
		<h5>1. Data Bayi</h5>
	</div>
	<div class="row">
		<label class="col-sm-3">Nama Bayi <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" class="form-control" id="nama_bayi" name="nama_bayi">
			<span class="invalid-feedback d-block" role="alert" id="nama_bayiError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Hari Lahir <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" class="form-control" id="hari_lahir" name="hari_lahir">
			<span class="invalid-feedback d-block" role="alert" id="hari_lahirError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Tempat Lahir <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" class="form-control" id="tempat_lahir" name="tempat_lahir">
			<span class="invalid-feedback d-block" role="alert" id="tempat_lahirError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Tanggal Lahir <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir">
			<span class="invalid-feedback d-block" role="alert" id="tanggal_lahirError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Jam/Pukul <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="time" class="form-control" id="jam_lahir" name="jam_lahir">
			<span class="invalid-feedback d-block" role="alert" id="jam_lahirError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<h5>2. Data Istri (dari seorang ibu)</h5>
	</div>
	<div class="row">
		<label class="col-sm-3">Nama Lengkap <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" class="form-control" id="nama_ibu" name="nama_ibu">
			<span class="invalid-feedback d-block" role="alert" id="nama_ibuError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">NIK/No KTP <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="number" class="form-control" id="nik_ibu" name="nik_ibu">
			<span class="invalid-feedback d-block" role="alert" id="nik_ibuError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Umur <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="number" class="form-control" id="umur_ibu" name="umur_ibu">
			<span class="invalid-feedback d-block" role="alert" id="umur_ibuError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Pekerjaan <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" class="form-control" id="pekerjaan_ibu" name="pekerjaan_ibu">
			<span class="invalid-feedback d-block" role="alert" id="pekerjaan_ibuError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Alamat/Tempat Tinggal <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" class="form-control" id="alamat_ibu" name="alamat_ibu">
			<span class="invalid-feedback d-block" role="alert" id="alamat_ibuError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<h5>3. Data Suami (istri dari)</h5>
	</div>
	<div class="row">
		<label class="col-sm-3">Nama Lengkap <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" class="form-control" id="nama_ayah" name="nama_ayah">
			<span class="invalid-feedback d-block" role="alert" id="nama_ayahError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">NIK <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="number" class="form-control" id="nik_ayah" name="nik_ayah">
			<span class="invalid-feedback d-block" role="alert" id="nik_ayahError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Umur <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="number" class="form-control" id="umur_ayah" name="umur_ayah">
			<span class="invalid-feedback d-block" role="alert" id="umur_ayahError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Pekerjaan <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" class="form-control" id="pekerjaan_ayah" name="pekerjaan_ayah">
			<span class="invalid-feedback d-block" role="alert" id="pekerjaan_ayahError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Alamat <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" class="form-control" id="alamat_ayah" name="alamat_ayah">
			<span class="invalid-feedback d-block" role="alert" id="alamat_ayahError">
				<strong></strong>
			</span>
		</div>
	</div>
</div>
<div class="col-xl-12 mt-3">
	<label>Berkas Persyaratan (jadikan 1 file PDF) <span class="text-danger">*</span></label>
	<div class="form-group position-relative">
		<input type="file" name="berkas" id="berkas" class="form-control">
		<span class="invalid-feedback" role="alert" id="berkasError">
			<strong></strong>
		</span>
	</div>
</div>
<?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ladar\resources\views/page/pengaju/request/SURAT_KETERANGAN_KELAHIRAN/skk_1_form.blade.php ENDPATH**/ ?>