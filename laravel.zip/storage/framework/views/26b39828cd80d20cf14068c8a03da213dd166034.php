<div class="col-xl-12">
	<label>Berkas Persyaratan <span class="text-danger">*</span></label>
	<div class="form-group position-relative">
		<input type="file" name="berkas" id="berkas" class="form-control">
		<span class="invalid-feedback" role="alert" id="berkasError">
			<strong></strong>
		</span>
	</div>
</div><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/page/pengaju/request/SURAT_KETERANGAN_USAHA/sku_2_form.blade.php ENDPATH**/ ?>