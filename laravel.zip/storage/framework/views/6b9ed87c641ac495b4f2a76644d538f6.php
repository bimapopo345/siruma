

<?php $__env->startSection('title','Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h3>Dashboard Desa</h3>
</div>
<div class="page-content">
    <section class="row">
        <div class="col-12 col-xl-12">
            <div class="row">
                <div class="col-lg-3 mt-2">
                  <div class="card">
                    <div class="card-body">
                      <div class="card-title d-flex align-items-start justify-content-between">
                        <div class="avatar flex-shrink-0">
                            <i class="bx bx-user" style="font-size: 0.5in;"></i>
                        </div>
                        <div class="dropdown">
                          <button
                          class="btn p-0"
                          type="button"
                          id="cardOpt3"
                          data-bs-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                          >
                          <i class="bx bx-dots-vertical-rounded"></i>
                      </button>
                      <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt3">
                        <a class="dropdown-item" href=" <?php echo e(route('data_user','Pengaju')); ?> ">Lihat Detail</a>
                    </div>
                </div>
            </div>
            <span class="fw-semibold d-block mb-1">User Pengaju</span>
            <h3 class="card-title mb-2"><?php echo e($pengaju); ?></h3>
        </div>
    </div>
</div>
<div class="col-lg-3 mt-2">
  <div class="card">
    <div class="card-body">
      <div class="card-title d-flex align-items-start justify-content-between">
        <div class="avatar flex-shrink-0">
            <i class="bx bx-user" style="font-size: 0.5in;"></i>
        </div>
        <div class="dropdown">
          <button
          class="btn p-0"
          type="button"
          id="cardOpt3"
          data-bs-toggle="dropdown"
          aria-haspopup="true"
          aria-expanded="false"
          >
          <i class="bx bx-dots-vertical-rounded"></i>
      </button>
      <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt3">
        <a class="dropdown-item" href=" <?php echo e(route('data_user','Pengurus')); ?> ">Lihat Detail</a>
    </div>
</div>
</div>
<span class="fw-semibold d-block mb-1">User Pengurus</span>
<h3 class="card-title mb-2"><?php echo e($pengurus); ?></h3>
</div>
</div>
</div>
<div class="col-lg-3 mt-2">
  <div class="card">
    <div class="card-body">
      <div class="card-title d-flex align-items-start justify-content-between">
        <div class="avatar flex-shrink-0">
            <i class="bx bx-file" style="font-size: 0.5in;"></i>
        </div>
        <div class="dropdown">
          <button
          class="btn p-0"
          type="button"
          id="cardOpt3"
          data-bs-toggle="dropdown"
          aria-haspopup="true"
          aria-expanded="false"
          >
          <i class="bx bx-dots-vertical-rounded"></i>
      </button>
      <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt3">
        <a class="dropdown-item" href=" <?php echo e(route('data_surat')); ?> ">Lihat Detail</a>
    </div>
</div>
</div>
<span class="fw-semibold d-block mb-1">Layanan Surat</span>
<h3 class="card-title mb-2"><?php echo e($surat); ?></h3>
</div>
</div>
</div>
<div class="col-lg-3 mt-2">
  <div class="card">
    <div class="card-body">
      <div class="card-title d-flex align-items-start justify-content-between">
        <div class="avatar flex-shrink-0">
            <i class="bx bx-time" style="font-size: 0.5in;"></i>
        </div>
        <div class="dropdown">
          <button
          class="btn p-0"
          type="button"
          id="cardOpt3"
          data-bs-toggle="dropdown"
          aria-haspopup="true"
          aria-expanded="false"
          >
          <i class="bx bx-dots-vertical-rounded"></i>
      </button>
      <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt3">
        <a class="dropdown-item" href=" <?php echo e(route('waktu_layanan')); ?> ">Lihat Detail</a>
    </div>
</div>
</div>
<span class="fw-semibold d-block mb-1">Waktu Pelayanan</span>
<h3 class="card-title mb-2"><?php echo e($layanan); ?></h3>
</div>
</div>
</div>
<div class="col-lg-3 mt-2">
  <div class="card">
    <div class="card-body">
      <div class="card-title d-flex align-items-start justify-content-between">
        <div class="avatar flex-shrink-0">
            <i class="bx bx-note" style="font-size: 0.5in;"></i>
        </div>
        <div class="dropdown">
          <button
          class="btn p-0"
          type="button"
          id="cardOpt3"
          data-bs-toggle="dropdown"
          aria-haspopup="true"
          aria-expanded="false"
          >
          <i class="bx bx-dots-vertical-rounded"></i>
      </button>
      <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt3">
        <a class="dropdown-item" href=" <?php echo e(route('prosedur')); ?> ">Lihat Detail</a>
    </div>
</div>
</div>
<span class="fw-semibold d-block mb-1">Prosedur Pengajuan</span>
<h3 class="card-title mb-2"><?php echo e($prosedur); ?></h3>
</div>
</div>
</div>


</div>

</div>
</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/desa/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ladar\resources\views/page/desa/dashboard/dashboard.blade.php ENDPATH**/ ?>