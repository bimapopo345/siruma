<!DOCTYPE html>
<html>
<head>
    <meta property="og:image" content="<?php echo e(asset('logo/WEB SURAT.jpg')); ?>">
    <title>PENDAFTARAN DESA/KELURAHAN</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('template/daftar/bostrap.min.css')); ?>">
    <link rel="stylesheet" href=
    "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.css">
</link>
<script type="text/javascript" src="<?php echo e(asset('template/daftar/bundle.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('template/daftar/jquery.min.js')); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('template/daftar/style.css')); ?>">
<link rel="shortcut icon" type="image/x-generic" href="<?php echo e(asset('logo/WEB SURAT.jpg')); ?>">

</head>
<body style="background: #435ebe;">
   <div itemprop="image" itemscope="itemscope" itemtype="http://schema.org/ImageObject">
      <meta content="<?php echo e(asset('logo/WEB SURAT.jpg')); ?>" itemprop="url"/> </div>
      <!-- MultiStep Form -->
      <div class="container-fluid" id="grad1">
        <div class="row justify-content-center mt-0">
            <div class="col-11 col-sm-9 col-md-7 col-lg-8 text-center p-0 mt-3 mb-2" id="msform">
                <div class="card px-0 pt-4 pb-0 mt-3 mb-3">
                    <h2><strong>Pendaftaran Desa</strong></h2>
                    <p>Lengkapi data - data di bawah</p>
                    <div class="row">
                        <div class="col-md-12 mx-0">
                            <!-- progressbar -->
                            <ul id="progressbar">
                                <li class="active" id="account"><strong>Lokasi</strong></li>
                                <li id="personal"><strong>Informasi</strong></li>
                                <li id="payment"><strong>Dokumen</strong></li>
                            </ul> <!-- fieldsets -->
                            <fieldset>
                                <div class="form-card">
                                    <h2 class="fs-title">Pilih Daerah/Kelurahan anda <a href="<?php echo e(route('pendaftaran',$url_kode)); ?>" class="btn btn-sm btn-primary" style="float: right;">Refresh</a></h2> 
                                    <?php if(empty($_GET['state'])): ?>
                                    <form method="GET" action="">
                                        <?php echo csrf_field(); ?>
                                        <label>Provinsi</label>
                                        <select id="country" required="" name="country" class="form-control">
                                            <option value="" selected disabled>-- PILIH PROVINSI --</option>
                                            <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($prc->code); ?>"> <?php echo e($prc->name_province); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label>Kota</label>
                                        <select name="state" required="" id="state" class="form-control"></select>
                                        <button class="btn btn-sm btn-danger mt-3">Lanjut</button>
                                    </form>
                                    <?php endif; ?>
                                    <form method="post" enctype="multipart/form-data" action="<?php echo e(route('tambah_pendaftaran',$url_kode)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php if(!empty($_GET['state'])): ?>
                                        <?php  
                                        $daerah=DB::table('indonesia_districts')->get();
                                        $kotaku=DB::table('indonesia_cities')->get();
                                        ?>
                                        <label>Provinsi</label>
                                        <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($key->code==$_GET['country']): ?>
                                        <input type="text" readonly="" value="<?php echo e($key->name_province); ?>" name="">
                                        <input type="hidden" readonly="" value="<?php echo e($key->code); ?>" name="province">
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <label>Kota</label>
                                        <?php $__currentLoopData = $kotaku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ktk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($ktk->code==$_GET['state']): ?>
                                        <input type="text" readonly="" value="<?php echo e($ktk->name_city); ?>" name="">
                                        <input type="hidden" readonly="" value="<?php echo e($ktk->code); ?>" name="city">
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <label>Kecamatan</label>
                                        <select class="form-control" required="" name="district" id="kec">
                                            <option>-- PILIH KECAMATAN --</option>
                                            <?php $__currentLoopData = $daerah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($dr->city_code==$_GET['state']): ?>
                                            <option value="<?php echo e($dr->code); ?>"><?php echo e($dr->name_district); ?></option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label class="text mt-3">Kel/Desa</label>
                                        <select class="form-control mb-3" required="" name="village" id="desa">
                                        </select>
                                    </div> 
                                    <input type="button" name="next" class="next action-button" value="Lanjut" />
                                </fieldset>
                                <fieldset>
                                    <div class="form-card">
                                        <h2 class="fs-title">Informasi Data Kelurahan</h2> 
                                        <input type="text" required="" name="email" placeholder="Email" /> 
                                        <input type="password" required="" name="password" placeholder="Password" /> 
                                        <input type="number" required="" name="telepon_desa" placeholder="Contact No." /> 
                                        <label>Alamat Kantor Kelurahan</label>
                                        <textarea class="form-control" rows="5" required="" name="lokasi_desa" autocomplete="off"></textarea>
                                    </div> <input type="button" name="previous" class="previous action-button-previous" value="Kembali" /> <input type="button" name="next" class="next action-button" value="Lanjut" />
                                </fieldset>
                                <fieldset>
                                    <div class="form-card">
                                        <h2 class="fs-title">Upload dokumen Kelurahan <sup>(image/pdf)</sup></h2> 
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="imgPreview">
                                                    <div class="form-group">
                                                        <input type="file" name="file" required="" autocomplete="off" class="form-control input-file" onchange="readURL(this);">
                                                        <sup class="text text-info">Format file yang disarankan : jpg, jpeg, pdf dan ukuran maks 2MB</sup>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div> 
                                    <!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script> -->
                                    <input type="button" name="previous" class="previous action-button-previous" value="Kembali" />
                                    <button type="submit" name="make_payment" class="btn btn-lg btn-danger" onclick="return confirm('Lanjut melakukan pendaftaran')">Konfirmasi</button>
                                </form>
                                <?php endif; ?>

                            </fieldset>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade text-left" id="rideimage" data-bs-backdrop="static" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel1">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-sm" role="document">
      <div class="modal-content">
        <div class="modal-body">
          <div class="row">
            <div class="col-12 text-center">
             <a href="javascript:void(0)" style="float: right;" class="close"
             data-bs-dismiss="modal" aria-label="Close">
             <i class="fa fa-close"></i>
         </a>
         Preview Image
         <hr>
     </div>
     <div class="col-12 text-center">
      <img class="file-upload-image img-thumbnail w-100" style="height: auto;" src="#" alt="your image" />
  </div>
</div>
</div>
</div>
</div>
</div>
<div class="modal fade text-left" id="ridedocument" data-bs-backdrop="static" tabindex="-1" role="dialog"
aria-labelledby="myModalLabel1">
<div class="modal-dialog modal-dialog-scrollable modal-lg" role="document">
  <div class="modal-content">
    <div class="modal-body">
      <div class="row">
        <div class="col-12 text-center">
         <a href="javascript:void(0)" style="float: right;" class="close"
         data-bs-dismiss="modal" aria-label="Close">
         <i class="fa fa-close"></i>
     </a>
     Preview Dokumen
     <hr>
 </div>
 <div class="col-12 text-center">
  <embed src="#" class="file-upload-document" height="650" width="100%"></embed>
</div>
</div>
</div>
</div>
</div>
</div>

</body>
<script type="text/javascript" src="<?php echo e(asset('template/daftar/ajax.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js" integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS" crossorigin="anonymous"></script>
<script>
        // when country dropdown changes
        $('#country').change(function() {

            var countryID = $(this).val();

            if (countryID) {

                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('pendaftaran-desa/getState',$url_kode)); ?>?country_id=" + countryID,
                    success: function(res) {

                        if (res) {

                            $("#state").empty();
                            $("#state").append('<option>-- PILIH KOTA --</option>');
                            $.each(res, function(key, value) {
                                $("#state").append('<option value="' + value.code + '">' + value.name_city +
                                    '</option>');
                            });

                        } else {

                            $("#state").empty();
                        }
                    }
                });
            } else {

                $("#state").empty();
            }
        });
    </script>
    <script>
        // when country dropdown changes
        $('#kec').change(function() {

            var districtID = $(this).val();

            if (districtID) {

                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('pendaftaran-desadua/getState',$url_kode)); ?>?district_code=" + districtID,
                    success: function(res) {

                        if (res) {

                            $("#desa").empty();
                            $("#desa").append('<option>-- PILIH DESA/KELURAHAN --</option>');
                            $.each(res, function(key, value) {
                                $("#desa").append('<option value="' + value.code + '">' + value.name_village +
                                    '</option>');
                            });

                        } else {

                            $("#desa").empty();
                        }
                    }
                });
            } else {

                $("#desa").empty();
            }
        });
    </script>
    <script src="<?php echo e(asset('template/dist/assets/js/extensions/sweetalert2.js')); ?>"></script>
    <script src="<?php echo e(asset('green/assets/js/not.js')); ?>"></script>
    <script src="<?php echo e(asset('green/assets/js/disabledi.js')); ?>"></script>
    <script src="<?php echo e(asset('green/assets/js/default.js')); ?>"></script>
    <script src="<?php echo e(asset('template/dist/assets/vendors/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
    <?php if(session('digunakan')): ?>
    <script type="text/javascript">
        document.getElementById('warning');
        Swal.fire({
            icon: "warning",
            title: "Wilayah Tersedia",
            text: "Wilayah sudah Terdaftar dalam Data.",
        });
    </script>
    <?php endif; ?>
    <?php if(session('coba')): ?>
    <script type="text/javascript">
        document.getElementById('warning');
        Swal.fire({
            icon: "warning",
            title: "Coba Lagi",
            text: "Coba lagi nanti untuk mendaftar.",
        });
    </script>
    <?php endif; ?>

    <script>
        function readURL(input) {
          if (input.files && input.files[0]) {

            var reader = new FileReader();
            if (input.files[0].size > 2048576) {
              alert('Ukuran File tidak boleh lebih dari 2MB');
              $('.input-file').val('');
          }else{
              reader.onload = function(e) {
                $('.image-upload-wrap').hide();
                $('.file-upload-content').show();

                $('.image-title').html(input.files[0].name);

                let cek = input.files[0].name;
                if (cek.substr(-3) == 'png' || cek.substr(-3) == 'jpg' || cek.substr(-3) == 'PNG' || cek.substr(-3) == 'JPG') {
            // alert('3 text')
            $("#rideimage").modal('show');
            $('.file-upload-image').attr('src', e.target.result);
            // $('.file-upload-document').hide();
        }else if(cek.substr(-4) == 'jpeg' || cek.substr(-4) == 'JPEG'){
            // alert('4 text')
            $("#rideimage").modal('show');
            $('.file-upload-image').attr('src', e.target.result);
            // $('.file-upload-document').hide();
        }else if(cek.substr(-3) == 'pdf' || cek.substr(-3) == 'PDF'){
            // alert('3 text pdf')
            $("#ridedocument").modal('show');
            $('.file-upload-document').attr('src', e.target.result);
            // $('.file-upload-image').hide();
        }else{
            $('.input-file').val('');
            alert('Format file yang anda masukkan tidak di dukung')
        }
    };

}
        // alert(input.files[0].name);
        reader.readAsDataURL(input.files[0]);

    } else {
        removeUpload();
    }
}
function removeUpload() {
  $('.file-upload-input').replaceWith($('.file-upload-input').clone());
  $('.file-upload-content').hide();
  $('.image-upload-wrap').show();
}
$('.image-upload-wrap').bind('dragover', function () {
  $('.image-upload-wrap').addClass('image-dropping');
});
$('.image-upload-wrap').bind('dragleave', function () {
  $('.image-upload-wrap').removeClass('image-dropping');
});
</script>
</html><?php /**PATH E:\xampp\htdocs\produk-web\desa\resources\views/pendaftaran.blade.php ENDPATH**/ ?>