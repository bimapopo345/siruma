

<?php $__env->startSection('title','Link Pendaftaran Desa'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <section class="section">
        <div class="card">
            <div class="card-header">
                Table Pendaftaran Desa
                <a href="<?php echo e(route('addurl')); ?>" class="btn btn-sm btn-primary rounded-pill" style="float: right;"><i class="fa fa-plus"></i></a>
            </div>
            <div class="card-body">
                <table class="table table-bordered" id="table1">
                    <thead>
                        <tr>
                            <th>URL</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><a href="<?php echo e(route('pendaftaran',$dt->url_kode)); ?>" target="_blank"><span class="badge form-control bg-success"><?php echo e($dt->url_kode); ?></span></a></td>
                            <td>
                                <a href="<?php echo e(route('delurl',$dt->url_kode)); ?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/desa/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/page/admin/link.blade.php ENDPATH**/ ?>