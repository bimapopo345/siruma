<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta property="og:image" content="<?php echo e(asset('logo/WEB SURAT.jpg')); ?>">
  <title>Web Surat Permohonan Digital - Surat Pengajuan Desa - Multi Desa</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link rel="shortcut icon" type="image/x-generic" href="<?php echo e(asset('logo/WEB SURAT.jpg')); ?>">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo e(asset('green/assets/vendor/animate.css/animate.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('green/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('green/assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('green/assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('green/assets/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('green/assets/vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">    

  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('green/assets/css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('green/assets/css/styletwo.css')); ?>" rel="stylesheet">

</head>
<style type="text/css">
#masuk:hover{
  color:#435ebe;
}
</style>
<body>
 <div itemprop="image" itemscope="itemscope" itemtype="http://schema.org/ImageObject">
  <meta content="<?php echo e(asset('logo/WEB SURAT.jpg')); ?>" itemprop="url"/> </div>
  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="" style="color: #435ebe">WEB SURAT</a></h1>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Beranda</a></li>
          <li><a class="nav-link scrollto" href="#about">Panduan Daftar</a></li>
          <li><a class="nav-link scrollto" href="#why-us">Format Surat</a></li>
          <li><a class="nav-link scrollto " href="#cta">Masuk</a></li>
          <li><a class="nav-link scrollto" href="#contact">Scan Masuk</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">


      <div class="carousel-inner" role="listbox">

        <!-- Slide 1 -->
        <div class="carousel-item active">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">WEB SURAT <span>PERMOHONAN</span></h2>
              <p class="animate__animated animate__fadeInUp">Selamat datang di Web Surat Permohonan/Pengajuan Desa - Multi Kantor Kelurahan/Desa</p>
              <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Baca Panduan</a>
            </div>
          </div>
        </div>

        <!-- Slide 2 -->

      </div>

    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Featured Services Section ======= -->
    <section id="featured-services" class="featured-services section-bg">

      <div class="container">

        <div class="row no-gutters">
          <div class="col-lg-4 col-md-6">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-pencil-square"></i></div>
              <h4 class="title">Tanda Tangan Digital</h4>
              <p class="description">Dalam sistem Web Surat Permohonan telah di siapkan Tanda Tangan Digital untuk Surat Ajuan.</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-file-pdf"></i></div>
              <h4 class="title">Pengambilan Online</h4>
              <p class="description">Pengambilan Surat Ajuan bisa di lakukan secara Online dengan Mendownload File Surat ketika Sudah siap di berikan.</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-qr-code"></i></div>
              <h4 class="title">QR Code</h4>
              <p class="description">Di sediakan Poster QR Code per Kantor Kelurahan/Desa yang mendaftar. Masuk ke desa dengan Scan QR Code atau Kode Akses Desa.</p>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Featured Services Section -->

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2>Panduan Pendaftaran</h2>
        </div>

        <div class="row">
          <div class="col-xl-12 pt-4 content">
            <p class="fst-italic">
              Panduan Pendaftaran Kantor Kelurahan/Desa :
            </p>
            <ul>
              <li><i class="bi bi-check-circled"></i> 1. Buat Kode Pendaftaran Desa/Kelurahan klik link di samping dan masukkan email pendaftaran.<b>
                <a href="javascript:void(0)" id="mail" onclick="mail()" style="font-family: times new roman;color: #435ebe;">
                  Klik di sini
                </a>
              </b></li>
              <li><i class="bi bi-check-circled"></i> 2. Setelah link Pendaftaran berhasil di Akses, isikan Data Kantor Kelurahan Anda.</li>
              <li><i class="bi bi-check-circled"></i> 3. Pastikan Data dan berkas-berkas benar dan sesuai dengan Kantor Kelurahan yang terdaftar, guna Admin mempermudah Verifikasi</li>
              <li><i class="bi bi-check-circled"></i> 4. Cek Email yang di gunakan untuk mendaftar untuk Info Verifikasi dan Informasi Data Data Desa.</li>
              <li><i class="bi bi-check-circled"></i> 5. Setelah Pendaftaran berhasil di Verifikasi oleh Admin, anda akan di berikan Kode Akses dan Qr Code untuk masuk ke Halaman Desa masing-masing.</li>
              <li><i class="bi bi-check-circled"></i> 6. Bagikan Kode Akses/QR Code ke Warga Desa untuk mengajukan Permohonan Surat.</li>
            </ul>
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us">
      <div class="container">

        <div class="row no-gutters text-center">

          <div class="col-lg-4 col-md-6 content-item">
            <span>FORMAT SURAT</span>
            <h4>01</h4>
            <p><a href="<?php echo e(asset('template-surat/61f7bdc4d3079TESTER 1.pdf')); ?>" target="_blank" style="color: #f73859">Cek Format Surat di sini</a> <br> Standar untuk di gunakan semua Surat</p>
          </div>

          <div class="col-lg-4 col-md-6 content-item">
            <span>FORMAT SURAT</span>
            <h4>02</h4>
            <p><a href="<?php echo e(asset('template-surat/61f7bdcddcf3aTESTER 2.pdf')); ?>" target="_blank" style="color: #f73859">Cek Format Surat di sini</a> <br> Standar untuk di gunakan semua Surat</p>
          </div>

          <div class="col-lg-4 col-md-6 content-item">
            <span>FORMAT SURAT</span>
            <h4>03</h4>
            <p><a href="<?php echo e(asset('template-surat/61f7cd2d38e84TESTER 3.pdf')); ?>" style="color: #f73859">Cek Format Surat di sini</a> <br> Standar untuk di gunakan Surat Pengantar SKCK</p>
          </div>

          <div class="col-lg-4 col-md-6 content-item">
            <span>FORMAT SURAT</span>
            <h4>03</h4>
            <p><a href="<?php echo e(asset('template-surat/61f7d78f937d8TESTER 4.pdf')); ?>" style="color: #f73859">Cek Format Surat di sini</a> <br> Standar untuk di gunakan Surat Pengantar SKCK</p>          </div>

          </div>

        </div>
      </section><!-- End Why Us Section -->

      <!-- ======= Cta Section ======= -->
      <section id="cta" class="cta">
        <div class="container">

          <div class="row">
            <div class="col-lg-9 text-center text-lg-start">
              <h3>Masukkan Kode Akses</h3>
              <p>Masuk ke Halaman menggunakan Kode Akses. Cek Kode Akses kamu ada di Email yang terkirim. <br> Klik tombol di samping untuk masuk</p>
            </div>
            <div class="col-lg-3 cta-btn-container text-center">
              <a class="cta-btn align-middle" onclick="masuk()" id="masuk">Masuk</a>
            </div>
          </div>

        </div>
      </section><!-- End Cta Section -->

      <!-- ======= Contact Section ======= -->
      <section id="contact" class="contact">
        <div class="container">

          <div class="section-title">
            <h2>Scan QR Code</h2>
            <p>Masuk ke Halaman dengan Scan QR Code kamu, akan di arahkan ke Halaman masing-masing</p>
          </div>

          <div class="row">
            <script src="<?php echo e(asset('scankode.min.js')); ?>" type="text/javascript"></script>
            <div class="col-xl-12 mt-5 mt-xl-0 d-flex align-items-stretch">
              <form action="" method="post" role="form" class="php-email-form">
                <div class="row" id="reader">
                </form>
              </div>

            </div>

          </div>
        </section><!-- End Contact Section -->

      </main><!-- End #main -->

      <!-- ======= Footer ======= -->
      <footer id="footer">
        <div class="container">
          <h3>DIGITAL SURAT PERMOHONAN</h3>
          <p>Web Surat Permohonan Digital Kantor Kelurahan/Desa - Aplikasi Surat Pengajuan/Permohonan Desa<br> Multi Desa</p>
          <div class="credits">
            Powered by <a href="https://danteproject.site/" style="color: #435ebe;">DANTE PROJECT</a>
          </div>
        </div>
      </footer><!-- End Footer -->

      <a href="https://www.facebook.com/plugins/video.php?height=314&href=https%3A%2F%2Fweb.facebook.com%2Fdanteprojectgroup%2Fvideos%2F1433367563843258%2F&show_text=true&width=560&t=0" target="_blank" class="back-to-top d-flex align-items-center justify-content-center btn-danger"><i class="bi bi-play"></i></a>

      <!-- Vendor JS Files -->
      <script src="<?php echo e(asset('green/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
      <script src="<?php echo e(asset('green/assets/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
      <script src="<?php echo e(asset('green/assets/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
      <script src="<?php echo e(asset('green/assets/vendor/php-email-form/validate.js')); ?>"></script>
      <script src="<?php echo e(asset('green/assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
      <script src="<?php echo e(asset('template/dist/assets/js/extensions/sweetalert2.js')); ?>"></script>
      <script src="<?php echo e(asset('template/dist/assets/vendors/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <!-- Template Main JS File -->
      <script src="<?php echo e(asset('green/assets/js/main.js')); ?>"></script>
      <script type="text/javascript">
        function masuk() {
          Swal.fire({
            title: 'Masuk ke Desa',
            html: `
            <input type="text" id="title_user" autocomplete="off" title="Kode Akses Desa" class="swal2-input" placeholder="Kode Akses">
            <a href="javascript:void(0)" onclick="kirim()" class="btn text-white" style="background: #435ebe;">Masuk</a>
            `,
            showConfirmButton: false,
          });
        }
      </script>
      <script type="text/javascript">
        function mail() {
          Swal.fire({
            title: 'Buat Kode Akses Pendaftaran',
            html: `
            <input type="text" id="email" autocomplete="off" title="E-mail anda" class="swal2-input" placeholder="E-Mail anda ...">
            <a href="javascript:void(0)" onclick="add()" class="btn text-white" style="background: #435ebe;">Kirim</a>
            `,
            showConfirmButton: false,
          });
        }
      </script>
    </body>
    <script type="text/javascript">
      function kirim() {
        var kode=$('#title_user').val();
        $.ajax({
          url : "<?php echo e(route('masuk')); ?>",
          type : 'POST',
          data : {
            '_method' : 'POST',
            '_token' : '<?php echo e(csrf_token()); ?>',
            'kode' : kode
          },
          success: function(response) {
            if (response.masuk) {
              window.location = "<?php echo e(url('/')); ?>"+"/"+kode;
            }
            if (response.notmasuk) {
             Swal.fire({
              icon: 'error',
              title: 'Kode Salah',
              text: 'Kode Akses anda tidak sesuai',
              showConfirmButton: false,
              timer: 1500
            }).then((result) => {
              masuk();
            });
          }
          if (response.kosong) {
           Swal.fire({
            icon: 'warning',
            title: 'Input Kode',
            text: 'Harap masukkan Kode Akses anda.',
            showConfirmButton: false,
            timer: 1300
          }).then((result) => {
            masuk();
          });
        }
      }
    });     
      }
    </script>
    <script type="text/javascript">
      function add() {
        var email=$('#email').val();
        var atps=email.indexOf("@");
        var dots=email.lastIndexOf(".");
        if (email=='') {
         Swal.fire({
          icon: 'info',
          title: 'Input Email',
          text: 'Harap masukkan Email anda.',
          showConfirmButton: false,
          timer: 1300
        }).then((result) => {
          mail();
        });
      }else{
       if (atps<1 || dots<atps+2 || dots+2>=email.length) {
        Swal.fire({
          icon: 'info',
          title: 'Tidak Valid',
          text: 'Masukkan Email anda dengan Benar dan Valid.',
          showConfirmButton: false,
          timer: 1800
        }).then((result) => {
          mail();
        });
      }else{
        $.ajax({
          url : "<?php echo e(route('buat_kode')); ?>",
          type : 'POST',
          data : {
            '_method' : 'POST',
            '_token' : '<?php echo e(csrf_token()); ?>',
            'email' : email
          },
          success: function(response) {
            if (response.yes) {
              Swal.fire({
                icon: 'success',
                title: 'Kode Terkirim',
                text: 'Cek E-mail anda untuk Kode Akses Pendaftaran.',
                showConfirmButton: false,
                timer: 1800
              });
            }
            if (response.repeat) {
              Swal.fire({
                icon: 'warning',
                title: 'Kode Sudah di Buat',
                text: 'Anda sudah melakukan Registrasi Kode Pendaftaran Kantor Kelurahan/Desa.',
                // showConfirmButton: false,
                // timer: 1800
              });
            }
          }
        });     
      }
    }
  }
</script>
<script type="text/javascript">

  function onScanSuccess(decodedText, decodedResult) {
    var result = $("#result").val(decodedText);
    let keyword = decodedText
    html5QrcodeScanner.clear();

    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    });
    csrf_token = $('meta[name="csrf-token"]').attr('content');
    let timerInterval
    Swal.fire({
      title: 'Proses Scan',
      html: 'Sedang melakukan Pengecekan',
      timer: 1500,
      timerProgressBar: true,
      didOpen: () => {
        Swal.showLoading()
        const b = Swal.getHtmlContainer().querySelector('b')
        timerInterval = setInterval(() => {
          b.textContent = Swal.getTimerLeft()
        }, 50)
      },
      willClose: () => {
        clearInterval(timerInterval)
      }
    }).then((result) => {

      $.ajax({
        url : "<?php echo e(route('validasiqrcode')); ?>",
        type : 'POST',
        data : {
          '_method' : 'POST',
          '_token' : '<?php echo e(csrf_token()); ?>',
          'keyword' : keyword
        },
        success: function(response) {
          if (response.status_error) {
            Swal.fire({
              icon: "error",
              title: "Gagal Scan",
              text: "Maaf QR CODE Tidak di temukan",
              showConfirmButton: false,
              timer: 1500
            }).then((result) => {
              new Html5QrcodeScanner(
                "reader", { fps: 10, qrbox: 250 });
              html5QrcodeScanner.render(onScanSuccess);
            });
          }
          if (response.berhasil) {    
            window.location = "<?php echo e(url('/')); ?>"+"/"+keyword;
          }
        },
        error: function(xhr) {
          Swal.fire({
            icon: "error",
            type: "error",
            title: "Gagal Scan!",
            text: "Silahkan mengulangi Scan anda"
          });
        }
      });     
    })

  }
  var html5QrcodeScanner = new Html5QrcodeScanner(
    "reader", { fps: 10, qrbox: 250 });
  html5QrcodeScanner.render(onScanSuccess);

</script>

<?php if(session('yes')): ?>
<script type="text/javascript">
  document.getElementById('success');
  Swal.fire({
    icon: "success",
    title: "Register Berhasil",
    text: "Tunggu Konfirmasi dari Pihak Admin melalui Email.",
  });
</script>
<?php endif; ?>
</html><?php /**PATH E:\xampp\htdocs\PRODUK WEB\desa\resources\views/index.blade.php ENDPATH**/ ?>