

<?php $__env->startSection('title','Cek Berkas Pendaftaran Desa'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content">
    <section class="row">
       <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="">Desa Pendaftar</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Preview & Validasi</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-8">

        <div class="card">
            <div class="card-content">
                <div class="card-body">
                    <div class="form-body">
                        <div class="row">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12">
                                <div class="form-group">
                                    <a href="<?php echo e(route('setuju',$dt->id_profil)); ?>" class="btn btn-sm btn-outline-success rounded-pill mt-2 form-control"> <i class="icon dripicons-checkmark"></i> Confirm </a>
                                </div>
                            </div>
                            <div class="col-12 mb-3">
                                <div class="form-group">
                                    <a href="<?php echo e(route('tolak',$dt->id_profil)); ?>" class="btn btn-sm btn-outline-danger rounded-pill mt-2 form-control"> <i class="icon dripicons-trash"></i> Tolak </a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <hr>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="email-id-vertical">Email</label>
                                    <p><?php echo e($dt->email_desa); ?></p>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="email-id-vertical">Telepon</label>
                                    <p><?php echo e($dt->telepon_desa); ?></p>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="email-id-vertical">Kode Desa</label>
                                    <p><?php echo e($dt->kode_desa); ?></p>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="email-id-vertical">Provinsi</label>
                                    <p><?php echo e($dt->name_province); ?></p>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="email-id-vertical">Kota</label>
                                    <p><?php echo e($dt->name_city); ?></p>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="email-id-vertical">Kecamatan</label>
                                    <p><?php echo e($dt->name_district); ?></p>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="email-id-vertical">Desa</label>
                                    <p><?php echo e($dt->name_village); ?></p>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="email-id-vertical">Alamat</label>
                                    <p><?php echo e($dt->lokasi_desa); ?></p>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="email-id-vertical">Logo</label>
                                    <?php if($dt->logo != NULL): ?>
                                    <p><img src="<?php echo e(asset('foto')); ?>/<?php echo e($dt->logo); ?>" width="100"></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="email-id-vertical">Link url</label>
                                    <p><a href="<?php echo e(route('home_desa',$dt->kode_desa)); ?>" target="_blank">Cek Desa</a></p>
                                </div>
                            </div>
                            <hr>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="email-id-vertical">Status Berkas</label>
                                    <p><?php if($dt->status_berkas=="Pending"): ?>
                                        <span class="badge bg-danger"><?php echo e($dt->status_berkas); ?></span>
                                        <?php else: ?>
                                        <span class="badge bg-success"><?php echo e($dt->status_berkas); ?></span>
                                    <?php endif; ?></p>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="email-id-vertical">Status Desa</label>
                                    <p><?php if($dt->status_desa=="A"): ?>
                                        <span class="badge bg-primary">Aktif</span>
                                        <?php else: ?>
                                        <span class="badge bg-danger">Non Aktif</span>
                                    <?php endif; ?></p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="col-12 col-lg-4">
        <div class="card">
            <div class="card-content">
                <div class="card-body">
                    <h4 class="card-title">Berkas Pengajuan</h4>
                    <hr>
                    <div class="form-body">
                        <?php $__currentLoopData = $berkas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row mt-2">
                            <a href="<?php echo e(asset('berkas-daftar')); ?>/<?php echo e($brk->berkas_daftar); ?>" class="btn btn-sm btn-primary" target="_blank">Cek Berkas</a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/desa/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/page/admin/desa/cek.blade.php ENDPATH**/ ?>