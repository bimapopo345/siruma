<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php  
$path_template_print = 'page/desa/template/'.$dt->singkatan_template.'/'.$dt->urutan_template.'/print';
?>
<?php echo $__env->make($path_template_print, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- Page Cetak Surat PDF Stream -->
<?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ladar\resources\views/page/staff/cetak/pdf.blade.php ENDPATH**/ ?>