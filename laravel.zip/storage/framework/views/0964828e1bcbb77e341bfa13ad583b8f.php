

<?php $__env->startSection('title','Dashboard Pengaju'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-title">
    <div class="row">
        <div class="col-12 col-md-6 order-md-1 order-last">
        </div>
        <div class="col-12 col-md-6 order-md-2 order-first">
            <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href=""><?php echo e(Auth::user()->name); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Surat Pengajuan tersedia</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<div class="row">
    <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-3 col-md-6 col-sm-6 mt-2">
        <div class="card" style="border: 1px solid <?php echo e($sur->bg); ?>;border-left: none;border-right: none;">
            <div class="card-content">
                <div class="card-body" style="text-align: center;">
                    <p class="text-center"><span style="text-transform: uppercase;"><?php echo e($sur->nama_surat); ?></span></p>
                    <p class="" style="border-bottom-right-radius: 40%;border-bottom-left-radius: 40%;">
                        <i class="bx bxs-file-plus" style="color: <?php echo e($sur->bg); ?>;font-size: 700%;"></i>
                    </p>
                </div>
            </div>
            <div class="card-footer" style="text-align: center">
                <a href="<?php echo e(route('request',['id_surat'=>$sur->id_surat, 'surat'=>$sur->nama_surat])); ?>" class="btn rounded-pill" style="border: 1px solid <?php echo e($sur->bg); ?>"> PENGAJUAN <i class="fa fa-arrow-up"></i> </a>
            </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item" style="background: <?php echo e($sur->bg); ?>"></li>
            </ul>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/desa/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ratdela\resources\views/page/pengaju/home/home.blade.php ENDPATH**/ ?>