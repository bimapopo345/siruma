<?php if($_GET['keyword']=="cek-surat"): ?>
<?php echo $__env->make('desa/template/1/cek', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif($_GET['keyword']=="print-surat"): ?>
<?php echo $__env->make('desa/template/1/print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<center><h1>Tidak ada data di Temukan</h1></center>
<?php endif; ?><?php /**PATH E:\xampp\htdocs\desa\resources\views/desa/template/1/1.blade.php ENDPATH**/ ?>