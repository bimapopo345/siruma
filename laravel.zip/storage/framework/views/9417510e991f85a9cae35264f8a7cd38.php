<?php if($_GET['keyword']=="cek-surat"): ?>
<?php echo $__env->make("$path_template_cek", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<center><h1>Tidak ada data di Temukan</h1></center>
<?php endif; ?><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ladar\resources\views/page/desa/template/SURAT_KETERANGAN_KELAHIRAN/SKK_1/skk_1.blade.php ENDPATH**/ ?>