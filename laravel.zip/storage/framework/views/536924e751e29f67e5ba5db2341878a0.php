<div class="col-xl-12">
	<div class="row">
		<label class="col-sm-3">Nama <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" value="<?php echo e($dt->name); ?>" readonly="" class="form-control" id="nama" name="nama">
			<span class="invalid-feedback d-block" role="alert" id="namaError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Tempat Lahir <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" value="<?php echo e($dt->tempat); ?>" readonly="" class="form-control" id="tempat_lahir" name="tempat_lahir">
			<span class="invalid-feedback d-block" role="alert" id="tempat_lahirError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Tanggal Lahir <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="date" value="<?php echo e($dt->tgl_lahir); ?>" readonly="" class="form-control" id="tanggal_lahir" name="tanggal_lahir">
			<span class="invalid-feedback d-block" role="alert" id="tanggal_lahirError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Umur <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="number" class="form-control" id="umur" name="umur">
			<span class="invalid-feedback d-block" role="alert" id="umurError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Warga negara <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" class="form-control" id="warga_negara" name="warga_negara">
			<span class="invalid-feedback d-block" role="alert" id="warga_negaraError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Agama <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" class="form-control" id="agama" name="agama">
			<span class="invalid-feedback d-block" role="alert" id="agamaError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Jenis Kelamin <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" value="<?php echo e($dt->jenis_kelamin); ?>" readonly="" class="form-control" id="jenis_kelamin" name="jenis_kelamin">
			<span class="invalid-feedback d-block" role="alert" id="jenis_kelaminError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Pekerjaan <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" class="form-control" readonly="" value="<?php echo e($dt->pekerjaan); ?>" id="pekerjaan" name="pekerjaan">
			<span class="invalid-feedback d-block" role="alert" id="pekerjaanError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Tempat Tinggal <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" value="<?php echo e($dt->alamat); ?>" readonly="" class="form-control" id="tempat_tinggal" name="tempat_tinggal">
			<span class="invalid-feedback d-block" role="alert" id="tempat_tinggalError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Surat Bukti (NO NIK) <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" class="form-control" id="no_nik" name="no_nik">
			<span class="invalid-feedback d-block" role="alert" id="no_nikError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Surat Bukti (NO KK) <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<input type="text" class="form-control" id="no_kk" name="no_kk">
			<span class="invalid-feedback d-block" role="alert" id="no_kkError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Keperluan <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<select class="form-control" required="" id="keperluan" name="keperluan">
				<option value="">:. PILIH KEPERLUAN .:</option>
				<option value="Permohonan Pembuatan KTP (Kartu Tanda Penduduk)">Permohonan Pembuatan KTP</option>
				<option value="Permohonan Pembuatan SKCK (Surat Keterangan Catatan Kepolisian)">Permohonan Pembuatan SKCK</option>
				<option value="Permohonan Pembuatan KK (Kartu Keluarga)">Permohonan Pembuatan KK</option>
			</select>
			<span class="invalid-feedback d-block" role="alert" id="keperluanError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Golongan Darah <span class="text-danger">*</span></label>
		<div class="col-sm-8">
			<!-- <input type="text" class="form-control" id="gol_darah" name="gol_darah"> -->
			<select class="form-control" id="gol_darah" name="gol_darah">
				<option value="">:. GOLONGAN DARAH .:</option>
				<option value="A">A</option>
				<option value="O">O</option>
				<option value="AB">AB</option>
				<option value="dll">Dll</option>
			</select>
			<span class="invalid-feedback d-block" role="alert" id="gol_darahError">
				<strong></strong>
			</span>
		</div>
	</div>
	<div class="row">
		<label class="col-sm-3">Berkas Persyaratan (jadikan 1 file PDF) <span class="text-danger">*</span><br>Syarat : <?php echo e($surat->persyaratan); ?></label>
		<div class="col-sm-8">
			<input type="file" class="form-control" id="berkas" name="berkas">
			<span class="invalid-feedback d-block" role="alert" id="berkasError">
				<strong></strong>
			</span>
		</div>
	</div>
</div><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ratdela\resources\views/page/pengaju/request/SURAT_KETERANGAN_PENGANTAR/skp_1_form.blade.php ENDPATH**/ ?>