<div class="container mt-3" id="content_cek" style="background: white;color: #000;">
    <div class="row">
        <div class="col-lg-2">

        </div>
        <div class="col-lg-8">
            <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="<?php echo e(asset('kop.png')); ?>" alt="avatar" class="img" style="width: 100%;">
            <br>
            <br>
            <center>
                <span style="text-transform: uppercase;font-size: 25px;letter-spacing: 4px;font-weight: bold;"><u>Surat Keterangan</u></span><br><span style="font-size: 15px;">Pengganti Kartu Tanda Mahasiswa (KTM)<br>Nomor : <?php echo e($dt->nomor_surat); ?></span>
                
            </center>
            <p class="text mt-5">
                Yang bertanda tangan dibawah ini, Wakil Dekan Sekolah Vokasi IPB Bogor, menerangkan bahwa :
            </p>
            <table border="0" style="margin-left: 10px;width: 100%;">
                <?php  
                $remark = explode(";", $dt->remark);
                $remark_1 = explode(";", $dt->remark_1);
                if ($remark[3] % 2 == 0) {
                    $semester = 'genap';
                } else {
                    $semester = 'ganjil';
                }
                ?>
                <tr>
                    <td>Nama</td>
                    <td>:</td>
                    <td><?php echo e($remark[0]); ?></td>
                </tr>
                <tr>
                    <td>NIM</td>
                    <td>:</td>
                    <td><?php echo e($remark[1]); ?></td>
                </tr>
                <tr>
                    <td>Program Studi</td>
                    <td>:</td>
                    <td><?php echo e($remark[2]); ?></td>
                </tr>
                <tr>
                    <td>Semester</td>
                    <td>:</td>
                    <td><?php echo e($remark[3]); ?></td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td>:</td>
                    <td><?php echo e($remark[5]); ?></td>
                </tr>
            </table>
            <p><br>
                Berdasarkan Surat Laporan yang diterima di bagian akademik pada tanggal <?php echo e(tanggal_indonesia($dt->tanggal_surat)); ?> menyatakan bahwa yang bersangkutan telah kehilangan KTM asli.
            </p>
            <p>
                Untuk itu, surat keterangan ini dibuat sebagai pengganti KTM, KTM berlaku selama 1 semester (semester <?php echo e($semester); ?> <?php echo e($remark[4]); ?>) dan agar dapat dipergunakan sebagaimana mestinya.
            </p>
            <div class="row" style="margin-top: 10%;">
                <div class="col-lg-2"></div>
                <div class="col-lg-10">
                    <img src="<?php echo e(asset('pengajuan_berkas')); ?>/<?php echo e($remark_1[0]); ?>" style="float: left;width: 130px;margin-right: 4px;">
                    Bogor, <?php echo e(tanggal_indonesia($dt->tanggal_surat)); ?><br>
                    Wakil Dekan<br>
                    Bidang Akademik Kemahasiswaan dan Alumni,
                    <br>
                    <?php if($dt->ttd != NULL): ?>
                    <img src="<?php echo e(asset($dt->ttd)); ?>" class="text" height="65"><br>
                    <?php endif; ?>
                    <?php $__currentLoopData = $kades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <u><?php echo e($kpl->name); ?></u><br>NIP. <?php echo e($kpl->nik); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-lg-2">

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\siruma_280524\resources\views/page/desa/template/SURAT_KETERANGAN_KEHILANGAN_KTM/SKKK_1/cek.blade.php ENDPATH**/ ?>