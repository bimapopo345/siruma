<?php if(session('add')): ?>
<script type="text/javascript">
	document.getElementById('top-right');
	Toastify({
		text: "<?php echo e(session('add')); ?>",
		duration: 3000,
		close:true,
		gravity:"top",
		position: "right",
		backgroundColor: "#4fbe87",
	}).showToast();
</script>
<?php endif; ?>
<?php if(session('up')): ?>
<script type="text/javascript">
	document.getElementById('top-right');
	Toastify({
		text: "<?php echo e(session('up')); ?>",
		duration: 3000,
		close:true,
		gravity:"top",
		position: "right",
		backgroundColor: "#4fbe87",
	}).showToast();
</script>
<?php endif; ?>
<?php if(session('del')): ?>
<script type="text/javascript">
	document.getElementById('top-right');
	Toastify({
		text: "<?php echo e(session('del')); ?>",
		duration: 3000,
		close:true,
		gravity:"top",
		position: "right",
		backgroundColor: "red",
	}).showToast();
</script>
<?php endif; ?>
<?php if(session('email')): ?>
<script type="text/javascript">
	document.getElementById('warning');
	Swal.fire({
		icon: "warning",
		title: "Email sama",
		text: "Email sudah di gunakan, mohon gunakan Email lain.",
	});
</script>
<?php endif; ?><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ratdela\resources\views/page/desa/layout/notif.blade.php ENDPATH**/ ?>