<div class="col-xl-12">
	<label>Keterangan/Keperluan <span class="text-danger">*</span></label>
	<div class="form-group position-relative">
		<input type="text" id="keperluan" required="" class="form-control" name="keperluan" value="">
		<span class="invalid-feedback" role="alert" id="keperluanError">
			<strong></strong>
		</span>
	</div>
</div>
<div class="col-xl-12">
	<label>Berkas Persyaratan <span class="text-danger">*</span></label>
	<div class="form-group position-relative">
		<input type="file" name="berkas" id="berkas" class="form-control">
		<span class="invalid-feedback" role="alert" id="berkasError">
			<strong></strong>
		</span>
	</div>
</div><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ratdela\resources\views/page/pengaju/request/SURAT_KETERANGAN_DOMISILI/skd_1_form.blade.php ENDPATH**/ ?>