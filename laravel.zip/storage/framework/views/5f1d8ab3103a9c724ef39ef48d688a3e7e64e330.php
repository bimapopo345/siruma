

<?php $__env->startSection('title','Data Template Surat'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-heading">
 <div class="page-title">
    <div class="row">
        <div class="col-12 col-md-6 order-md-1 order-last">
        </div>
        <div class="col-12 col-md-6 order-md-2 order-first">
            <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="">Template</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Surat</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<section class="section">
    <div class="card">
        <div class="card-header">
            Data Template Surat
            <a href="javascript:void(0)" class="btn btn-sm btn-primary rounded-pill new" style="float: right;"><i class="bx bx-plus"></i> Tambah Template</a>
        </div>
        <div class="card-body">
            <table class="table table-hover table-striped" id="table_template">
                <thead>
                    <tr>
                        <th>No. </th>
                        <th>Nama Template</th>
                        <th>Urutan</th>
                        <th>File</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
    </div>

</section>
</div>
<div class="modal fade text-left" id="modal_form_template" data-bs-backdrop="static" tabindex="-1" role="dialog"
aria-labelledby="myModalLabel1" aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="myModalLabel1"></h5>
            <button
            type="button"
            class="btn-close"
            data-bs-dismiss="modal"
            aria-label="Close"
            ></button>
        </div>
        <form method="post" enctype="multipart/form-data" id="templateForm">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label>Nama Template <span class="text-danger">*</span></label>
                            <input type="text" placeholder="SURAT_KETERANGAN_USAHA" onkeyup="keyupReplace('nama_template')" class="form-control" name="nama_template" id="nama_template">
                            <input type="hidden" id="id_template" name="id_template">
                            <span class="invalid-feedback" role="alert" id="nama_templateError">
                                <strong></strong>
                            </span>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label>Singkatan <span class="text-danger">*</span></label>
                            <input type="text" placeholder="SKU_1" class="form-control" onkeyup="keyupReplace('urutan_template')" name="urutan_template" id="urutan_template">
                            <span class="invalid-feedback d-block" role="alert" id="urutan_templateError">
                                <strong></strong>
                            </span>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label>File Template <span class="text-danger" id="file_label">*</span></label>
                            <input type="file" class="form-control" name="gambar_template" id="gambar_template">
                            <input type="hidden" id="gambar_templateLama" name="gambar_templateLama">
                            <span class="invalid-feedback" role="alert" id="gambar_templateError">
                                <strong></strong>
                            </span>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label>Status Template <span class="text-danger">*</span></label>
                            <select class="form-control" id="status_template" name="status_template">
                                <option value="">:. PILIH STATUS TEMPLATE .:</option>
                                <option value="Process">Process</option>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                            <span class="invalid-feedback d-block" role="alert" id="status_templateError">
                                <strong></strong>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-loading" id="modal-loading" style="display: none;">
                <span class="fa fa-circle-o-notch fa-pulse fa-3x"></span>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn" data-bs-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Tutup</span>
                </button>
                <button class="btn btn-primary ml-1">
                    <i class="bx bx-check d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Simpan</span>
                </button>
            </div>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    function keyupReplace(inputId) {
        var inputElement = document.getElementById(inputId);
        if (inputElement) {
            var inputValue = inputElement.value;
            var replacedValue = inputValue.replace(/ /g, "_").toUpperCase();
            inputElement.value = replacedValue;
        }
    }

    $(function () {
        $('#table_template').DataTable({
            processing: true,
            pageLength: 10,
            responsive: true,
            ajax: {
                url: "<?php echo e(route('data_surat')); ?>",
                error: function (jqXHR, textStatus, errorThrown) {
                    $('#table_template').DataTable().ajax.reload();
                }
            },
            columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex'},
            { 
                data: 'nama_template', 
                name: 'nama_template', 
                render: function (data, type, row) {
                    return data;
                }  
            },
            { 
                data: 'urutan_template', 
                name: 'urutan_template', 
                render: function (data, type, row) {
                    return data;
                }  
            },
            { 
                data: 'gambar_template', 
                name: 'gambar_template', 
                render: function (data, type, row) {
                    return '<a href="<?php echo e(asset('template-surat')); ?>/'+data+'" target="_blank"><span class="badge bg-info">Lihat Template</span>';
                }  
            },
            { 
                data: 'status_template', 
                name: 'status_template', 
                render: function (data, type, row) {
                    var bg = "";
                    if (data == 'Process') {
                        bg = 'bg-warning';
                    }else if(data == 'Active'){
                        bg = 'bg-success';
                    }else{
                        bg = 'bg-danger';
                    }
                    return '<span class="badge '+bg+' text-white">'+data+'</span>';
                }  
            },
            { data: 'action', name: 'action', orderable: false, className: 'space' }
            ]
        });
    });
    var ajaxUrl;
    $(".new").click(function() {
        $("#templateForm")[0].reset();
        $(".modal-title").html('<i class="fa fa-plus"></i> Form Tambah Template');
        $(".invalid-feedback").children("strong").text("");
        $(".select_opsi").val(null).trigger('change');
        $("#templateForm input").removeClass("is-invalid");
        $("#templateForm select").removeClass("is-invalid");
        $("#status_template").val(null).trigger('change');
        $("#file_label").html('');
        $("#modal_form_template").modal('show');
        ajaxUrl = " <?php echo e(route('addtemplate')); ?> ";
    });
    $(function () {
        $('#templateForm').submit(function(e) {
            e.preventDefault();
            let formData = new FormData(this);
            show_loading();
            $(".invalid-feedback").children("strong").text("");
            $("#templateForm input").removeClass("is-invalid");
            $("#templateForm select").removeClass("is-invalid");
            $.ajax({
                method: "POST",
                headers: {
                    Accept: "application/json"
                },
                contentType: false,
                processData: false,
                url: ajaxUrl,
                data: formData,
                success: function (response) {
                    hide_loading();
                    if (response.status == 'true') {
                        $("#templateForm")[0].reset();
                        $('#modal_form_template').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            type: 'success',
                            title: 'Success',
                            text: response.message
                        });
                        $('#table_template').DataTable().ajax.reload();
                    } else {
                        Swal.fire({
                            icon: 'error',
                            type: 'error',
                            title: 'Gagal',
                            dangerMode: true,
                            text: response.message
                        });
                    }
                },
                error: function (response) {
                    hide_loading();
                    if (response.status === 422) {
                        let errors = response.responseJSON.errors;
                        Object.keys(errors).forEach(function (key) {
                            $("#" + key).addClass("is-invalid");
                            $("#" + key + "Error").children("strong").text(errors[key][0]);
                        });
                    } else {
                        swal({
                            icon: 'error',
                            type: 'error',
                            title: 'Gagal',
                            dangerMode: true,
                            text: response.message
                        });
                    }
                }
            });
        });
    });
    function get_edit(templateID) {
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('admin-dashboard/data_template/get_edit_template')); ?>"+"/"+templateID,
            success: function(response) {
                if (response) {
                    hide_loading();
                    $.each(response, function(key, value) {
                        $("#id_template").val(value.id_template);
                        $("#nama_template").val(value.nama_template);
                        $("#urutan_template").val(value.urutan_template);
                        $("#gambar_templateLama").val(value.gambar_template);
                        $("#status_template").val(value.status_template).trigger('change');
                    });
                }
            },
            error: function(response) {
                get_edit(templateID);
            }
        });
    }
    $(document).on('click','.edit',function() {
        var templateID = $(this).attr('more_id');
        show_loading();
        $("#templateForm")[0].reset();
        $(".modal-title").html('<i class="fa fa-edit"></i> Form Ubah Template');
        $(".invalid-feedback").children("strong").text("");
        $("#templateForm input").removeClass("is-invalid");
        $("#templateForm select").removeClass("is-invalid");
        $("#file_label").html('');
        $("#modal_form_template").modal('show');
        ajaxUrl = " <?php echo e(route('updatetemplate')); ?> ";
        if (templateID) {
            get_edit(templateID);
        }
    });
    $(document).on('click', '.delete', function (event) {
        templateID = $(this).attr('more_id');
        event.preventDefault();
        Swal.fire({
            title: 'Lanjut Hapus Data?',
            text: 'Data Surat akan dihapus secara Permanent!',
            icon: 'warning',
            type: 'warning',
            showCancelButton: !0,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: 'Lanjutkan'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('page/surat/hapus')); ?>"+"/"+templateID,
                    success: function(response) {
                        if (response.status == 'true') {
                            Swal.fire({
                                icon: 'success',
                                type: 'success',
                                title: 'Success',
                                text: response.message
                            });
                            $('#table_template').DataTable().ajax.reload();
                        }else{
                            Swal.fire({
                                icon: 'error',
                                type: 'error',
                                title: 'Terjadi kesalahan',
                                text: response.message
                            });
                        }
                    },
                    error: function(response) {
                        Swal.fire({
                            icon: 'error',
                            type: 'error',
                            title: 'Gagal',
                            dangerMode: true,
                            text: 'Terjadi kesalahan!'
                        });
                    }
                });
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/desa/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/page/admin/template/index.blade.php ENDPATH**/ ?>