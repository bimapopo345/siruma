

<?php $__env->startSection('title','Data Request Surat Permohonan'); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="card">
        <div class="card-header">
            Table Data
        </div>
        <div class="card-body">
            <table class="table table-striped" id="table1">
                <thead>
                    <tr>
                        <th>No. </th>
                        <th>Tanggal Request</th>
                        <th>Request Surat</th>
                        <th>Nama Lengkap</th>
                        <th>Status</th>
                        <th>Keterangan</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no=1; ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?=$no; ?>. </th>
                        <td><?php echo e($dt->tgl_req); ?></td>
                        <td><?php echo e($dt->nama_surat); ?></td>
                        <td><?php echo e($dt->name); ?></td>
                        <td>
                            <?php if($dt->status_pengajuan=="Pengecekan Permohonan"): ?>
                            <span class="badge bg-danger">Data Sedang <br>di Periksa</span>
                            <?php elseif($dt->status_pengajuan=="Data Belum Lengkap"): ?>
                            <span class="badge bg-danger"><?php echo e($dt->status_pengajuan); ?></span>
                            <?php else: ?>
                            <span class="badge bg-success"><?php echo e($dt->status_pengajuan); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($dt->selesai==NULL): ?>
                            Menunggu Konfirmasi
                            <?php endif; ?>
                            <?php if($dt->selesai!==NULL): ?>
                            <span class="badge bg-success">
                                <?php echo e($dt->selesai); ?>

                            </span>
                            <?php endif; ?>
                        </td>
                        <td align="center">
                            <a href="" data-bs-toggle="modal"
                            data-bs-target="#detail<?php echo e($dt->id_pengajuan); ?>" class="btn btn-sm btn-primary rounded-pill"><i class="icon dripicons-document"></i></a>
                            <?php if($dt->selesai=="Surat Selesai"): ?>
                            <a href="<?php echo e(route('cetak_surat',['surat'=>$dt->singkatan,'id_pengajuan'=>$dt->id_pengajuan])); ?>?keyword=print-surat" class="btn btn-sm btn-success rounded-pill"><i class="icon dripicons-print"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php $no++ ?>
                    <?php echo $__env->make('pengaju/data/detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('desa/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\produk-web\desa\resources\views/pengaju/data/data.blade.php ENDPATH**/ ?>