<!DOCTYPE html>
<html lang="en">
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($dt->nomor_surat); ?></title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/bootstrap.css')); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/dripicons/webfont.css')); ?>"> -->
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/pages/dripicons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/app.css')); ?>">
</head>
<style type="text/css">
    .footer_right {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        text-align: right;
        padding: 10px;
    }
    .footer_left {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        text-align: left;
        padding: 10px;
    }
    .signature {
        display: inline-block;
        text-align: center;
        width: 50%; /* Adjust the width as needed */
        margin: 0 auto;
    }
</style>
<body style="background: white;color: black;font-size: 13px;">
    <div class="container-fluid" style="background: white;">
        <div class="row">
            <div class="col-xl-12">
                <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <center>
                    <img src="<?php echo e(asset('foto')); ?>/<?php echo e($ds->logo); ?>" alt="avatar" class="img" width="75" style="float: left;">
                    <b>PEMERINTAHAN <?php echo e($ds->name_city); ?> <br>
                        KECAMATAN <?php echo e($ds->name_district); ?></b>
                        <h5 style="color: black;">DESA <?php echo e($ds->name_village); ?></h5>
                        <span><?php echo e($ds->lokasi_desa); ?></span>
                    </center>
                    <hr>
                    <center>
                        <span style="font-size: 15px;text-transform: uppercase;font-weight: bold;text-decoration: underline;"><?php echo e($dt->nama_surat); ?></span>
                        <br>
                        <span>Nomor : <?php echo e($dt->nomor_surat); ?></span>
                    </center>
                    <p style="text-align: left;" class="text mt-3">
                        Yang bertanda tangan di bawah ini Kasi Pemerintahan, Kecamatan <?php echo e(ucwords(strtolower($ds->name_district))); ?>, <?php echo e(ucwords(strtolower($ds->name_city))); ?>, Provinsi <?php echo e(ucwords(strtolower($ds->name_province))); ?> menerangkan dengan sebenarnya bahwa pada :
                    </p>
                    <table border="0" style="margin-left: 0.5in;margin-top: -15px;">
                        <?php  
                        $remark = explode(";", $dt->remark);
                        $remark_1 = explode(";", $dt->remark_1);
                        $tanggal_lahir = $dt->tgl_lahir;
                        $umur = date_diff(date_create($tanggal_lahir), date_create('today'))->y;

                        ?>
                        <tr>
                            <td>1. Hari</td>
                            <td>:</td>
                            <td><?php echo e($remark[1]); ?></td>
                        </tr>
                        <tr>
                            <td>2. Tanggal</td>
                            <td>:</td>
                            <td><?php echo e(tanggal_indonesia($remark[3])); ?></td>
                        </tr>
                        <tr>
                            <td>3. Pukul</td>
                            <td>:</td>
                            <td><?php echo e($remark[4]); ?></td>
                        </tr>
                        <tr>
                            <td>4. Tempat</td>
                            <td>:</td>
                            <td><?php echo e($remark[2]); ?></td>
                        </tr>
                        <tr>
                            <td>5. Telah lahir seorang anak</td>
                            <td>:</td>
                            <td><?php echo e($remark[0]); ?></td>
                        </tr>
                    </table>
                    <p>
                        <br>
                        Dari seorang ibu:
                    </p>
                    <table border="0" style="margin-left: 0.5in;margin-top: -15px;">
                        <tr>
                            <td>6. Nama Lengkap</td>
                            <td>:</td>
                            <td><?php echo e($remark_1[0]); ?></td>
                        </tr>
                        <tr>
                            <td>7. NIK / No KTP</td>
                            <td>:</td>
                            <td><?php echo e($remark_1[1]); ?></td>
                        </tr>
                        <tr>
                            <td>8. Umur</td>
                            <td>:</td>
                            <td><?php echo e($remark_1[2]); ?></td>
                        </tr>
                        <tr>
                            <td>9. Pekerjaan</td>
                            <td>:</td>
                            <td><?php echo e($remark_1[3]); ?></td>
                        </tr>
                        <tr>
                            <td>10. Alamat/Tempat Tinggal</td>
                            <td>:</td>
                            <td><?php echo e($remark_1[4]); ?></td>
                        </tr>
                    </table>
                    <p>
                        <br>Istri dari:
                    </p>
                    <table border="0" style="margin-left: 0.5in;margin-top: -15px;">
                        <tr>
                            <td>11. Nama Lengkap</td>
                            <td>:</td>
                            <td><?php echo e($remark_1[5]); ?></td>
                        </tr>
                        <tr>
                            <td>12. NIK</td>
                            <td>:</td>
                            <td><?php echo e($remark_1[6]); ?></td>
                        </tr>
                        <tr>
                            <td>13. Umur</td>
                            <td>:</td>
                            <td><?php echo e($remark_1[7]); ?></td>
                        </tr>
                        <tr>
                            <td>14. Pekerjaan</td>
                            <td>:</td>
                            <td><?php echo e($remark_1[8]); ?></td>
                        </tr>
                        <tr>
                            <td>15. Alamat</td>
                            <td>:</td>
                            <td><?php echo e($remark_1[9]); ?></td>
                        </tr>
                    </table>
                    <p>
                        <br>Surat keterangan ini dibuat berdasarkan keterangan pelapor:
                    </p>
                    <table border="0" style="margin-left: 0.5in;margin-top: -15px;">
                        <tr>
                            <td>16. Nama Lengkap</td>
                            <td>:</td>
                            <td><?php echo e($dt->name); ?></td>
                        </tr>
                        <tr>
                            <td>17. NIK</td>
                            <td>:</td>
                            <td><?php echo e($dt->nik); ?></td>
                        </tr>
                        <tr>
                            <td>18. Umur</td>
                            <td>:</td>
                            <td><?php echo e($umur); ?></td>
                        </tr>
                        <tr>
                            <td>19. Pekerjaan</td>
                            <td>:</td>
                            <td><?php echo e($dt->pekerjaan); ?></td>
                        </tr>
                        <tr>
                            <td>20. Alamat</td>
                            <td>:</td>
                            <td><?php echo e($dt->alamat); ?></td>
                        </tr>
                        <tr>
                            <td>21. Hubungan pelapor dengan bayi</td>
                            <td>:</td>
                            <td>
                                <?php echo e($remark_1[10]); ?>

                            </td>
                        </tr>
                    </table>
                    <p class="text mt-2" style="font-size:14.5px;">
                     Surat Keterangan ini dibuat untuk Keamanan. <br>
                     Demikian surat keterangan ini dibuat, atas perhatian dan kerjasamanya kami ucapkan terima kasih.
                 </p>
                 <div class="footer_right">
                    <div class="signature" style="margin-bottom: 20px;">
                        <div><?php echo e(ucwords(strtolower($ds->name_village))); ?>, <?php echo e(date('d F Y')); ?></div>
                        <div><br></div>
                        <div><br></div>
                        <div><br></div>
                        <div><br></div>
                        <div><br></div>
                        <div style="font-weight: bold;text-decoration: underline;">
                           <?php echo e($dt->name); ?>

                       </div>
                   </div>
               </div>
               <div class="footer_left">
                <div class="signature">
                    <div>Mengetahui :</div>
                    <div>Kepala Desa</div>
                    <div><img src="<?php echo e(asset($dt->ttd)); ?>" class="text" height="95"></div>
                    <div>
                       <?php if(Auth::user()->level!=="Kepala Desa"): ?>
                       <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <p><b><u><?php echo e($kpl->name); ?></u></b></p>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <?php else: ?>
                       <p><b><u><?php echo e(Auth::user()->name); ?></u></b></p>
                       <?php endif; ?>
                   </div>
               </div>
           </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
   </div>
</div>
</body>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</html><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ladar\resources\views/page/desa/template/SURAT_KETERANGAN_KELAHIRAN/SKK_1/print.blade.php ENDPATH**/ ?>