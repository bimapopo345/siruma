<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php if($details['status']=="Pemberitahuan"): ?>
	Anda telah mendaftar di DIGITAL SURAT-PERMOHONAN, silahkan Tunggu Konfirmasi dari Pihak Admin untuk Meng-Aktifkan Akun anda : <br>
	<p>Provinsi : <?php echo e($details['provinsi']); ?></p>
	<p>Kota : <?php echo e($details['kota']); ?></p>
	<p>Kecamatan : <?php echo e($details['kecamatan']); ?></p>
	<p>Desa/Kelurahan : <?php echo e($details['desa']); ?></p>
	Pastikan Berkas yang di Upload Benar dan Resmi dari Kelurahan yang terdaftar, guna untuk Admin mempercepat Verifikasi.
	<p>
		<br>
		Best Regards,<br>
		<b>Dante Project Sejahtera</b>
	</p>
	<?php elseif($details['status']=="Setuju"): ?>
	Yth. Bpk/Ibu  <span style="text-transform: uppercase;"><?php echo e($details['email']); ?></span>,
	<p>
		Kami Menyetujui Permohonan Kelurahan Desa anda.
	</p>
	<p>
		Untuk tahap masuk ke Halaman Kelurahan Desa, Anda dapat Menggunakan Kode Akses. <br>
		<br>
		Kode Akses Desa : <?php echo e($details['akses']); ?>

	</p>
	<br>
	<p>
		<i>Notes: Jangan beri tahu Kode Akses Desa anda selain Warga Desa setempat.</i>
	</p>
	<p>
		Demikian informasi dari kami. Atas perhatian dan kerjasamanya kami ucapkan terima kasih.
	</p>
	<p>
		Best Regards,<br>
		<b>Dante Project Sejahtera</b>
	</p>
	<?php else: ?>
	Yth. Bpk/Ibu  <span style="text-transform: uppercase;"><?php echo e($details['email']); ?></span>,
	<p>
		Kami Menolak Permohonan Kelurahan Desa anda.
	</p>
	<p>
		Di Karenakan formulir yang tidak lengkap dan Berkas yang tidak sesuai, mengacu pihak Admin untuk menolak Permohonan Kelurahan anda.
	</p>
	<p>
		Demikian informasi dari kami. Atas ke tidak nyaman nya kami ucapkan mohon maaf.
	</p>
	<p>
		Best Regards,<br>
		<b>Dante Project Sejahtera</b>
	</p>
	<?php endif; ?>
</body>
</html><?php /**PATH D:\xampp\htdocs\desa\resources\views/mail.blade.php ENDPATH**/ ?>