<div class="container mt-3" id="content_cek" style="background: white;">
    <div class="row">
        <div class="col-lg-2">

        </div>
        <div class="col-lg-8">
            <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <center>
                <img src="<?php echo e(asset('foto')); ?>/<?php echo e($ds->logo); ?>" alt="avatar" class="img pt-2" width="75" style="float: left;">
                <b>PEMERINTAHAN <?php echo e($ds->name_city); ?> <br>
                    KECAMATAN <?php echo e($ds->name_district); ?></b>
                    <h4>KELURAHAN <?php echo e($ds->name_village); ?></h4>
                    <span><i><?php echo e($ds->lokasi_desa); ?></i></span>
                </center>
                <hr>
                <center>
                    <span style="font-size: 20px;text-transform: uppercase;font-weight: bold;text-decoration: underline;"><?php echo e($dt->nama_surat); ?></span>
                    <br>
                    <span>Nomor : <?php echo e($dt->nomor_surat); ?></span>
                </center>
                <p>
                    Yang bertanda tangan di bawah ini: 
                </p>
                <table style="margin-left: 3rem;margin-top: -20px;">
                    <tr>
                      <td>Nama</td>
                      <td>:</td>
                      <td>
                         <?php $__currentLoopData = $kades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php echo e($kpl->name); ?>

                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </td>
                 </tr>
                 <tr>
                    <td>Jabatan</td>
                    <td>:</td>
                    <td>
                       <?php $__currentLoopData = $kades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php echo e($kpl->level); ?> Desa <?php echo e(ucwords(strtolower($ds->name_village))); ?> Kecamatan <?php echo e(ucwords(strtolower($ds->name_district))); ?>

                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </td>
               </tr>
               <tr>
                  <td>Alamat</td>
                  <td>:</td>
                  <td>
                     <?php $__currentLoopData = $kades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php echo e($kpl->alamat); ?>

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </td>
             </tr>
         </table>
         <p class="text mt-3">Dengan ini memberikan Keterangan pada :</p>
         <table border="0" style="margin-left: 3rem;margin-top: -20px;">
            <?php  
            $remark = explode(";", $dt->remark);
            $remark_1 = explode(";", $dt->remark_1);
            ?>
            <tr>
                <td>Nama Wali/Ortu</td>
                <td>:</td>
                <td><?php echo e($remark[0]); ?></td>
            </tr>
            <tr>
                <td>NIK</td>
                <td>:</td>
                <td><?php echo e($remark[1]); ?></td>
            </tr>
            <tr>
                <td>Tempat/Tanggal Lahir</td>
                <td>:</td>
                <td><?php echo e($remark[2]); ?> / <?php echo e(tanggal_indonesia($remark[3])); ?></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td>:</td>
                <td><?php echo e($remark[5]); ?></td>
            </tr>
            <tr>
                <td>Pekerjaan</td>
                <td>:</td>
                <td><?php echo e($remark[4]); ?></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>:</td>
                <td><?php echo e($remark[6]); ?></td>
            </tr>
        </table>
        <p class="text mt-3">Keterangan :</p>
        <ol style="margin-top: -20px;">
            <li>
                Yang tersebut adalah benar Penduduk <?php echo e($remark[6]); ?>.
            </li>
            <li>
                Benar tersebut tergolong penduduk yang <b><u>BERPENGHASILAN KURANG/KURANG MAMPU.</u></b>
            </li>
            <li>
                Yang tersebut diatas adalah Wali/Orang Tua dari :
                <table style="margin-left: 2rem;">
                    <tr>
                        <td>Nama</td>
                        <td>:</td>
                        <td><?php echo e($dt->name); ?></td>
                    </tr>
                    <tr>
                        <td>NIK</td>
                        <td>:</td>
                        <td><?php echo e($dt->nik); ?></td>
                    </tr>
                </table>
            </li>
            <li>
                <?php  
                function terbilangRupiah($angka) {
                    $angka = abs($angka);
                    $terbilang = '';
                    $huruf = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
                    if ($angka < 12) {
                        $terbilang = $huruf[$angka];
                    } elseif ($angka < 20) {
                        $terbilang = terbilangRupiah($angka - 10) . " belas";
                    } elseif ($angka < 100) {
                        $terbilang = terbilangRupiah($angka / 10) . " puluh " . terbilangRupiah($angka % 10);
                    } elseif ($angka < 200) {
                        $terbilang = "seratus " . terbilangRupiah($angka - 100);
                    } elseif ($angka < 1000) {
                        $terbilang = terbilangRupiah($angka / 100) . " ratus " . terbilangRupiah($angka % 100);
                    } elseif ($angka < 2000) {
                        $terbilang = "seribu " . terbilangRupiah($angka - 1000);
                    } elseif ($angka < 1000000) {
                        $terbilang = terbilangRupiah($angka / 1000) . " ribu " . terbilangRupiah($angka % 1000);
                    } elseif ($angka < 1000000000) {
                        $terbilang = terbilangRupiah($angka / 1000000) . " juta " . terbilangRupiah($angka % 1000000);
                    } else {
                        $terbilang = 'Angka terlalu besar untuk diolah';
                    }
                    return ucwords($terbilang);
                }
                ?>
                Penghasilan Wali/Orang Tua per Bulan Rp. <?php echo e(number_format($remark_1[0],0,",",".")); ?> ( <?php echo e(terbilangRupiah($remark_1[0])); ?> ).
            </li>
            <li>
                Surat Keterangan ini digunakan untuk <?php echo e($dt->keperluan); ?>.
            </li>
        </ol>
        <p class="text mt-3">
            Demikian Surat Keterangan ini telah dibuat dan diberikan kepada yang bersangkutan untuk digunakan sesuai perlunya, atas perhatian dan kerjasamanya kami ucapkan terima kasih.
        </p>
        <div class="row">
            <div class="col-lg-6 text-center">
            </div>
            <div class="col-lg-6 text-center">
                <p>
                    Dikeluarkan di : <?php echo e(ucwords(strtolower($ds->name_village))); ?> <br>
                    Pada Tanggal : <?php echo date('m F Y') ?>
                </p>
                <hr>
                Kepala Desa Kelurahan <?php echo e(ucwords(strtolower($ds->name_village))); ?>

                <?php if($dt->ttd!==NULL): ?>
                <br>
                <img src="<?php echo e(asset($dt->ttd)); ?>" style="width: 60%;">
                <?php else: ?>
                <p class="text" style="padding-top: 23%;">
                </p>
                <?php endif; ?>
                <p class="text">
                    <?php if(Auth::user()->level!=="Kepala Desa"): ?>
                    <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <b><u><?php echo e($kpl->name); ?></u></b>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <b><u><?php echo e(Auth::user()->name); ?></u></b>
                    <?php endif; ?>
                </p>
            </div>
        </div>
    </center>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="col-lg-2">

</div>
</div>
</div><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/page/desa/template/SURAT_KETERANGAN_PENGHASILAN_ORANG_TUA/SKPOT_1/cek.blade.php ENDPATH**/ ?>