

<?php $__env->startSection('title','Cek Surat Acc'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
    <div class="col-lg-7 pb-4" style="background: white;box-shadow:2px 2px grey;">
        <form method="post" action="<?php echo e(route('confirm_ttd',$dt->id_pengajuan)); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" value="<?php echo e($dt->singkatan); ?>" name="singkatan">
            <button class="btn btn-sm form-control btn-primary mt-2">Konfirmasi Surat Selesai</button>
        </form>
    </div>
        <div class="col-lg-7">
        <a href="<?php echo e(route('form_ttd',$dt->id_pengajuan)); ?>" class="btn btn-sm form-control btn-success mt-2">Tanda Tangan</a>
   </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container mt-3" style="background: white;">
    <div class="row">
        <div class="col-lg-2">

        </div>
        <div class="col-lg-8">
            <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <center>
                <img src="<?php echo e(asset('foto')); ?>/<?php echo e($ds->logo); ?>" alt="avatar" class="img pt-3" width="50" style="float: left;">
                PEMERINTAHAN <?php echo e($ds->name_city); ?> <br>
                KECAMATAN <?php echo e($ds->name_district); ?>

                <h4>KELURAHAN <?php echo e($ds->name_village); ?></h4>
                <span><i><?php echo e($ds->lokasi_desa); ?></i></span>
            </center>
            <hr>
            <center>
                <h5 style="text-transform: uppercase;"><u><?php echo e($dt->nama_surat); ?></u></h5>
                Nomor : <?php echo e($dt->singkatan); ?> / <?php echo e($dt->nomor_surat); ?> / <?php echo e($dt->tgl_req); ?>

            </center>
            <p style="text-align: left;">
                &nbsp;&nbsp;&nbsp; Yang bertanda tangan di bawah ini Lurah <?php echo e($ds->name_village); ?> <?php echo e($ds->name_city); ?>, <br style="float: left;">Menerangkan bahwa :
            </p>
            <center>
                <table border="0">
                    <tr>
                        <td>Nama</td>
                        <td>:</td>
                        <td><?php echo e($dt->name); ?></td>
                    </tr>
                    <tr>
                        <td>Tempat, tanggal lahir</td>
                        <td>:</td>
                        <td><?php echo e($dt->tempat); ?>, <?php echo e($dt->tgl_lahir); ?></td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td>:</td>
                        <td><?php echo e($dt->jenis_kelamin); ?></td>
                    </tr>
                    <tr>
                        <td>Agama</td>
                        <td>:</td>
                        <td><?php echo e($dt->agama); ?></td>
                    </tr>
                    <tr>
                        <td>Pekerjaan</td>
                        <td>:</td>
                        <td><?php echo e($dt->pekerjaan); ?></td>
                    </tr>
                    <tr>
                        <td>No. NIK</td>
                        <td>:</td>
                        <td><?php echo e($dt->nik); ?></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td>:</td>
                        <td><?php echo e($dt->alamat); ?></td>
                    </tr>
                </table>
                Adalah benar - benar penduduk asli Kampung <?php echo e($ds->nama_village); ?> Kecamatan <?php echo e($ds->name_district); ?>.
                <p>"Surat Keterangan ini digunakan untuk Keperluan <b><i><u><?php echo e($dt->keperluan); ?></u></i></b>"</p>
                <p>Demikian surat ini diberikan kepada yang bersangkutan agar dapat dipergunakan untuk sebagaimana mestinya.</p>
                <div class="row">
                    <div class="col-lg-6">
                        Tanda Tangan <br> Yang Bersangkutan 
                        <p class="text" style="padding-top: 29%;">
                            <b><u><?php echo e($dt->name); ?></u></b>
                        </p>
                    </div>
                    <div class="col-lg-6">
                        <?php echo e($ds->name_city); ?> <br>
                        Kepala Desa Kelurahan <?php echo e($ds->name_village); ?> <br>
                        <?php if($dt->ttd==NULL): ?>
                        <span class="badge bg-danger">Isi TTD dulu</span>
                        <?php else: ?>
                        <img src="<?php echo e(asset($dt->ttd)); ?>" style="width: 60%;">
                        <?php endif; ?>
                        <p class="text">
                            <b><u><?php echo e(Auth::user()->name); ?></u></b>
                        </p>
                    </div>
                </div>
            </center>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-lg-2">

        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('desa/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\desa\resources\views/kepaladesa/acc/ttd.blade.php ENDPATH**/ ?>