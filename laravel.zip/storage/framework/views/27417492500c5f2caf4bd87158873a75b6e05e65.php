

<?php $__env->startSection('title','Acc Staff'); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <!-- <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Pengajuan Surat /</span> <?php echo e($surat); ?></h4> -->
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="">Pengajuan Surat</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($surat); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-header">
            Data Pengajuan permohonan Surat | Belum ACC
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped" id="table1">
                    <thead>
                        <tr>
                            <th>No. </th>
                            <th>Tanggal Pengajuan</th>
                            <th>Surat</th>
                            <th>Nama</th>
                            <th>Status</th>
                            <th>Keterangan</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no=1; ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?=$no; ?>. </th>
                            <td><?php echo e(tanggal_indonesia($dt->tgl_req)); ?></td>
                            <td><?php echo e($dt->nama_surat); ?></td>
                            <td><?php echo e($dt->name); ?></td>
                            <td>
                                <?php if($dt->status_pengajuan=="Pengecekan Permohonan"): ?>
                                <span class="badge bg-danger">Data Sedang di Periksa</span>
                                <?php elseif($dt->status_pengajuan=="Data Belum Lengkap"): ?>
                                <span class="badge bg-danger"><?php echo e($dt->status_pengajuan); ?></span>
                                <?php else: ?>
                                <span class="badge bg-success"><?php echo e($dt->status_pengajuan); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($dt->selesai==NULL): ?>
                                Menunggu Konfirmasi
                                <?php endif; ?>
                                <?php if($dt->selesai!==NULL): ?>
                                <span class="badge bg-success">
                                    <?php echo e($dt->selesai); ?>

                                </span>
                                <?php endif; ?>
                            </td>
                            <td align="center">
                                <a href="<?php echo e(route('staff_cek_berkas',['surat'=>$dt->singkatan,'id_pengajuan'=>$dt->id_pengajuan])); ?>" class="btn btn-sm btn-primary rounded-pill"><i class="fa fa-eye"></i></a>
                            </td>
                        </tr>
                        <?php $no++ ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/desa/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/page/staff/acc/acc.blade.php ENDPATH**/ ?>