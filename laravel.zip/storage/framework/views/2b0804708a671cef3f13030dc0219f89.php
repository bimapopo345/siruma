<div class="col-lg-6">
	<div class="row">
		<div class="col-lg-12">
			<label>Nama <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="text" id="nama" class="form-control" name="nama">
				<span class="invalid-feedback d-block" role="alert" id="namaError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<label>Bin / Binti <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="text" id="bin" class="form-control" name="bin">
				<span class="invalid-feedback d-block" role="alert" id="binError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<label>NIK <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="text" id="nik" class="form-control" name="nik">
				<span class="invalid-feedback d-block" role="alert" id="nikError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<label>Jenis Kelamin <span class="text-danger">*</span></label>
			<div class="form-group">
				<select class="form-control" id="jenis_kelamin" name="jenis_kelamin">
					<option value="">:. PILIH JENIS KELAMIN .:</option>
					<option value="Laki-Laki">Laki-Laki</option>
					<option value="Perempuan">Perempuan</option>
				</select>
				<span class="invalid-feedback d-block" role="alert" id="jenis_kelaminError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-6">
			<label>Tempat Lahir <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="text" id="tempat_lahir" class="form-control" name="tempat_lahir">
				<span class="invalid-feedback d-block" role="alert" id="tempat_lahirError">
					<strong></strong>
				</span>
			</div>
		</div>
		<div class="col-lg-6">
			<label>Tanggal Lahir <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="date" id="tanggal_lahir" class="form-control" name="tanggal_lahir">
				<span class="invalid-feedback d-block" role="alert" id="tanggal_lahirError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<label>Status Pernikahan <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="text" id="status_pernikahan" class="form-control" name="status_pernikahan">
				<span class="invalid-feedback d-block" role="alert" id="status_pernikahanError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<label>Pekerjaan <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="text" id="pekerjaan" class="form-control" name="pekerjaan">
				<span class="invalid-feedback d-block" role="alert" id="pekerjaanError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<label>Alamat <span class="text-danger">*</span></label>
			<div class="form-group">
				<textarea class="form-control" rows="4" id="alamat" name="alamat"></textarea>
				<span class="invalid-feedback d-block" role="alert" id="alamatError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
</div>
<div class="col-lg-6">
	<div class="row">
		<div class="col-lg-6">
			<label>Tanggal Meninggal <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="date" id="tanggal_meninggal" class="form-control" name="tanggal_meninggal">
				<span class="invalid-feedback d-block" role="alert" id="tanggal_meninggalError">
					<strong></strong>
				</span>
			</div>
		</div>
		<div class="col-lg-6">
			<label>Jam <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="time" id="jam_meninggal" class="form-control" name="jam_meninggal">
				<span class="invalid-feedback d-block" role="alert" id="jam_meninggalError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<label>Tempat Meninggal <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="text" id="tempat_meninggal" class="form-control" name="tempat_meninggal">
				<span class="invalid-feedback d-block" role="alert" id="tempat_meninggalError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<label>Sebab Meninggal <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="text" id="sebab_meninggal" class="form-control" name="sebab_meninggal">
				<span class="invalid-feedback d-block" role="alert" id="sebab_meninggalError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-xl-12">
			<label>Berkas Persyaratan <span class="text-danger">*</span></label>
			<div class="form-group position-relative">
				<input type="file" name="berkas" id="berkas" class="form-control">
				<span class="invalid-feedback" role="alert" id="berkasError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
</div>
<?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ratdela\resources\views/page/pengaju/request/SURAT_KETERANGAN_KEMATIAN/skk_1_form.blade.php ENDPATH**/ ?>