<div class="modal fade" id="detail<?php echo e($dt->id_pengajuan); ?>" data-bs-backdrop="static" tabindex="-1"
    role="dialog" aria-labelledby="myModalLabel160"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered"
    role="document">
    <div class="modal-content">
        <div class="modal-header">
           <h5 class="modal-title" id="exampleModalLabel1">Detail Informasi</h5>
           <button
           type="button"
           class="btn-close"
           data-bs-dismiss="modal"
           aria-label="Close"
           ></button>
       </div>
       <div class="modal-body">
        <div class="row">
            <div class="col-6">
                Pengajuan Surat
            </div>
            <div class="col-6">
                <?php echo e($dt->nama_surat); ?>

            </div>
            <div class="col-6">
                Nomor Surat
            </div>
            <div class="col-6">
                <?php echo e($dt->nomor_surat); ?>

            </div>
            <div class="col-6">
                Tanggal Pengajuan
            </div>
            <div class="col-6">
                <?php echo e(tanggal_indonesia($dt->tgl_req)); ?>

            </div>
            <div class="col-6">
                Keperluan
            </div>
            <div class="col-6">
                <?php if($dt->keperluan == NULL): ?>
                <?php echo e($dt->nama_surat); ?>

                <?php else: ?>
                <?php echo e($dt->keperluan); ?>

                <?php endif; ?>
            </div>
            <div class="col-6">
                Nama Lengkap
            </div>
            <div class="col-6">
                <?php echo e($dt->name); ?>

            </div>
            <div class="col-6">
                NIK
            </div>
            <div class="col-6">
                <?php echo e($dt->nik); ?>

            </div>
            <div class="col-6">
                Status Pengajuan
            </div>
            <div class="col-6">
                <?php if($dt->status_pengajuan=="Pengecekan Permohonan"): ?>
                Data Sedang di Periksa
                <?php else: ?>
                <?php echo e($dt->status_pengajuan); ?>

                <?php endif; ?>
            </div>
            <!-- <div class="col-6 mt-5">
                <b><i>Note : </i></b>
            </div>
            <div class="col-6">
                <i><b>SILAHKAN TUNGGU PENGAJUAN SEDANG DI VERIFIKASI, INFO AKAN DI KIRIM MELALUI EMAIL ANDA.</b></i>
            </div> -->
            <hr>
            <?php $__currentLoopData = $pelengkap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $br): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($br->pengajuan_id==$dt->id_pengajuan): ?>
            <div class="col-lg-4">
                <a href="<?php echo e(asset('pengajuan_berkas')); ?>/<?php echo e($br->data_berkas); ?>" class="btn btn-md btn-success text-white" download=""><i class="fa fa-file"></i> Lihat Berkas</a>
                <!-- <img src="" width="50"> -->
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button"
        class="btn btn-outline-secondary"
        data-bs-dismiss="modal">
        <span class="">Tutup</span>
    </button>
    <!--  -->
</div>
</div>
</div>
</div><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/page/pengaju/data/detail.blade.php ENDPATH**/ ?>