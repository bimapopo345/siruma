<div class="container mt-3" id="content_cek" style="background: white;">
    <div class="row">
        <div class="col-lg-2">

        </div>
        <div class="col-lg-8">
            <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <center>
                <img src="<?php echo e(asset('foto')); ?>/<?php echo e($ds->logo); ?>" alt="avatar" class="img pt-3" width="75" style="float: left;">
                PEMERINTAHAN <?php echo e($ds->name_city); ?> <br>
                KECAMATAN <?php echo e($ds->name_district); ?>

                <h4>DESA <?php echo e($ds->name_village); ?></h4>
                <span><i><?php echo e($ds->lokasi_desa); ?></i></span>
            </center>
            <hr>
            <center>
                <h5 style="text-transform: uppercase;"><u><?php echo e($dt->nama_surat); ?></u><br><span style="font-size: 15px;">Nomor : <?php echo e($dt->nomor_surat); ?></span></h5>
                
            </center>
            <p style="text-align: center;">
                Yang bertanda tangan dibawah ini Kepala Desa <?php echo e(ucwords(strtolower($ds->name_village))); ?>, Kecamatan <?php echo e(ucwords(strtolower($ds->name_district))); ?>, <?php echo e(ucwords(strtolower($ds->name_city))); ?>, Provinsi <?php echo e(ucwords(strtolower($ds->name_province))); ?> menerangkan dengan sebenarnya bahwa :
            </p>
            <table border="0">
                <?php  
                $remark = explode(";", $dt->remark);
                ?>
                <tr>
                    <td>1. Nama</td>
                    <td>:</td>
                    <td><?php echo e($dt->name); ?></td>
                </tr>
                <tr>
                    <td>2. Tempat Tanggal Lahir</td>
                    <td>:</td>
                    <td><?php echo e($dt->tempat); ?>, <?php echo e($dt->tgl_lahir); ?></td>
                </tr>
                <tr>
                    <td>3. Umur</td>
                    <td>:</td>
                    <td><?php echo e($remark[0]); ?></td>
                </tr>
                <tr>
                    <td>4. Warga Negara</td>
                    <td>:</td>
                    <td><?php echo e($remark[1]); ?></td>
                </tr>
                <tr>
                    <td>5. Agama</td>
                    <td>:</td>
                    <td><?php echo e($remark[2]); ?></td>
                </tr>
                <tr>
                    <td>6. Jenis Kelamin</td>
                    <td>:</td>
                    <td><?php echo e($dt->jenis_kelamin); ?></td>
                </tr>
                <tr>
                    <td>7. Pekerjaan</td>
                    <td>:</td>
                    <td><?php echo e($dt->pekerjaan); ?></td>
                </tr>
                <tr>
                    <td>8. Tempat tinggal</td>
                    <td>:</td>
                    <td><?php echo e($dt->alamat); ?></td>
                </tr>
                <tr>
                    <td>9. Surat bukti diri</td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;NIK</td>
                    <td>:</td>
                    <td><?php echo e($remark[3]); ?></td>
                </tr>
                <tr>
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;KK</td>
                    <td>:</td>
                    <td><?php echo e($remark[4]); ?></td>
                </tr>
                <tr>
                    <td>10. Keperluan</td>
                    <td>:</td>
                    <td><?php echo e($dt->keperluan); ?></td>
                </tr>
                <tr>
                    <td>11. Berlaku</td>
                    <td>:</td>
                    <td><?php echo e($dt->tgl_req); ?> s.d <?php echo e(date('Y-m-d', strtotime($dt->tgl_req . ' +3 months'))); ?></td>
                </tr>
                <tr>
                    <td>12. Golongan Darah</td>
                    <td>:</td>
                    <td><?php echo e($remark[5]); ?></td>
                </tr>
            </table>

            <p><br>Demikian surat keterangan ini dibuat, untuk dipergunakan sebagaimana mestinya.</p>
            <div class="row" style="margin-top: 20%;">
                <?php if($dt->keperluan == 'Permohonan Pembuatan KTP (Kartu Tanda Penduduk)'): ?>
                <div class="col-lg-4 text-center">
                    Pemegang Surat
                    <p class="text" style="padding-top: 40%;font-weight: bold;text-decoration: underline;">
                        <?php echo e($dt->name); ?>

                    </p>
                </div>
                <div class="col-lg-4 text-center">
                    Mengetahui<br>Camat ...........................
                    <p class="text" style="padding-top: 30%;font-weight: bold;text-decoration: underline;">
                        ...............................
                    </p>
                </div>
                <div class="col-lg-4 text-center">
                    <?php echo e(tanggal_indonesia(date('Y-m-d'))); ?>

                    <br>
                    Kepala Desa <?php echo e(ucfirst(strtolower($ds->name_village))); ?>

                    <?php if($dt->ttd!==NULL): ?>
                    <br>
                    <img src="<?php echo e(asset($dt->ttd)); ?>" style="width: 60%;">
                    <?php else: ?>
                    <p class="text" style="padding-top: 23%;">
                    </p>
                    <?php endif; ?>
                    <p class="text">
                        <?php if(Auth::user()->level!=="Kepala Desa"): ?>
                        <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <b><u><?php echo e($kpl->name); ?></u></b>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <b><u><?php echo e(Auth::user()->name); ?></u></b>
                        <?php endif; ?>
                    </p>
                </div>
                <?php else: ?>
                <div class="col-lg-6 text-center">
                    Mengetahui : <br>Kepala Desa
                    <?php if($dt->ttd!==NULL): ?>
                    <br>
                    <img src="<?php echo e(asset($dt->ttd)); ?>" style="width: 60%;">
                    <?php else: ?>
                    <p class="text" style="padding-top: 23%;">
                    </p>
                    <?php endif; ?>
                    <p class="text">
                        <?php if(Auth::user()->level!=="Kepala Desa"): ?>
                        <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <b><u><?php echo e($kpl->name); ?></u></b>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <b><u><?php echo e(Auth::user()->name); ?></u></b>
                        <?php endif; ?>
                    </p>
                </div>
                <div class="col-lg-6 text-center">
                 <?php  
                 $tanggal_awal = tanggal_indonesia(date('Y-m-d'));
                 $tanggal_parts = explode(", ", $tanggal_awal);
                 ?>
                 <?php echo e(ucwords(strtolower($ds->name_village))); ?>, <?php echo e($tanggal_parts[1]); ?> <br>
                 PEMOHON
                 <p class="text" style="padding-top: 30%;font-weight: bold;text-decoration: underline;">
                    <?php echo e($dt->name); ?>

                </p>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-lg-2">

    </div>
</div>
</div><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ratdela\resources\views/page/desa/template/SURAT_KETERANGAN_PENGANTAR/SKP_1/cek.blade.php ENDPATH**/ ?>