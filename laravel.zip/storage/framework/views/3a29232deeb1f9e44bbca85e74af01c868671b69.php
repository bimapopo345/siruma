<div class="container mt-3" id="content_cek" style="background: white;">
    <div class="row">
        <div class="col-lg-2">

        </div>
        <div class="col-lg-8">
            <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <center>
                <img src="<?php echo e(asset('foto')); ?>/<?php echo e($ds->logo); ?>" alt="avatar" class="img pt-3" width="50" style="float: left;">
                PEMERINTAHAN <?php echo e($ds->name_city); ?> <br>
                KECAMATAN <?php echo e($ds->name_district); ?>

                <h4>KANTOR DESA <?php echo e($ds->name_village); ?></h4>
                <span><i><?php echo e($ds->lokasi_desa); ?></i></span>
            </center>
            <hr>
            <center>
                <h5 style="text-transform: uppercase;"><u><?php echo e($dt->nama_surat); ?></u></h5>
                Nomor : <?php echo e($dt->nomor_surat); ?>

            </center>
            <p style="text-align: left;" class="text mt-3">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Yang bertanda tangan dibawah ini adalah Kepala Desa <?php echo e(ucfirst(strtolower($ds->name_village))); ?> Kecamatan
                <?php echo e(ucfirst(strtolower($ds->name_district))); ?> <?php echo e(ucfirst(strtolower($ds->name_city))); ?>,
                <br>
                <br>
                Dengan ini menerangkan bahwa :
            </p>
            <table border="0">
                <tr>
                    <td>Nama</td>
                    <td>:</td>
                    <td><?php echo e($dt->name); ?></td>
                </tr>
                <tr>
                    <td>NIK</td>
                    <td>:</td>
                    <td><?php echo e($dt->nik); ?></td>
                </tr>
                <tr>
                    <td>Tempat/Tanggal Lahir</td>
                    <td>:</td>
                    <td><?php echo e($dt->tempat); ?>, <?php echo e(tanggal_indonesia($dt->tgl_lahir)); ?></td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td>:</td>
                    <td><?php echo e($dt->jenis_kelamin); ?></td>
                </tr>
                <tr>
                    <td>Agama</td>
                    <td>:</td>
                    <td><?php echo e($dt->agama); ?></td>
                </tr>
                <tr>
                    <td>Pekerjaan</td>
                    <td>:</td>
                    <td><?php echo e($dt->pekerjaan); ?></td>
                </tr>
                <tr>
                    <td>Status</td>
                    <td>:</td>
                    <td>
                        <?php  
                        $status = explode(";", $dt->remark);
                        ?>
                        <?php echo e($status[0]); ?>

                    </td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td>:</td>
                    <td><?php echo e($dt->alamat); ?></td>
                </tr>
                <tr>
                    <td>Maksud</td>
                    <td>:</td>
                    <td><?php echo e($dt->keperluan); ?></td>
                </tr>
            </table>
            <p style="text-align: center;" class="text mt-3">
                Bahwa orang diatas adalah penduduk Desa <?php echo e(ucfirst(strtolower($ds->name_village))); ?> Kecamatan <?php echo e(ucfirst(strtolower($ds->name_district))); ?> yang
                tergolong Rumah Tangga <b><u>Tidak Mampu/Miskin</u></b>
                <br>
                Demikian Surat Keterangan ini dibuat untuk dapat dipergunakan seperlunya. 
            </p>
            <div class="row">
                <div class="col-lg-6">
                </div>
                <div class="col-lg-6 text-center mt-3">
                    <?php echo e(ucfirst(strtolower($ds->name_village))); ?>, <?php echo e(tanggal_indonesia($dt->tgl_req)); ?> <br>
                    Kepala Desa <?php echo e(ucfirst(strtolower($ds->name_village))); ?>

                    <?php if($dt->ttd!==NULL): ?>
                    <br>
                    <img src="<?php echo e(asset($dt->ttd)); ?>" style="width: 60%;">
                    <?php else: ?>
                    <p class="text" style="padding-top: 23%;">
                    </p>
                    <?php endif; ?>
                    <p class="text">
                        <?php if(Auth::user()->level!=="Kepala Desa"): ?>
                        <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <b><u><?php echo e($kpl->name); ?></u></b>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <b><u><?php echo e(Auth::user()->name); ?></u></b>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-lg-2">

        </div>
    </div>
</div><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/page/desa/template/SURAT_KETERANGAN_TIDAK_MAMPU/SKTM_1/cek.blade.php ENDPATH**/ ?>