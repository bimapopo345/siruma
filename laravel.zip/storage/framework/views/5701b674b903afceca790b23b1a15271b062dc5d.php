<div class="col-lg-6">
	<h6>Keperluan</h6>
	<div class="form-group position-relative has-icon-left">
		<input type="text" required="" class="form-control" name="keperluan" value="">
		<div class="form-control-icon">
			<i class="dripicons dripicons-document-edit"></i>
		</div>
	</div>
</div>
<div class="col-lg-6">
	<h6>Untuk Usaha/Usaha yang dimiliki</h6>
	<div class="form-group position-relative has-icon-left">
		<input type="text" required="" class="form-control" name="nama_usaha" value="">
		<div class="form-control-icon">
			<i class="dripicons dripicons-document-edit"></i>
		</div>
	</div>
</div><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/pengaju/request/SURAT_KETERANGAN_USAHA/sku_1_form.blade.php ENDPATH**/ ?>