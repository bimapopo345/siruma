<?php if($_GET['keyword']=="cek-surat"): ?>
<?php echo $__env->make("$path_template_cek", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<center><h1>Tidak ada data di Temukan</h1></center>
<?php endif; ?><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/page/desa/template/SURAT_KETERANGAN_DOMISILI/SKD_2/SKD_2.blade.php ENDPATH**/ ?>