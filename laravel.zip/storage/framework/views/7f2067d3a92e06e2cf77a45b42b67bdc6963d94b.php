
<?php $__env->startSection('title','Dashboard Kepala Desa'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <section class="row">
        <div class="col-12">
            <div class="row">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php  
                $jml=DB::table('surat')->join('pengajuan','pengajuan.surat_id','=','surat.id_surat')->where('id_surat',$dt->id_surat)->where('pengajuan.selesai','=','Sudah di Konfirmasi')->count();
                ?>
                <div class="col-lg-3 mt-2">
                  <div class="card">
                    <div class="card-body">
                      <div class="card-title d-flex align-items-start justify-content-between">
                        <div class="avatar flex-shrink-0">
                            <i class="bx bxs-file-plus" style="font-size: 0.5in;color: <?php echo e($dt->bg); ?>"></i>
                        </div>
                        <div class="dropdown">
                          <button
                          class="btn p-0"
                          type="button"
                          id="cardOpt3"
                          data-bs-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                          >
                          <i class="bx bx-dots-vertical-rounded"></i>
                      </button>
                      <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt3">
                        <a class="dropdown-item" href=" <?php echo e(route('kepaladesa_acc',['id_surat'=>$dt->id_surat,'surat'=>$dt->singkatan])); ?> ">Lihat Detail</a>
                    </div>
                </div>
            </div>
            <span class="fw-semibold d-block mb-1"><?php echo e($dt->nama_surat); ?></span>
            <h3 class="card-title mb-2"><?php echo e($jml); ?></h3>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<!--  -->
<!--  -->
</div>
</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/desa/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Custom Produk\webdesa_siruma\resources\views/page/kepaladesa/home/home.blade.php ENDPATH**/ ?>