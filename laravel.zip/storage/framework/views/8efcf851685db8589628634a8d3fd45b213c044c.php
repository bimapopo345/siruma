<!DOCTYPE html>
<html lang="en">
<?php
$logodesa=DB::table('profil_desa')
->join('users','users.id','=','profil_desa.user_id')
->where('users.title_user',session('kodeakses'))->get();
?>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php $__currentLoopData = $logodesa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lgd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <meta property="og:image" content="<?php echo e(asset('foto')); ?>/<?php echo e($lgd->logo); ?>">
  <title><?php echo $__env->yieldContent('title'); ?> | Web Surat Permohonan</title>
  <link rel="shortcut icon" type="image/x-generic" href="<?php echo e(asset('foto')); ?>/<?php echo e($lgd->logo); ?>">
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/bootstrap.css')); ?>">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/iconly/bold.css')); ?>">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap4.min.css">
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css"> -->
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/simple-datatables/style.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/dripicons/webfont.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/pages/dripicons.css')); ?>">
  <script src="<?php echo e(asset('javascript-css/canva.js')); ?>"></script> 
  <link href="<?php echo e(asset('javascript-css/foto.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/toastify/toastify.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/sweetalert2/sweetalert2.min.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/perfect-scrollbar/perfect-scrollbar.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/app.css')); ?>">

  <script src="<?php echo e(asset('canva.js')); ?>"></script>
  <script type="text/javascript" 
  src="http://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <link type="text/css" 
  href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/south- 
  street/jquery-ui.css" rel="stylesheet">
  <script type="text/javascript" 
  src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"> 
</script>
<script type="text/javascript" src="http://keith-wood.name/js/jquery.signature.js"> 
</script>

<link rel="stylesheet" type="text/css" href="http://keith- 
wood.name/css/jquery.signature.css">

<style>
  .kbw-signature { width: 50%; height: 90px;}
  #sig canvas{
    width: 100% !important;
    height: auto;
  }
  .modal-loading {
    display: flex;
    justify-content: center;
    align-items: center;
    position: absolute;
    top: 50%;
    left: 50%;
    z-index: 9999;
    visibility: hidden;
  }
  .modal-body {
    position: relative;
  }
  .modal.show .modal-loading {
    visibility: visible;
  }
  #loading {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0.8);
    z-index: 9999;
    text-align: center;
    padding-top: 20%;
  }
</style>
<?php echo $__env->yieldContent('css'); ?>
</head>

<body>
  <?php $__currentLoopData = $logodesa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lgd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div itemprop="image" itemscope="itemscope" itemtype="http://schema.org/ImageObject">
    <meta content="<?php echo e(asset('foto')); ?>/<?php echo e($lgd->logo); ?>" itemprop="url"/> </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div id="app">
      <?php echo $__env->make('desa/layout/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div id="main">
        <header class="mb-3">
          <a href="#" class="burger-btn d-block d-xl-none">
            <i class="bi bi-justify fs-3"></i>
          </a>
        </header>
        <?php echo $__env->yieldContent('content'); ?>

      </div>
    </div>

    <script src="<?php echo e(asset('template/dist/assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/dist/assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap4.min.js"></script>
   <!--  <script src="<?php echo e(asset('template/dist/assets/vendors/simple-datatables/simple-datatables.js')); ?>"></script>
    <script>
        // Simple Datatable
        let table1 = document.querySelector('#table1');
        let dataTable = new simpleDatatables.DataTable(table1);
      </script> -->
      <!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script> -->
      <script src="<?php echo e(asset('template/dist/assets/vendors/apexcharts/apexcharts.js')); ?>"></script>
      <script src="<?php echo e(asset('template/dist/assets/js/pages/dashboard.js')); ?>"></script>
      <script src="<?php echo e(asset('template/dist/assets/js/main.js')); ?>"></script>
      <!-- <script src="<?php echo e(asset('green/assets/js/not.js')); ?>"></script> -->
      <!-- <script src="<?php echo e(asset('green/assets/js/disabledi.js')); ?>"></script> -->
      <!-- <script src="<?php echo e(asset('green/assets/js/default.js')); ?>"></script> -->
      <script src="<?php echo e(asset('template/dist/assets/vendors/toastify/toastify.js')); ?>"></script>
      <script src="<?php echo e(asset('template/dist/assets/js/extensions/toastify.js')); ?>"></script>
      <script src="<?php echo e(asset('template/dist/assets/js/extensions/sweetalert2.js')); ?>"></script>
      <script src="<?php echo e(asset('template/dist/assets/vendors/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
      <!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script> -->
      <script type="text/javascript">
        $("#table1").DataTable();
      </script>
      <script type="text/javascript">
        var sig = $('#sig').signature({syncField: '#signature64', syncFormat: 'PNG'});
        $('#clear').click(function(e) {
          e.preventDefault();
          sig.signature('clear');
          $("#signature64").val('');
        });
      </script>
      <script type="text/javascript">


        $(document).ready(function() {
          $("#copy").hide();
          $("#add-more").click(function(){ 
            var html = $("#copy").html();
            $("#after-add-more").after(html);
          });

      // saat tombol remove dklik control group akan dihapus 
      $("body").on("click","#remove",function(){ 
        $(this).parents("#control-group").remove();
      });
    });

        
  </script>
  <script>
    function readURL(input) {
      if (input.files && input.files[0]) {

        var reader = new FileReader();

        reader.onload = function(e) {
          $('.image-upload-wrap').hide();

          $('.file-upload-image').attr('src', e.target.result);
          $('.file-upload-content').show();

          $('.image-title').html(input.files[0].name);
        };

        reader.readAsDataURL(input.files[0]);

      } else {
        removeUpload();
      }
    }

    function removeUpload() {
      $('.file-upload-input').replaceWith($('.file-upload-input').clone());
      $('.file-upload-content').hide();
      $('.image-upload-wrap').show();
    }
    $('.image-upload-wrap').bind('dragover', function () {
      $('.image-upload-wrap').addClass('image-dropping');
    });
    $('.image-upload-wrap').bind('dragleave', function () {
      $('.image-upload-wrap').removeClass('image-dropping');
    });
  </script>
  <script type="text/javascript">
    function show_loading() {
      var elemenModalLoading = document.getElementsByClassName('modal-loading');
      var ModalBody = document.getElementsByClassName('modal-body');
      for (var i = 0; i < elemenModalLoading.length; i++) {
        elemenModalLoading[i].style.display = "block";
      }
      for (var i = 0; i < ModalBody.length; i++) {
        ModalBody[i].style.pointerEvents = "none";
        ModalBody[i].style.background = 'white';
        ModalBody[i].style.opacity = '0.4';
      }
    }
    function hide_loading() {
      var elemenModalLoading = document.getElementsByClassName('modal-loading');
      var ModalBody = document.getElementsByClassName('modal-body');
      for (var i = 0; i < elemenModalLoading.length; i++) {
        elemenModalLoading[i].style.display = "none";
      }
      for (var i = 0; i < ModalBody.length; i++) {
        ModalBody[i].style.pointerEvents = "auto";
        ModalBody[i].style.background = "transparent";
        ModalBody[i].style.opacity = '1';
      }
    }
  </script>
  <script type="text/javascript">
   $(document).ready(function() {
    // Mendapatkan URL saat ini
    var currentUrl = window.location.href;

    // Menemukan elemen yang sesuai dengan URL
    var activeLink = $("ul#menu a").filter(function() {
        return this.href == currentUrl;
    });

    // Menambahkan kelas 'active' pada elemen yang sesuai
    activeLink.addClass("active");

    // Menambahkan kelas 'active' pada parent elemen (li) jika ada
    activeLink.parents("li").addClass("active");

    // Menambahkan kelas 'in' pada parent elemen (ul) dari submenu
    activeLink.parents("ul.submenu").addClass("in");

    // Menambahkan kelas 'active' pada parent elemen (li) dari submenu
    activeLink.parents("li.submenu-item").addClass("active");

    // Membuka submenu yang sesuai dengan hierarki
    activeLink.parents("ul.submenu").slideDown();
});


</script>
</body>
<?php echo $__env->make('desa/layout/notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('scripts'); ?>
</html><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/desa/layout/app.blade.php ENDPATH**/ ?>