<div class="col-xl-12">
	<h6>Keterangan/Keperluan <span class="text-danger">*</span></h6>
	<div class="form-group position-relative">
		<input type="text" id="keperluan" required="" class="form-control" name="keperluan" value="">
		<span class="invalid-feedback" role="alert" id="keperluanError">
			<strong></strong>
		</span>
	</div>
</div><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/page/pengaju/request/SURAT_KETERANGAN_DOMISILI/skd_form.blade.php ENDPATH**/ ?>