            <div class="modal fade text-left" data-bs-backdrop="static" id="modal_form_profil" tabindex="-1"
            role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"
            role="document">
            <div class="modal-content" style="border-bottom:1px solid blue;">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel33"></h4>
                </div>
                <div class="modal-body">
                    <form method="post" id="profilForm" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <label>EMAIL:</label>
                                <div class="form-group">
                                    <input type="email" id="email" value="<?php echo e($cst->email); ?>" name="email"
                                    class="form-control">
                                    <span class="invalid-feedback" role="alert" id="emailError">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <label>NAME:</label>
                                <div class="form-group">
                                    <input type="text" id="name" value="<?php echo e($cst->name); ?>" name="name"
                                    class="form-control">
                                    <span class="invalid-feedback" role="alert" id="nameError">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <?php if(Auth::user()->level == "Pengaju"): ?>
                            <div class="col-lg-6">
                                <label>PEKERJAAN:</label>
                                <div class="form-group">
                                    <input type="text" id="pekerjaan" value="<?php echo e($cst->pekerjaan); ?>" name="pekerjaan"
                                    class="form-control">
                                    <span class="invalid-feedback" role="alert" id="pekerjaanError">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <?php else: ?>
                            <div class="col-lg-6">
                                <label>JABATAN:</label>
                                <div class="form-group">
                                    <select class="form-control" disabled="" id="level" name="level">
                                        <option <?php if($cst->level=="Staff"){echo "selected";} ?> value="Staff">Staff</option>
                                        <option <?php if($cst->level=="Kepala Desa"){echo "selected";} ?> value="Kepala Desa">Kepala Desa</option>
                                    </select>
                                    <span class="invalid-feedback" role="alert" id="levelError">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>

                            <?php endif; ?>
                            <div class="col-lg-6">
                                <label>PONSEL:</label>
                                <div class="form-group">
                                    <input type="number" id="telepon" value="<?php echo e($cst->telepon); ?>" name="telepon" 
                                    class="form-control">
                                    <span class="invalid-feedback" role="alert" id="teleponError">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <label>NIK:</label>
                                <div class="form-group">
                                    <input type="number" id="nik" name="nik" value="<?php echo e($cst->nik); ?>"
                                    class="form-control">
                                    <span class="invalid-feedback" role="alert" id="nikError">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <label>AGAMA:</label>
                                <div class="form-group">
                                    <input type="text" id="agama" name="agama" value="<?php echo e($cst->agama); ?>"
                                    class="form-control">
                                    <span class="invalid-feedback" role="alert" id="agamaError">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <label>TEMPAT LAHIR:</label>
                                <div class="form-group">
                                    <input type="text" id="tempat" name="tempat" value="<?php echo e($cst->tempat); ?>"
                                    class="form-control">
                                    <span class="invalid-feedback" role="alert" id="tempatError">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <label>JENIS KELAMIN:</label>
                                <div class="form-group">
                                    <select class="form-control" id="jenis_kelamin" name="jenis_kelamin">
                                        <option <?php if($cst->jenis_kelamin=="Laki-Laki"){echo "selected";} ?> value="Laki-Laki">Laki-Laki</option>
                                        <option <?php if($cst->jenis_kelamin=="Perempuan"){echo "selected";} ?> value="Perempuan">Perempuan</option>
                                    </select>
                                    <span class="invalid-feedback" role="alert" id="jenis_kelaminError">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <label>TANGGAL LAHIR:</label>
                                <div class="form-group">
                                    <input type="date" name="tgl_lahir" id="tgl_lahir" value="<?php echo e($cst->tgl_lahir); ?>"
                                    class="form-control">
                                    <span class="invalid-feedback" role="alert" id="tgl_lahirError">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-xl-12">
                                <label>FOTO PROFIL:</label>
                                <div class="form-group">
                                    <input type="file" name="foto"
                                    class="form-control">
                                    <input type="text" hidden="" value="<?php echo e($cst->foto); ?>" name="fotoLama">
                                </div>
                            </div>
                            <div class="col-xl-12">
                                <label>ALAMAT: </label>
                                <div class="form-group">
                                    <textarea class="form-control" id="alamat" rows="4" name="alamat"><?php echo e($cst->alamat); ?></textarea>
                                    <span class="invalid-feedback" role="alert" id="alamatError">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-loading" id="modal-loading" style="display: none;">
                        <span class="fa fa-circle-o-notch fa-pulse fa-3x"></span>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light-secondary"
                        data-bs-dismiss="modal">
                        <span>Tutup</span>
                    </button>
                    <button type="submit" class="btn btn-primary ml-1">
                        <span><i class="fa fa-save"></i> Simpan</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/pengaju/profil/ubah.blade.php ENDPATH**/ ?>