<div class="container mt-3" id="content_cek" style="background: white;">
    <div class="row">
        <div class="col-lg-2">

        </div>
        <div class="col-lg-8">
            <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <center>
                <img src="<?php echo e(asset('foto')); ?>/<?php echo e($ds->logo); ?>" alt="avatar" class="img pt-3" width="75" style="float: left;">
                PEMERINTAHAN <?php echo e($ds->name_city); ?> <br>
                KECAMATAN <?php echo e($ds->name_district); ?>

                <h4>DESA <?php echo e($ds->name_village); ?></h4>
                <span><i><?php echo e($ds->lokasi_desa); ?></i></span>
            </center>
            <hr>
            <span>No. Kode Desa / Kelurahan<br>13 18 14 2011</span>
            <center>
                <h5 style="text-transform: uppercase;" class="text mt-3"><u><?php echo e($dt->nama_surat); ?></u><br><span style="font-size: 15px;">Nomor : <?php echo e($dt->nomor_surat); ?></span></h5>
                
            </center>
            <p style="text-align: center;">
                Yang bertanda tangan dibawah ini menerangkan bahwa :
            </p>
            <table border="0" style="width: 100%;">
                <?php  
                $remark = explode(";", $dt->remark);
                ?>
                <tr>
                    <td>1. Nama</td>
                    <td>:</td>
                    <td style="border-bottom: 1px solid #eee;"><?php echo e($dt->name); ?></td>
                </tr>
                <tr>
                    <td>2. Tempat Tanggal Lahir</td>
                    <td>:</td>
                    <td style="border-bottom: 1px solid #eee;"><?php echo e($dt->tempat); ?>, <?php echo e($dt->tgl_lahir); ?></td>
                </tr>
                <tr>
                    <td>3. Kewarganegaraan / Agama</td>
                    <td>:</td>
                    <td style="border-bottom: 1px solid #eee;"><?php echo e($dt->remark[0]); ?>, <?php echo e($dt->remark[1]); ?></td>
                </tr>
                <tr>
                    <td>4. Pekerjaan</td>
                    <td>:</td>
                    <td style="border-bottom: 1px solid #eee;"><?php echo e($dt->pekerjaan); ?></td>
                </tr>
                <tr>
                    <td>5. Tempat Tinggal</td>
                    <td>:</td>
                    <td style="border-bottom: 1px solid #eee;"><?php echo e($dt->tempat); ?></td>
                </tr>
                <tr>
                    <td>6. Surat bukti diri</td>
                    <td>:</td>
                    <td style="border-bottom: 1px solid #eee;">No NIK : <?php echo e($remark[2]); ?></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td style="border-bottom: 1px solid #eee;">No KK : <?php echo e($remark[3]); ?></td>
                </tr>
                <tr>
                    <td>Keperluan</td>
                    <td>:</td>
                    <td style="border-bottom: 1px solid #eee;"><?php echo e($dt->keperluan); ?></td>
                </tr>
                <tr>
                    <td>Berlaku mulai</td>
                    <td>:</td>
                    <td style="border-bottom: 1px solid #eee;"><?php echo e($dt->tgl_req); ?> s.d <?php echo e(date('Y-m-d', strtotime($dt->tgl_req . ' +3 months'))); ?></td>
                </tr>
                <tr>
                    <td>Keterangan lain</td>
                    <td>:</td>
                    <td style="border-bottom: 1px solid #eee;">Orang tersebut diatas benar-benar Penduduk Desa <?php echo e(ucfirst(strtolower($ds->name_village))); ?> Kec.<?php echo e(ucfirst(strtolower($ds->name_district))); ?> <?php echo e(ucfirst(strtolower($ds->name_city))); ?> dan berkelakuan Baik</td>
                </tr>
            </table>
            <p style="text-align: center;"><br>Demikianlah untuk menjadikan maklum bagi yang berkepentingan</p>
            <div class="row" style="margin-top: 1in;">
                <div class="col-lg-6 text-center">
                    <?php  
                    $tanggal_awal = tanggal_indonesia(date('Y-m-d'));
                    $tanggal_parts = explode(", ", $tanggal_awal);
                    ?>
                    Tanda tangan pemegang
                    <p class="text" style="padding-top: 30%;font-weight: bold;text-decoration: underline;">
                        <?php echo e($dt->name); ?>

                    </p>

                </div>
                <div class="col-lg-6 text-center">
                    <?php echo e(ucfirst(strtolower($ds->name_village))); ?>, <?php echo e(date('d F Y')); ?>

                    <?php if($dt->ttd!==NULL): ?>
                    <img src="<?php echo e(asset($dt->ttd)); ?>" style="width: 60%;">
                    <?php else: ?>
                    <p class="text" style="padding-top: 17%;">
                    </p>
                    <?php endif; ?>
                    <p class="text">
                        <?php if(Auth::user()->level!=="Kepala Desa"): ?>
                        <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <b><u><?php echo e($kpl->name); ?></u></b>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <b><u><?php echo e(Auth::user()->name); ?></u></b>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-lg-2">

        </div>
    </div>
</div><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ratdela\resources\views/page/desa/template/SURAT_KETERANGAN_PENGANTAR_NIKAH/SKPN_1/cek.blade.php ENDPATH**/ ?>