<!DOCTYPE html>
<html lang="en">
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($dt->nomor_surat); ?></title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/bootstrap.css')); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/dripicons/webfont.css')); ?>"> -->
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/pages/dripicons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/app.css')); ?>">
</head>
<style type="text/css">
    .footer_right {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        text-align: right;
        padding: 10px;
    }
    .footer_center {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        text-align: center;
        padding: 10px;
    }
    .footer_left {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        text-align: left;
        padding: 10px;
    }
    .signature {
        display: inline-block;
        text-align: center;
        width: 50%; /* Adjust the width as needed */
        margin: 0 auto;
    }
</style>
<body style="background: white;color: black;">
    <div class="container-fluid" style="background: white;">
        <div class="row">
            <div class="col-xl-12">
                <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <center>
                    <img src="<?php echo e(asset('foto')); ?>/<?php echo e($ds->logo); ?>" alt="avatar" class="img" width="90" style="float: left;">
                    <b>PEMERINTAHAN <?php echo e($ds->name_city); ?> <br>
                        KECAMATAN <?php echo e($ds->name_district); ?></b>
                        <h5 style="color: black;">DESA <?php echo e($ds->name_village); ?></h5>
                        <span><?php echo e($ds->lokasi_desa); ?></span>
                    </center>
                    <hr>
                    <center>
                        <span style="font-size: 15px;text-transform: uppercase;font-weight: bold;text-decoration: underline;"><?php echo e($dt->nama_surat); ?></span>
                        <br>
                        <span>Nomor : <?php echo e($dt->nomor_surat); ?></span>
                    </center>
                    <p style="text-align: left;margin-top: 20px;">
                        Yang bertanda tangan dibawah ini Kepala Desa <?php echo e(ucwords(strtolower($ds->name_village))); ?>, Kecamatan <?php echo e(ucwords(strtolower($ds->name_district))); ?>, <?php echo e(ucwords(strtolower($ds->name_city))); ?>, Provinsi <?php echo e(ucwords(strtolower($ds->name_province))); ?> menerangkan dengan sebenarnya bahwa :
                    </p>
                    <table border="0">
                        <?php  
                        $remark = explode(";", $dt->remark);
                        ?>
                        <tr>
                            <td>1. Nama</td>
                            <td>:</td>
                            <td><?php echo e($dt->name); ?></td>
                        </tr>
                        <tr>
                            <td>2. Tempat Tanggal Lahir</td>
                            <td>:</td>
                            <td><?php echo e($dt->tempat); ?>, <?php echo e($dt->tgl_lahir); ?></td>
                        </tr>
                        <tr>
                            <td>3. Umur</td>
                            <td>:</td>
                            <td><?php echo e($remark[0]); ?></td>
                        </tr>
                        <tr>
                            <td>4. Warga Negara</td>
                            <td>:</td>
                            <td><?php echo e($remark[1]); ?></td>
                        </tr>
                        <tr>
                            <td>5. Agama</td>
                            <td>:</td>
                            <td><?php echo e($remark[2]); ?></td>
                        </tr>
                        <tr>
                            <td>6. Jenis Kelamin</td>
                            <td>:</td>
                            <td><?php echo e($dt->jenis_kelamin); ?></td>
                        </tr>
                        <tr>
                            <td>7. Pekerjaan</td>
                            <td>:</td>
                            <td><?php echo e($dt->pekerjaan); ?></td>
                        </tr>
                        <tr>
                            <td>8. Tempat tinggal</td>
                            <td>:</td>
                            <td><?php echo e($dt->alamat); ?></td>
                        </tr>
                        <tr>
                            <td>9. Surat bukti diri</td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;NIK</td>
                            <td>:</td>
                            <td><?php echo e($remark[3]); ?></td>
                        </tr>
                        <tr>
                            <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;KK</td>
                            <td>:</td>
                            <td><?php echo e($remark[4]); ?></td>
                        </tr>
                        <tr>
                            <td>10. Keperluan</td>
                            <td>:</td>
                            <td><?php echo e($dt->keperluan); ?></td>
                        </tr>
                        <tr>
                            <td>11. Berlaku</td>
                            <td>:</td>
                            <td><?php echo e($dt->tgl_req); ?> s.d <?php echo e(date('Y-m-d', strtotime($dt->tgl_req . ' +3 months'))); ?></td>
                        </tr>
                        <tr>
                            <td>12. Golongan Darah</td>
                            <td>:</td>
                            <td><?php echo e($remark[5]); ?></td>
                        </tr>
                    </table>
                    <p><br>Demikian surat keterangan ini dibuat, untuk dipergunakan sebagaimana mestinya.</p>
                    <div class="footer_left">
                        <div class="signature" style="text-align: left;">
                            <div>Pemegang Surat</div>
                            <div><br></div>
                            <div><br></div>
                            <div><br></div>
                            <div><br></div>
                            <div style="font-weight: bold;text-decoration: underline;"><?php echo e($dt->name); ?></div>
                        </div>
                    </div>
                    <?php if($dt->keperluan == 'Permohonan Pembuatan KTP (Kartu Tanda Penduduk)'): ?>
                    <div class="footer_center">
                        <div class="signature" style="text-align: center;">
                            <div>Mengetahui</div>
                             <div>Camat ......................</div>
                            <div><br></div>
                            <div><br></div>
                            <div><br></div>
                            <div style="font-weight: bold;text-decoration: underline;">.....................................</div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="footer_right">
                        <div class="signature" style="text-align: right;">
                            <div><?php echo e(tanggal_indonesia(date('Y-m-d'))); ?></div>
                            <div>Kepala Desa <?php echo e(ucfirst(strtolower($ds->name_village))); ?></div>
                            <div><img src="<?php echo e(asset($dt->ttd)); ?>" class="text" height="95"></div>
                            <div>
                               <?php if(Auth::user()->level!=="Kepala Desa"): ?>
                               <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <p><b><u><?php echo e($kpl->name); ?></u></b></p>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               <?php else: ?>
                               <p><b><u><?php echo e(Auth::user()->name); ?></u></b></p>
                               <?php endif; ?>
                           </div>
                       </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </div>
               </div>
           </div>
       </body>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </html><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ladar\resources\views/page/desa/template/SURAT_KETERANGAN_PENGANTAR/SKP_1/print.blade.php ENDPATH**/ ?>