            <div class="modal fade text-left" id="inlineFormprofil" tabindex="-1"
            role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"
            role="document">
            <div class="modal-content" style="border-bottom:1px solid blue;">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel33">Tambah Data Pengurus </h4>
                    <button type="button" class="close" data-bs-dismiss="modal"
                    aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" action="<?php echo e(route('update_profil_pengurus')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <label>EMAIL:</label>
                            <div class="form-group">
                                <input type="email" value="<?php echo e($cst->email); ?>" name="email"
                                class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <label>NAME:</label>
                            <div class="form-group">
                                <input type="text" value="<?php echo e($cst->name); ?>" name="name"
                                class="form-control">
                            </div>
                        </div>
                        <?php if(Auth::user()->level=="Pengaju"): ?>
                        <div class="col-lg-6">
                            <label>PEKERJAAN:</label>
                            <div class="form-group">
                                <input type="text" value="<?php echo e($cst->pekerjaan); ?>" name="pekerjaan"
                                class="form-control">
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="col-lg-6">
                            <label>JABATAN:</label>
                            <div class="form-group">
                                <select class="form-control" name="level">
                                    <option <?php if($cst->level=="Staff"){echo "selected";} ?> value="Staff">Staff</option>
                                    <option <?php if($cst->level=="Kepala Desa"){echo "selected";} ?> value="Kepala Desa">Kepala Desa</option>
                                </select>
                            </div>
                        </div>

                        <?php endif; ?>
                        <div class="col-lg-6">
                            <label>PONSEL:</label>
                            <div class="form-group">
                                <input type="number" value="<?php echo e($cst->telepon); ?>" name="telepon" 
                                class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <label>NIK:</label>
                            <div class="form-group">
                                <input type="number" name="nik" value="<?php echo e($cst->nik); ?>"
                                class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <label>AGAMA:</label>
                            <div class="form-group">
                                <input type="text" name="agama" value="<?php echo e($cst->agama); ?>"
                                class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <label>TEMPAT LAHIR:</label>
                            <div class="form-group">
                                <input type="text" name="tempat" value="<?php echo e($cst->tempat); ?>"
                                class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <label>JENIS KELAMIN:</label>
                            <div class="form-group">
                                <select class="form-control" name="jenis_kelamin">
                                    <option <?php if($cst->jenis_kelamin=="Laki-Laki"){echo "selected";} ?> value="Laki-Laki">Laki-Laki</option>
                                    <option <?php if($cst->jenis_kelamin=="Perempuan"){echo "selected";} ?> value="Perempuan">Perempuan</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <label>TANGGAL LAHIR:</label>
                            <div class="form-group">
                                <input type="date" name="tgl_lahir" value="<?php echo e($cst->tgl_lahir); ?>"
                                class="form-control">
                            </div>
                        </div>
                        <div class="col-xl-12">
                            <label>FOTO PROFIL:</label>
                            <div class="form-group">
                                <input type="file" name="foto"
                                class="form-control">
                            </div>
                        </div>
                        <div class="col-xl-12">
                            <label>ALAMAT: </label>
                            <div class="form-group">
                                <textarea class="form-control" rows="4" name="alamat"><?php echo e($cst->alamat); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light-secondary"
                    data-bs-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Close</span>
                </button>
                <button type="submit" class="btn btn-primary ml-1">
                    <i class="bx bx-check d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Accept</span>
                </button>
            </div>
        </form>
    </div>
</div>
</div><?php /**PATH E:\xampp\htdocs\desa\resources\views/pengaju/profil/ubah.blade.php ENDPATH**/ ?>