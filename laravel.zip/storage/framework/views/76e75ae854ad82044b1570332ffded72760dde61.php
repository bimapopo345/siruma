

<?php $__env->startSection('title','Data Desa Mendaftar'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <section class="section">
        <div class="card">
            <div class="card-header">
                Table Desa Mendaftar
            </div>
            <div class="card-body">
                <table class="table table-striped" id="table1">
                    <thead>
                        <tr>
                            <th>No. </th>
                            <th>Email User</th>
                            <th>Provinsi</th>
                            <th>Kota</th>
                            <th>Kecamatan</th>
                            <th>Desa</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no=1; ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?=$no; ?>. </th>
                            <td><?php echo e($pgn->email); ?></td>
                            <td><?php echo e($pgn->name_province); ?></td>
                            <td><?php echo e($pgn->name_city); ?></td>
                            <td><?php echo e($pgn->name_district); ?></td>
                            <td><?php echo e($pgn->name_village); ?></td>
                            <td>
                                <?php if($pgn->status_user=="True"): ?>
                                <span class="badge bg-primary"><?php echo e($pgn->status_user); ?></span>
                                <?php else: ?>
                                <span class="badge bg-danger"><?php echo e($pgn->status_user); ?></span>
                                <?php endif; ?>
                            </td>
                            <td align="center">
                                <a href="<?php echo e(route('cek_berkas',$pgn->id)); ?>" class="btn btn-sm btn-success rounded-pill"><i class="icon dripicons-preview"></i></a>
                            </td>
                        </tr>
                        <?php $no++ ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('desa/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\PRODUK WEB\desa\resources\views/admin/user.blade.php ENDPATH**/ ?>