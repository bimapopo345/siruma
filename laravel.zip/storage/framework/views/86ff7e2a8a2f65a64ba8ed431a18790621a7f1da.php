

<?php $__env->startSection('title','QR CODE DESA'); ?>

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="page-heading">
  <h2>Unduh QR CODE Kantor Kelurahan anda.</h2>
  <section class="section">
    <div class="row mb-3">
      <div class="col-lg-4">
        <input id="btn-Preview-Image" class="btn btn-sm btn-primary form-control" type="button" value="Tampilkan" />  
      </div>
      <div class="col-lg-4">
        <a id="btn-Convert-Html2Image" class="btn btn-sm btn-success form-control text-white" href="#">Unduh</a> 
      </div>
    </div>
    <div class="row bg-light" id="html-content-holder" style="font-family: calibri">
      <div class="col-xl-12 bg-primary text-primary mb-5">
        ..
      </div>
      <div class="col-xl-12 text-center">
        <img src="<?php echo e(asset('foto')); ?>/<?php echo e($dt->logo); ?>" alt="QR CODE" width="80">
        <h1>SCAN DI SINI</h1>
        Untuk masuk ke Halaman Desa dan membuat Permohonan Surat
        <br>
        Scan Kode QR untuk masuk ke Halaman Web Desa <br>
        <a href="data:image/png;base64, <?php echo base64_encode(QrCode::format('png')->size(150)->generate(Auth::user()->title_user)); ?>" download=""><img src="data:image/png;base64, <?php echo base64_encode(QrCode::format('png')->size(150)->generate(Auth::user()->title_user)); ?>" class="text mt-3 mb-3" /></a>
        <h3>HALAMAN UTAMA WEB DESA</h3>
        KANTOR KELURAHAN <?php echo e($dt->name_village); ?> KECAMATAN <?php echo e($dt->name_district); ?> <br>
        <?php echo e($dt->name_province); ?> <?php echo e($dt->name_city); ?>

        <br>
        <button class="btn btn-sm btn-primary">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CARA SCAN QR CODE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button>
      </div>
      <div class="col-lg-6 text-center">
        <span>1. <b>Buka/Akses Website <span class="text text-primary">by.danteproject.site</span></b></span><br>
        Kunjungi Website <span class="text text-primary">by.danteproject.site</span> <br> melalui Browser atau Scan QR Code di atas.
      </div>
      <div class="col-lg-6 text-center">
        2. <b>Buat Akun</b><br>
        Lakukan Registrasi untuk membuat Akun.
        <br>
        Jika sudah mempunyai Akun <br>Silahkan Login dengan Akun tersebut.
      </div>
      <div class="col-xl-12 text-center">
        3. <b>Pengajuan Surat</b><br>
        Buat Surat Pengajuan/Permohonan anda sesuai Surat yang di sediakan oleh <br>Kantor Kelurahan.
      </div>
      <div class="col-xl-12 bg-primary text-primary mt-5">
        ..
      </div>
    </div>

  </section>

</div>
<div id="previewImage"></div> 
<script> 
  $(document).ready(function() { 

    $("#btn-Convert-Html2Image").hide();

    var element = $("#html-content-holder");  

    var getCanvas;  
    $("#btn-Preview-Image").on('click', function() {
      $("#btn-Convert-Html2Image").show(); 
      html2canvas(element, { 
        onrendered: function(canvas) { 
          $("#previewImage").append(canvas); 
          getCanvas = canvas; 
        } 
      }); 
    }); 
    $("#btn-Convert-Html2Image").on('click', function() { 
      var imgageData =  
      getCanvas.toDataURL("image/jpg",1); 

      var newData = imgageData.replace( 
        /^data:image\/jpg/, "data:application/octet-stream"); 

      $("#btn-Convert-Html2Image").attr( 
        "download", "QR CODE DESA <?php echo e($dt->title_user); ?>.jpg").attr( 
        "href", newData); 
      }); 
  }); 
</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('desa/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\desa\resources\views/desa/barcode/index.blade.php ENDPATH**/ ?>