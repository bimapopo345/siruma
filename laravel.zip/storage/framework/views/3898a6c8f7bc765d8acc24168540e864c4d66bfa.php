<div class="col-lg-6">
	<h6>Maksud <span class="text-danger">*</span></h6>
	<div class="form-group position-relative">
		<input type="text" id="keperluan" required="" class="form-control" name="keperluan">
		<span class="invalid-feedback" role="alert" id="keperluanError">
			<strong></strong>
		</span>
	</div>
</div>
<div class="col-lg-6">
	<h6>Status <span class="text-danger">*</span></h6>
	<div class="form-group position-relative">
		<input type="text" id="status" class="form-control" name="status" value="" placeholder="Mahasiswa/Pelajar/Pekerja/Umum/Dll">
		<span class="invalid-feedback d-block" role="alert" id="statusError">
			<strong></strong>
		</span>
	</div>
</div><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/pengaju/request/SURAT_KETERANGAN_TIDAK_MAMPU/sktm_1_form.blade.php ENDPATH**/ ?>