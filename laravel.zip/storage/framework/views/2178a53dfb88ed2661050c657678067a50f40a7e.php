<div class="col-lg-6">
	<div class="row">
		<div class="col-lg-6">
			<label>Nama Wali/Ortu <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="text" id="nama" class="form-control" name="nama">
				<span class="invalid-feedback d-block" role="alert" id="namaError">
					<strong></strong>
				</span>
			</div>
		</div>
		<div class="col-lg-6">
			<label>NIK <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="number" id="nik" class="form-control" name="nik">
				<span class="invalid-feedback d-block" role="alert" id="nikError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-6">
			<label>Tempat Lahir <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="text" id="tempat_lahir" class="form-control" name="tempat_lahir">
				<span class="invalid-feedback d-block" role="alert" id="tempat_lahirError">
					<strong></strong>
				</span>
			</div>
		</div>
		<div class="col-lg-6">
			<label>Tanggal Lahir <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="date" id="tanggal_lahir" class="form-control" name="tanggal_lahir">
				<span class="invalid-feedback d-block" role="alert" id="tanggal_lahirError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-6">
			<label>Pekerjaan <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="text" id="pekerjaan" class="form-control" name="pekerjaan">
				<span class="invalid-feedback d-block" role="alert" id="pekerjaanError">
					<strong></strong>
				</span>
			</div>
		</div>
		<div class="col-lg-6">
			<label>Jenis Kelamin <span class="text-danger">*</span></label>
			<div class="form-group">
				<select class="form-control" id="jenis_kelamin" name="jenis_kelamin">
					<option value="">:. PILIH JENIS KELAMIN .:</option>
					<option value="Laki-Laki">Laki-Laki</option>
					<option value="Perempuan">Perempuan</option>
				</select>
				<span class="invalid-feedback d-block" role="alert" id="jenis_kelaminError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
</div>
<div class="col-lg-6">
	<div class="row">
		<div class="col-lg-12">
			<label>Penghasilan <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="text" id="penghasilan" class="form-control" name="penghasilan">
				<span class="invalid-feedback d-block" role="alert" id="penghasilanError">
					<strong></strong>
				</span>
			</div>
		</div>
		<div class="col-lg-12">
			<label>Untuk Keperluan <span class="text-danger">*</span></label>
			<div class="form-group">
				<input type="text" required="" id="keperluan" class="form-control" name="keperluan">
				<span class="invalid-feedback d-block" role="alert" id="keperluanError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-xl-12">
			<label>Berkas Persyaratan <span class="text-danger">*</span></label>
			<div class="form-group position-relative">
				<input type="file" name="berkas" id="berkas" class="form-control">
				<span class="invalid-feedback" role="alert" id="berkasError">
					<strong></strong>
				</span>
			</div>
		</div>
	</div>
</div>
<div class="col-lg-12">
	<label>Alamat <span class="text-danger">*</span></label>
	<div class="form-group">
		<textarea class="form-control" rows="4" id="alamat" name="alamat"></textarea>
		<span class="invalid-feedback d-block" role="alert" id="alamatError">
			<strong></strong>
		</span>
	</div>
</div>

<script type="text/javascript">
	function formatRupiah(angka, prefix)
	{
		var number_string = angka.replace(/[^,\d]/g, '').toString(),
		split    = number_string.split(','),
		sisa     = split[0].length % 3,
		rupiah     = split[0].substr(0, sisa),
		ribuan     = split[0].substr(sisa).match(/\d{3}/gi);

		if (ribuan) {
			separator = sisa ? '.' : '';
			rupiah += separator + ribuan.join('.');
		}

		rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
		return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
	}
	$(document).on('keyup','#penghasilan',function() {
		var nominal = $(this).val();
		$(this).val(formatRupiah(nominal,'Rp. '));
	});
</script>
<?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/page/pengaju/request/SURAT_KETERANGAN_PENGHASILAN_ORANG_TUA/skpot_1_form.blade.php ENDPATH**/ ?>