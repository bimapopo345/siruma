<div class="modal fade text-left" id="edit<?php echo e($dt->id_prosedur); ?>" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel1"><i class="fa fa-edit"></i> Form Ubah Prosedur</h5>
                <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
                ></button>
            </div>

            <div class="modal-body">
                <form method="post" action="<?php echo e(route('edit_prosedur',$dt->id_prosedur)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <label>Isi Prosedur</label>
                                <textarea class="form-control" rows="5" name="prosedur"><?php echo e($dt->prosedur); ?></textarea>
                            </div> 
                        </div>
                    </div>
                    <button class="btn btn-sm btn-primary form-control mt-2"><i class="fa fa-save"></i> Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ladar\resources\views/page/desa/prosedur/update.blade.php ENDPATH**/ ?>