<div id="sidebar" class="active">
    <div class="sidebar-wrapper active">
        <div class="sidebar-header">
            <div class="d-flex justify-content-between">
                <?php
                $desaporfil=DB::table('profil_desa')->where('user_id',Auth::user()->id)->get();
                $request=DB::table('surat')->where('desa_id',session('desaid'))->get();
                $logoutuser=DB::table('users')->get();
                $userporfil=DB::table('info_lengkap')->where('user_id',Auth::user()->id)->get();
                ?>
                <div class="toggler">
                    <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="d-flex align-items-center">
                <div class="avatar avatar-xl">

                    <?php if(Auth::user()->level=="Desa"): ?>
                    <?php $__currentLoopData = $desaporfil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dpf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($dpf->logo==NULL): ?>
                    <a href="<?php echo e(route('profil_desa')); ?>"><img src="<?php echo e(asset('template/dist/assets/images/faces/1.jpg')); ?>" alt="Face 1"></a>
                    <?php else: ?>
                    <a href="<?php echo e(route('profil_desa')); ?>"><img src="<?php echo e(asset('foto')); ?>/<?php echo e($dpf->logo); ?>" alt="Face 1"></a>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <?php $__currentLoopData = $userporfil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($usp->foto_profil==NULL): ?>
                    <a href="<?php echo e(route('profil_pengaju')); ?>"><img src="<?php echo e(asset('template/dist/assets/images/faces/1.jpg')); ?>" alt="Face 1"></a>
                    <?php else: ?>
                    <a href="<?php echo e(route('profil_pengaju')); ?>"><img src="<?php echo e(asset('profil')); ?>/<?php echo e($usp->foto_profil); ?>" alt="Face 1"></a>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if(Auth::user()->level=="Admin"): ?>
                    <a href=""><img src="<?php echo e(asset('template/dist/assets/images/faces/1.jpg')); ?>" alt="Face 1"></a>
                    <?php endif; ?>
                    
                </div>
                <div class="ms-3 name">
                    <h5 class="font-bold">
                        <?php echo e(Auth::user()->name); ?>

                    </h5>
                    <h6 class="text-muted mb-0"><?php echo e(Auth::user()->level); ?></h6>
                </div>
            </div>
        </div>
        <div class="sidebar-menu">
            <ul class="menu" id="menu">
                <li class="sidebar-title">Menu</li>

                <?php if(Auth::user()->level=="Desa"): ?>
                <li class="sidebar-item ">
                    <a href="<?php echo e(route('dashboard')); ?>" class='sidebar-link'>
                        <i class="bi bi-house"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                
                <li class="sidebar-item ">
                    <a href="<?php echo e(route('profil_desa')); ?>" class='sidebar-link'>
                        <i class="bi bi-person-square"></i>
                        <span>Profile Desa</span>
                    </a>
                </li>

                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i class="dripicons dripicons-user-group"></i>
                        <span>Data User</span>
                    </a>
                    <ul class="submenu ">
                        <li class="submenu-item ">
                            <a href="<?php echo e(route('user_pengaju')); ?>">Pengaju</a>
                        </li>
                        <li class="submenu-item ">
                            <a href="<?php echo e(route('user_pengurus')); ?>">Pengurus</a>
                        </li>
                    </ul>
                </li>

                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i class="dripicons dripicons-archive"></i>
                        <span>Data Master</span>
                    </a>
                    <ul class="submenu ">
                        <li class="submenu-item ">
                            <a href="<?php echo e(route('data_surat')); ?>">Surat</a>
                        </li>
                        <li class="submenu-item ">
                            <a href="<?php echo e(route('waktu_layanan')); ?>">Waktu Pelayanan</a>
                        </li>
                        <li class="submenu-item ">
                            <a href="<?php echo e(route('prosedur')); ?>">Prosedur Pengajuan</a>
                        </li>
                    </ul>
                </li>
                <li class="sidebar-item ">
                    <a href="<?php echo e(route('barcode')); ?>" class='sidebar-link'>
                        <i class="fa fa-qrcode"></i>
                        <span>Qr Code Poster</span>
                    </a>
                </li>
                <?php elseif(Auth::user()->level=="Pengaju"): ?>
                <li class="sidebar-item ">
                    <a href="<?php echo e(route('dashboard_pengaju')); ?>" class='sidebar-link'>
                        <i class="bi bi-house"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i class="dripicons dripicons-document-remove"></i>
                        <span>Data Request </span>
                    </a>
                    <ul class="submenu ">
                        <?php $__currentLoopData = $request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="submenu-item ">
                            <a href="<?php echo e(route('data_request',['id_surat'=>$req->id_surat,'singkatan'=>$req->singkatan])); ?>"><?php echo e($req->singkatan); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <?php elseif(Auth::user()->level=="Staff"): ?>
                <li class="sidebar-item ">
                    <a href="<?php echo e(route('dashboard_staff')); ?>" class='sidebar-link'>
                        <i class="bi bi-house"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i class="dripicons dripicons-document-edit"></i>
                        <span>Belum Acc</span>
                    </a>
                    <ul class="submenu ">
                        <?php $__currentLoopData = $request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="submenu-item ">
                            <a href="<?php echo e(route('staff_acc',['id_surat'=>$req->id_surat,'surat'=>$req->singkatan])); ?>"><?php echo e($req->singkatan); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i class="dripicons dripicons-print"></i>
                        <span>Cetak Surat</span>
                    </a>
                    <ul class="submenu ">
                        <?php $__currentLoopData = $request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="submenu-item ">
                            <a href="<?php echo e(route('staff_cetak',['id_surat'=>$req->id_surat,'surat'=>$req->singkatan])); ?>"><?php echo e($req->singkatan); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li class="sidebar-item">
                    <a href="<?php echo e(route('surat_selesai')); ?>" class='sidebar-link'>
                        <i class="dripicons dripicons-checkmark"></i>
                        <span>Surat Selesai</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="<?php echo e(route('laporan')); ?>" class='sidebar-link'>
                        <i class="dripicons dripicons-to-do"></i>
                        <span>Laporan</span>
                    </a>
                </li>
                <?php elseif(Auth::user()->level=="Kepala Desa"): ?>
                <li class="sidebar-item ">
                    <a href="<?php echo e(route('dashboard_kepaladesa')); ?>" class='sidebar-link'>
                        <i class="bi bi-house"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i class="dripicons dripicons-graph-pie"></i>
                        <span>ACC dan TTD</span>
                    </a>
                    <ul class="submenu ">
                        <?php $__currentLoopData = $request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="submenu-item ">
                            <a href="<?php echo e(route('kepaladesa_acc',['id_surat'=>$req->id_surat,'surat'=>$req->singkatan])); ?>"><?php echo e($req->singkatan); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <?php else: ?>
                <li class="sidebar-item has-sub">
                    <a href="#" class='sidebar-link'>
                        <i class="dripicons dripicons-user-group"></i>
                        <span>Desa Daftar</span>
                    </a>
                    <ul class="submenu ">
                        <li class="submenu-item ">
                            <a href="<?php echo e(route('user_desa')); ?>">Data Desa</a>
                        </li>
                    </ul>
                </li>
                <li class="sidebar-item  ">
                    <a href="<?php echo e(route('data_template')); ?>" class='sidebar-link'>
                        <i class="dripicons dripicons-blog"></i>
                        <span>Template</span>
                    </a>
                </li>
                <li class="sidebar-item  ">
                    <a href="<?php echo e(route('data_url')); ?>" class='sidebar-link'>
                        <i class="dripicons dripicons-blog"></i>
                        <span>URL Pendaftaran</span>
                    </a>
                </li>
                <?php endif; ?>
                <li class="sidebar-item  ">
                    <a href="<?php echo e(route('logout')); ?>" class='sidebar-link'>
                        <i class="dripicons dripicons-exit"></i>
                        <span>Logout</span>
                    </a>
                </li>

            </ul>
        </div>
        <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
    </div>
</div><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/desa/layout/sidebar.blade.php ENDPATH**/ ?>