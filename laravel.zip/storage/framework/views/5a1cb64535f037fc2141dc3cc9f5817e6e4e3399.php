<div class="col-lg-6">
	<label>Keperluan <span class="text-danger">*</span></label>
	<div class="form-group position-relative">
		<input type="text" id="keperluan" required="" class="form-control" name="keperluan" value="">
		<span class="invalid-feedback" role="alert" id="keperluanError">
			<strong></strong>
		</span>
	</div>
</div>
<div class="col-lg-6">
	<label>Untuk Usaha/Usaha yang dimiliki <span class="text-danger">*</span></label>
	<div class="form-group position-relative">
		<input type="text" id="nama_usaha" class="form-control" name="nama_usaha" value="">
		<span class="invalid-feedback" role="alert" id="nama_usahaError">
			<strong></strong>
		</span>
	</div>
</div>
<div class="col-xl-12">
	<label>Berkas Persyaratan <span class="text-danger">*</span></label>
	<div class="form-group position-relative">
		<input type="file" name="berkas" id="berkas" class="form-control">
		<span class="invalid-feedback" role="alert" id="berkasError">
			<strong></strong>
		</span>
	</div>
</div><?php /**PATH E:\xampp\htdocs\Produk Web\Web Surat Desa\resources\views/page/pengaju/request/SURAT_KETERANGAN_USAHA/sku_1_form.blade.php ENDPATH**/ ?>