<!DOCTYPE html>
<html lang="en">
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($dt->nomor_surat); ?></title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/bootstrap.css')); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/dripicons/webfont.css')); ?>"> -->
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/pages/dripicons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/dist/assets/css/app.css')); ?>">
</head>
<style type="text/css">
    .footer_right {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        text-align: right;
        padding: 10px;
    }
    .footer_left {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        text-align: left;
        padding: 10px;
    }
    .signature {
        display: inline-block;
        text-align: center;
        width: 50%; /* Adjust the width as needed */
        margin: 0 auto;
    }
</style>
<body style="background: white;color: black;">
    <div class="container-fluid" style="background: white;">
        <div class="row">
            <div class="col-xl-12">
                <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <center>
                    <img src="<?php echo e(asset('foto')); ?>/<?php echo e($ds->logo); ?>" alt="avatar" class="img" width="90" style="float: left;">
                    <b>PEMERINTAHAN <?php echo e($ds->name_city); ?> <br>
                        KECAMATAN <?php echo e($ds->name_district); ?></b>
                        <h5 style="color: black;">DESA <?php echo e($ds->name_village); ?></h5>
                        <span><?php echo e($ds->lokasi_desa); ?></span>
                    </center>
                    <hr>
                    <center>
                        <span style="font-size: 15px;text-transform: uppercase;font-weight: bold;text-decoration: underline;"><?php echo e($dt->nama_surat); ?></span>
                        <br>
                        <span>Nomor : <?php echo e($dt->nomor_surat); ?></span>
                    </center>
                    <p style="text-align: center;margin-top: 20px;">
                        Yang bertanda tangan dibawah ini menerangkan bahwa :
                    </p>
                    <table border="0" style="width: 100%;">
                        <?php  
                        $remark = explode(";", $dt->remark);
                        $tanggal_lahir = $dt->tgl_lahir;
                        ?>
                        <tr>
                            <td>1. Nama</td>
                            <td>:</td>
                            <td style="border-bottom: 1px solid #eee;"><?php echo e($dt->name); ?></td>
                        </tr>
                        <tr>
                            <td>2. Tempat Tanggal Lahir</td>
                            <td>:</td>
                            <td style="border-bottom: 1px solid #eee;"><?php echo e($dt->tempat); ?>, <?php echo e($dt->tgl_lahir); ?></td>
                        </tr>
                        <tr>
                            <td>3. Kewarganegaraan / Agama</td>
                            <td>:</td>
                            <td style="border-bottom: 1px solid #eee;"><?php echo e($dt->remark[0]); ?>, <?php echo e($dt->remark[1]); ?></td>
                        </tr>
                        <tr>
                            <td>4. Pekerjaan</td>
                            <td>:</td>
                            <td style="border-bottom: 1px solid #eee;"><?php echo e($dt->pekerjaan); ?></td>
                        </tr>
                        <tr>
                            <td>5. Tempat Tinggal</td>
                            <td>:</td>
                            <td style="border-bottom: 1px solid #eee;"><?php echo e($dt->tempat); ?></td>
                        </tr>
                        <tr>
                            <td>6. Surat bukti diri</td>
                            <td>:</td>
                            <td style="border-bottom: 1px solid #eee;">No NIK : <?php echo e($remark[2]); ?></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td style="border-bottom: 1px solid #eee;">No KK : <?php echo e($remark[3]); ?></td>
                        </tr>
                        <tr>
                            <td>Keperluan</td>
                            <td>:</td>
                            <td style="border-bottom: 1px solid #eee;"><?php echo e($dt->keperluan); ?></td>
                        </tr>
                        <tr>
                            <td>Berlaku mulai</td>
                            <td>:</td>
                            <td style="border-bottom: 1px solid #eee;"><?php echo e($dt->tgl_req); ?> s.d <?php echo e(date('Y-m-d', strtotime($dt->tgl_req . ' +3 months'))); ?></td>
                        </tr>
                        <tr>
                            <td>Keterangan lain</td>
                            <td>:</td>
                            <td style="border-bottom: 1px solid #eee;">Orang tersebut diatas benar-benar Penduduk Desa <?php echo e(ucfirst(strtolower($ds->name_village))); ?> Kec.<?php echo e(ucfirst(strtolower($ds->name_district))); ?> <?php echo e(ucfirst(strtolower($ds->name_city))); ?> dan berkelakuan Baik</td>
                        </tr>
                    </table>
                    <p style="text-align: center;"><br>Demikianlah untuk menjadikan maklum bagi yang berkepentingan</p>
                    <div class="footer_right">
                        <div class="signature" style="margin-bottom: 20px;">
                            <div><?php echo e(ucfirst(strtolower($ds->name_village))); ?>, <?php echo e(date('d F Y')); ?></div>
                            <div><img src="<?php echo e(asset($dt->ttd)); ?>" class="text" height="95"></div>
                            <div>
                             <?php if(Auth::user()->level!=="Kepala Desa"): ?>
                             <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <p><b><u><?php echo e($kpl->name); ?></u></b></p>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php else: ?>
                             <p><b><u><?php echo e(Auth::user()->name); ?></u></b></p>
                             <?php endif; ?>
                         </div>
                     </div>
                 </div>
                 <div class="footer_left">
                    <div class="signature" style="margin-bottom: 35px;">
                     <div>Tanda tangan pemegang</div>
                     <div><br></div>
                     <div><br></div>
                     <div><br></div>
                     <div><br></div>
                     <div style="font-weight: bold;text-decoration: underline;">
                         <?php echo e($dt->name); ?>

                     </div>
                 </div>
             </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div>
     </div>
 </div>
</body>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</html><?php /**PATH E:\xampp81\htdocs\Custom Produk\web_ratdela\resources\views/page/desa/template/SURAT_KETERANGAN_PENGANTAR_NIKAH/SKPN_1/print.blade.php ENDPATH**/ ?>