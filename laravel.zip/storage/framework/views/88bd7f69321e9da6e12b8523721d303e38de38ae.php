<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<b>PERHATIAN JANGAN MEMBALAS E-MAIL INI</b>
	<hr>
	<br>
	<?php if($details['status']=="Pemberitahuan"): ?>
	Anda telah mendaftar di DIGITAL SURAT PERMOHONAN, silahkan Tunggu Konfirmasi dari Pihak Admin untuk Meng-Aktifkan Akun anda : <br>
	<p>Provinsi : <?php echo e($details['provinsi']); ?></p>
	<p>Kota : <?php echo e($details['kota']); ?></p>
	<p>Kecamatan : <?php echo e($details['kecamatan']); ?></p>
	<p>Desa/Kelurahan : <?php echo e($details['desa']); ?></p>
	Pastikan Berkas yang di Upload Benar dan Resmi dari Kelurahan yang terdaftar, untuk Admin mempermudah Verifikasi.
	<?php elseif($details['status']=="Setuju"): ?>
	Yth. Bpk/Ibu  <span style="text-transform: uppercase;"><?php echo e($details['email']); ?></span>,
	<p>
		Kami Menyetujui Permohonan Kelurahan Desa anda.
	</p>
	<p>
		Untuk tahap masuk ke Halaman Kelurahan Desa, Anda dapat Menggunakan Kode Akses dan QR Code Kantor. <br>
		<br>
		Kode Akses Desa : <br><?php echo e($details['akses']); ?>

		<br>
		QR Code Kantor Kelurahan/Desa : <br>
		<?php
		$qrCodeAsPng = QrCode::format('png')->size(150)->generate($details['akses']);
		$text=$details['akses'].".png";
		?>
		<img src="<?php echo e($message->embedData($qrCodeAsPng, $text)); ?>" />
	</p>
	<br>
	<p>
		<i>Notes: Jangan beri tahu Kode Akses Desa anda selain Warga Desa setempat.</i>
	</p>
	<p>
		Demikian informasi dari kami. Atas perhatian dan kerjasamanya kami ucapkan terima kasih.
	</p>
	<?php elseif($details['status']=="Tolak"): ?>
	Yth. Bpk/Ibu  <span style="text-transform: uppercase;"><?php echo e($details['email']); ?></span>,
	<p>
		Kami Menolak Permohonan Kelurahan Desa anda.
	</p>
	<p>
		Di Karenakan formulir yang tidak lengkap dan Berkas yang tidak sesuai, mengacu pihak Admin untuk menolak Permohonan Kelurahan anda.
	</p>
	<p>
		Demikian informasi dari kami. Atas ke tidak nyaman nya kami ucapkan mohon maaf.
	</p>
	<?php else: ?>
	<p>
		Lupa Passowrd <?php echo e($details['email']); ?>, Verfikasi Akun jika ini memang Anda.<br>
		Kode Verifikasi : <?php echo e($details['verifikasi']); ?>

	</p>
	<p>
		<i>Notes: Jangan beri tahu Kode anda ke siapapun.</i>
	</p>
	<?php endif; ?>
	<p>
		<br>
		<i>Sistem Web Surat Permohonan/Pengajuan Digital,</i><br>
		<b>Dante Project</b>
	</p>
</body>
</html><?php /**PATH E:\xampp\htdocs\desa\resources\views/mail.blade.php ENDPATH**/ ?>