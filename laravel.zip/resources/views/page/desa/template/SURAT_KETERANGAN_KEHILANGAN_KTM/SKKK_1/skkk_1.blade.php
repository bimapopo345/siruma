@if($_GET['keyword']=="cek-surat")
@include("$path_template_cek")
@else
<center><h1>Tidak ada data di Temukan</h1></center>
@endif