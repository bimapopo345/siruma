<?php

return [
    'indonesia_' => [
        'table_prefix' => 'id_',
    ],
];
